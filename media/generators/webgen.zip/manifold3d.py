"""The part of the manifold3d Python API that the generators use, backed by manifold's WebAssembly build
(registered by the worker as the JS module manifold_js)."""
from __future__ import annotations

import numpy as np
from pyodide.ffi import to_js
import js
import manifold_js as _M


class Error:
    NoError = 0


class FillRule:
    Positive = "Positive"


def _f32(a):
    return js.Float32Array.new(to_js(memoryview(np.ascontiguousarray(a, np.float32).reshape(-1))))


def _u32(a):
    return js.Uint32Array.new(to_js(memoryview(np.ascontiguousarray(a, np.uint32).reshape(-1))))


class Mesh:
    def __init__(self, vert_properties=None, tri_verts=None, **kwargs):
        self.vert_properties = np.asarray(vert_properties, np.float32).reshape(-1, 3) if vert_properties is not None else np.zeros((0, 3), np.float32)
        self.tri_verts = np.asarray(tri_verts, np.uint32).reshape(-1, 3) if tri_verts is not None else np.zeros((0, 3), np.uint32)

    def _js(self):
        opts = js.Object.new()
        opts.numProp = int(self.vert_properties.shape[1])
        opts.vertProperties = _f32(self.vert_properties)
        opts.triVerts = _u32(self.tri_verts)
        return _M.Mesh.new(opts)

    def merge(self):
        return False


class Manifold:
    def __init__(self, mesh=None, _j=None):
        if _j is not None:
            self._j = _j
        elif mesh is None:
            self._j = _M.Manifold.union(js.Array.new())
        else:
            self._j = _M.Manifold.new(mesh._js())

    def __del__(self):
        try:
            self._j.delete()
        except Exception:
            pass

    @staticmethod
    def cube(size=(1.0, 1.0, 1.0), center=False):
        return Manifold(_j=_M.Manifold.cube(to_js([float(s) for s in size]), bool(center)))

    def status(self):
        s = self._j.status()
        s = getattr(s, "value", s)
        return 0 if s in (0, "NoError") else (s if isinstance(s, int) else 1)

    def is_empty(self):
        return bool(self._j.isEmpty())

    def volume(self):
        return float(self._j.volume())

    def translate(self, v):
        return Manifold(_j=self._j.translate(to_js([float(x) for x in v])))

    def scale(self, v):
        v = [float(v)] * 3 if np.isscalar(v) else [float(x) for x in v]
        return Manifold(_j=self._j.scale(to_js(v)))

    def mirror(self, n):
        return Manifold(_j=self._j.mirror(to_js([float(x) for x in n])))

    def simplify(self, *args, **kwargs):
        return self

    def get_tolerance(self):
        return float(self._j.tolerance())

    def decompose(self):
        return [Manifold(_j=p) for p in self._j.decompose()]

    def bounding_box(self):
        b = self._j.boundingBox()
        return tuple(float(x) for x in list(b.min) + list(b.max))

    def __add__(self, other):
        return Manifold(_j=self._j.add(other._j))

    def __sub__(self, other):
        return Manifold(_j=self._j.subtract(other._j))

    def __xor__(self, other):
        return Manifold(_j=self._j.intersect(other._j))

    def to_mesh(self):
        m = self._j.getMesh()
        n = int(m.numProp)
        v = np.asarray(m.vertProperties.to_py(), np.float32).reshape(-1, n)
        f = np.asarray(m.triVerts.to_py(), np.uint32).reshape(-1, 3)
        return Mesh(v[:, :3], f)


def triangulate(polygons, epsilon=-1.0):
    polys = js.Array.new()
    for poly in polygons:
        ring = js.Array.new()
        for p in poly:
            ring.push(to_js([float(p[0]), float(p[1])]))
        polys.push(ring)
    tris = _M.triangulate(polys, float(epsilon))
    return np.asarray([[int(t[0]), int(t[1]), int(t[2])] for t in tris], np.int64).reshape(-1, 3)


def _polygons(contours):
    polys = js.Array.new()
    for contour in contours:
        ring = js.Array.new()
        for p in contour:
            ring.push(to_js([float(p[0]), float(p[1])]))
        polys.push(ring)
    return polys


class CrossSection:
    def __init__(self, contours=None, fill_rule="Positive", _j=None):
        self._j = _j if _j is not None else _M.CrossSection.new(_polygons(contours or []), str(fill_rule))

    def __del__(self):
        try:
            self._j.delete()
        except Exception:
            pass

    def simplify(self, epsilon=1e-6):
        return CrossSection(_j=self._j.simplify(float(epsilon)))

    def decompose(self):
        return [CrossSection(_j=p) for p in self._j.decompose()]

    def to_polygons(self):
        return [[(float(pt[0]), float(pt[1])) for pt in ring] for ring in self._j.toPolygons()]
