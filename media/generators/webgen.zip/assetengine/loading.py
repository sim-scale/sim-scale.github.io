from __future__ import annotations

import hashlib
import importlib.util
import sys
from pathlib import Path

from .errors import GeneratorLoadError
from .spec import GeneratorSpec


def load_generator(path: str | Path) -> GeneratorSpec:
    generator_path = Path(path).expanduser().resolve()
    if not generator_path.is_file():
        raise GeneratorLoadError(f"generator file does not exist: {generator_path}")

    digest = hashlib.sha256(str(generator_path).encode("utf-8")).hexdigest()[:12]
    module_name = f"_assetengine_user_{digest}"
    spec = importlib.util.spec_from_file_location(module_name, generator_path)
    if spec is None or spec.loader is None:
        raise GeneratorLoadError(f"cannot create an import spec for {generator_path}")

    module = importlib.util.module_from_spec(spec)
    previous = sys.modules.get(module_name)
    sys.modules[module_name] = module
    sys.path.insert(0, str(generator_path.parent))
    try:
        spec.loader.exec_module(module)
    except Exception as exc:
        raise GeneratorLoadError(
            f"failed to import {generator_path}: {type(exc).__name__}: {exc}"
        ) from exc
    finally:
        if sys.path and sys.path[0] == str(generator_path.parent):
            sys.path.pop(0)
        if previous is None:
            sys.modules.pop(module_name, None)
        else:
            sys.modules[module_name] = previous

    generator = getattr(module, "GENERATOR", None)
    if not isinstance(generator, GeneratorSpec):
        raise GeneratorLoadError(
            f"{generator_path} must define top-level GENERATOR as assetengine.GeneratorSpec"
        )
    return generator
