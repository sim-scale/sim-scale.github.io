from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Sequence

import manifold3d
import numpy as np

from .articraft import MeshGeometry, Origin
from .errors import MountPlacementError

Vec3 = tuple[float, float, float]


@dataclass(frozen=True)
class RigidMountPlacement:
    """A child mesh and frame after bounded placement and attachment-surface trimming."""

    child_geometry: MeshGeometry
    parent_from_child: Origin
    translation: Vec3
    witness_intersection_volume: float
    final_intersection_volume: float
    discarded_components: int


def _as_manifold(geometry: MeshGeometry, *, name: str) -> manifold3d.Manifold:
    mesh = manifold3d.Mesh(
        np.asarray(geometry.vertices, dtype=np.float32),
        np.asarray(geometry.faces, dtype=np.uint32),
    )
    result = manifold3d.Manifold(mesh)
    if result.status() != manifold3d.Error.NoError:
        raise MountPlacementError(f"{name} must be a valid manifold solid")
    return result


def _intersection_volume(first: MeshGeometry, second: MeshGeometry) -> float:
    return float((_as_manifold(first, name="child") ^ _as_manifold(second, name="parent")).volume())


def _normalized(value: Sequence[float]) -> Vec3:
    if len(value) != 3:
        raise MountPlacementError("mount_direction must contain exactly three values")
    vector = (float(value[0]), float(value[1]), float(value[2]))
    if not all(math.isfinite(item) for item in vector):
        raise MountPlacementError("mount_direction must be finite")
    length = math.sqrt(sum(item * item for item in vector))
    if length <= 1e-12:
        raise MountPlacementError("mount_direction must be non-zero")
    return tuple(item / length for item in vector)  # type: ignore[return-value]


def _translated_origin(origin: Origin, direction: Vec3, distance: float) -> Origin:
    return Origin(
        xyz=tuple(
            float(origin.xyz[index]) + float(distance) * direction[index] for index in range(3)
        ),
        rpy=origin.rpy,
    )


def _to_parent_frame(geometry: MeshGeometry, origin: Origin) -> MeshGeometry:
    roll, pitch, yaw = origin.rpy
    return (
        geometry.copy()
        .rotate_x(float(roll))
        .rotate_y(float(pitch))
        .rotate_z(float(yaw))
        .translate(*origin.xyz)
    )


def _to_child_frame(geometry: MeshGeometry, origin: Origin) -> MeshGeometry:
    roll, pitch, yaw = origin.rpy
    return (
        geometry.copy()
        .translate(*(-float(value) for value in origin.xyz))
        .rotate_z(-float(yaw))
        .rotate_y(-float(pitch))
        .rotate_x(-float(roll))
    )


def _transform_point_to_parent(point: Sequence[float], origin: Origin) -> Vec3:
    if len(point) != 3:
        raise MountPlacementError("keep_point must contain exactly three values")
    marker = MeshGeometry(vertices=[tuple(float(value) for value in point)], faces=[])
    return _to_parent_frame(marker, origin).vertices[0]


def _mesh_from_manifold(component: manifold3d.Manifold) -> MeshGeometry:
    mesh = component.to_mesh()
    vertices = np.asarray(mesh.vert_properties, dtype=np.float64)
    faces = np.asarray(mesh.tri_verts, dtype=np.int64)
    return MeshGeometry(
        vertices=[tuple(float(value) for value in row[:3]) for row in vertices],
        faces=[tuple(int(value) for value in row) for row in faces],
    )


def _difference_components(
    child_geometry: MeshGeometry,
    parent_geometry: MeshGeometry,
) -> list[MeshGeometry]:
    components: list[MeshGeometry] = []
    difference = _as_manifold(child_geometry, name="positioned child") - _as_manifold(
        parent_geometry, name="parent"
    )
    for component in difference.decompose():
        components.append(_mesh_from_manifold(component))
    return components


def _aabb_contains(geometry: MeshGeometry, point: Vec3, *, tolerance: float = 1e-8) -> bool:
    if not geometry.vertices:
        return False
    for axis in range(3):
        values = [vertex[axis] for vertex in geometry.vertices]
        if point[axis] < min(values) - tolerance or point[axis] > max(values) + tolerance:
            return False
    return True


def _ray_triangle_distance(
    origin: Vec3,
    direction: Vec3,
    a: Vec3,
    b: Vec3,
    c: Vec3,
) -> float | None:
    epsilon = 1e-10
    edge_one = tuple(b[index] - a[index] for index in range(3))
    edge_two = tuple(c[index] - a[index] for index in range(3))
    cross = (
        direction[1] * edge_two[2] - direction[2] * edge_two[1],
        direction[2] * edge_two[0] - direction[0] * edge_two[2],
        direction[0] * edge_two[1] - direction[1] * edge_two[0],
    )
    determinant = sum(edge_one[index] * cross[index] for index in range(3))
    if abs(determinant) <= epsilon:
        return None
    inverse = 1.0 / determinant
    offset = tuple(origin[index] - a[index] for index in range(3))
    u_value = inverse * sum(offset[index] * cross[index] for index in range(3))
    if u_value < -epsilon or u_value > 1.0 + epsilon:
        return None
    q_vector = (
        offset[1] * edge_one[2] - offset[2] * edge_one[1],
        offset[2] * edge_one[0] - offset[0] * edge_one[2],
        offset[0] * edge_one[1] - offset[1] * edge_one[0],
    )
    v_value = inverse * sum(direction[index] * q_vector[index] for index in range(3))
    if v_value < -epsilon or u_value + v_value > 1.0 + epsilon:
        return None
    distance = inverse * sum(edge_two[index] * q_vector[index] for index in range(3))
    return distance if distance > epsilon else None


def _contains_point(geometry: MeshGeometry, point: Vec3) -> bool:
    if not _aabb_contains(geometry, point):
        return False
    direction = _normalized((0.917, 0.371, 0.149))
    distances: list[float] = []
    for face in geometry.faces:
        distance = _ray_triangle_distance(
            point,
            direction,
            geometry.vertices[face[0]],
            geometry.vertices[face[1]],
            geometry.vertices[face[2]],
        )
        if distance is not None:
            distances.append(distance)
    unique_hits = {round(distance, 9) for distance in distances}
    return len(unique_hits) % 2 == 1


def _select_component(components: Sequence[MeshGeometry], keep_point: Vec3) -> MeshGeometry:
    candidates = [component for component in components if _aabb_contains(component, keep_point)]
    containing = [component for component in candidates if _contains_point(component, keep_point)]
    if len(containing) == 1:
        return containing[0]
    if len(candidates) == 1:
        return candidates[0]
    raise MountPlacementError(
        "keep_point does not uniquely identify the desired exterior child component after trim"
    )


def place_rigid_mount(
    *,
    parent_geometry: MeshGeometry,
    child_geometry: MeshGeometry,
    parent_from_child: Origin,
    mount_direction: Sequence[float],
    keep_point: Sequence[float],
    max_translation: float,
    min_intersection_volume: float = 1e-10,
    max_final_intersection_volume: float = 1e-8,
    search_iterations: int = 24,
) -> RigidMountPlacement:
    """Translate a child frame to shallowly intersect a parent, then trim at the interface.

    ``mount_direction`` points from the parent toward the child in the parent frame. The search
    moves the complete child frame along that axis; it never stretches or extends child geometry.
    Both geometries must be manifold solids. ``keep_point`` is expressed in the child frame and
    must lie inside the exterior component that should remain after trimming.
    """

    if not isinstance(parent_geometry, MeshGeometry) or not parent_geometry.faces:
        raise MountPlacementError("parent_geometry must be a non-empty MeshGeometry solid")
    if not isinstance(child_geometry, MeshGeometry) or not child_geometry.faces:
        raise MountPlacementError("child_geometry must be a non-empty MeshGeometry solid")
    if not isinstance(parent_from_child, Origin):
        raise MountPlacementError("parent_from_child must be an Articraft Origin")
    direction = _normalized(mount_direction)
    maximum = float(max_translation)
    minimum_volume = float(min_intersection_volume)
    final_volume_limit = float(max_final_intersection_volume)
    if not math.isfinite(maximum) or maximum <= 0.0:
        raise MountPlacementError("max_translation must be finite and positive")
    if not math.isfinite(minimum_volume) or minimum_volume <= 0.0:
        raise MountPlacementError("min_intersection_volume must be finite and positive")
    if not math.isfinite(final_volume_limit) or final_volume_limit < 0.0:
        raise MountPlacementError("max_final_intersection_volume must be finite and non-negative")
    if int(search_iterations) < 4:
        raise MountPlacementError("search_iterations must be at least 4")

    def intersection_at(distance: float) -> tuple[Origin, MeshGeometry, float]:
        candidate_origin = _translated_origin(parent_from_child, direction, distance)
        candidate_geometry = _to_parent_frame(child_geometry, candidate_origin)
        return (
            candidate_origin,
            candidate_geometry,
            _intersection_volume(candidate_geometry, parent_geometry),
        )

    _outward_origin, _outward_geometry, outward_volume = intersection_at(maximum)
    if outward_volume >= minimum_volume:
        raise MountPlacementError(
            "cannot find a detached outward pose within max_translation; increase the bounded "
            "translation or correct the nominal child frame"
        )

    _inward_origin, _inward_geometry, inward_volume = intersection_at(-maximum)
    if inward_volume < minimum_volume:
        raise MountPlacementError(
            "cannot establish the required intersection within max_translation; correct the "
            "mount direction or nominal child frame"
        )

    outside_distance = maximum
    inside_distance = -maximum
    chosen_origin = _inward_origin
    positioned_parent = _inward_geometry
    witness_volume = inward_volume
    for _ in range(int(search_iterations)):
        midpoint = 0.5 * (outside_distance + inside_distance)
        candidate_origin, candidate_parent, candidate_volume = intersection_at(midpoint)
        if candidate_volume >= minimum_volume:
            inside_distance = midpoint
            chosen_origin = candidate_origin
            positioned_parent = candidate_parent
            witness_volume = candidate_volume
        else:
            outside_distance = midpoint

    components = _difference_components(positioned_parent, parent_geometry)
    if not components:
        raise MountPlacementError("trimming removed the complete child geometry")
    transformed_keep_point = _transform_point_to_parent(keep_point, chosen_origin)
    retained_parent = _select_component(components, transformed_keep_point)
    final_intersection_volume = _intersection_volume(retained_parent, parent_geometry)
    if final_intersection_volume > final_volume_limit:
        raise MountPlacementError(
            "trimmed rigid mount exceeds max_final_intersection_volume: "
            f"{final_intersection_volume:.6g} > {final_volume_limit:.6g}"
        )

    translation = tuple(
        float(chosen_origin.xyz[index]) - float(parent_from_child.xyz[index]) for index in range(3)
    )
    return RigidMountPlacement(
        child_geometry=_to_child_frame(retained_parent, chosen_origin),
        parent_from_child=chosen_origin,
        translation=translation,  # type: ignore[arg-type]
        witness_intersection_volume=witness_volume,
        final_intersection_volume=final_intersection_volume,
        discarded_components=len(components) - 1,
    )
