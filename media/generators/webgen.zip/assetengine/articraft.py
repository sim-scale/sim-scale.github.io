from __future__ import annotations

import sdk as _sdk

__all__ = list(_sdk.__all__)

for _name in __all__:
    globals()[_name] = getattr(_sdk, _name)
del _name


def __getattr__(name: str):
    return getattr(_sdk, name)


def __dir__() -> list[str]:
    return sorted(set(globals()) | set(__all__))
