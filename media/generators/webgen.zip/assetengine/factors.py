from __future__ import annotations

import json
import math
import random
import re
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Mapping

from .errors import GeneratorDefinitionError, SamplingError

ParameterValues = Mapping[str, Any]
_NAME_RE = re.compile(r"^[a-z][a-z0-9_]*$")


def _validate_name(name: str, *, kind: str = "factor") -> None:
    if not _NAME_RE.fullmatch(name):
        raise GeneratorDefinitionError(
            f"{kind} name {name!r} must be lower snake_case and start with a letter"
        )


def _validate_finite(value: float, *, field: str) -> float:
    result = float(value)
    if not math.isfinite(result):
        raise GeneratorDefinitionError(f"{field} must be finite")
    return result


def _ensure_json_value(value: Any, *, field: str) -> None:
    try:
        json.dumps(value)
    except (TypeError, ValueError) as exc:
        raise GeneratorDefinitionError(f"{field} must be JSON-serializable: {exc}") from exc


def _quantile(value: float) -> float:
    q = float(value)
    if not 0.0 <= q <= 1.0:
        raise SamplingError(f"quantile must be in [0, 1], got {q}")
    return q


def _same_choice(left: Any, right: Any) -> bool:
    return type(left) is type(right) and left == right


@dataclass(frozen=True, kw_only=True)
class ActiveWhen:
    """Declare when a factor affects the generated object's geometry or topology."""

    factor: str
    values: tuple[Any, ...]

    def __post_init__(self) -> None:
        _validate_name(self.factor, kind="activation selector")
        values = tuple(self.values)
        object.__setattr__(self, "values", values)
        if not values:
            raise GeneratorDefinitionError(
                f"activation selector {self.factor!r} needs at least one allowed value"
            )
        for index, value in enumerate(values):
            _ensure_json_value(value, field=f"active_when[{self.factor!r}].values[{index}]")
        for index, value in enumerate(values):
            if any(_same_choice(value, earlier) for earlier in values[:index]):
                raise GeneratorDefinitionError(
                    f"activation selector {self.factor!r} contains duplicate value {value!r}"
                )

    def matches(self, parameters: ParameterValues) -> bool:
        if self.factor not in parameters:
            return False
        current = parameters[self.factor]
        return any(_same_choice(current, allowed) for allowed in self.values)

    def describe(self) -> dict[str, Any]:
        return {"factor": self.factor, "values": list(self.values)}


@dataclass(frozen=True, kw_only=True)
class Factor(ABC):
    """One named value in an ordered generator parameterization."""

    name: str
    description: str
    unit: str | None = None
    active_when: tuple[ActiveWhen, ...] = ()

    def __post_init__(self) -> None:
        _validate_name(self.name)
        if not self.description.strip():
            raise GeneratorDefinitionError(f"factor {self.name!r} needs a description")
        if self.unit is not None and not self.unit.strip():
            raise GeneratorDefinitionError(f"factor {self.name!r} has an empty unit")
        active_when = tuple(self.active_when)
        object.__setattr__(self, "active_when", active_when)
        if not all(isinstance(rule, ActiveWhen) for rule in active_when):
            raise GeneratorDefinitionError(
                f"factor {self.name!r} active_when entries must be ActiveWhen instances"
            )
        selectors = [rule.factor for rule in active_when]
        if len(selectors) != len(set(selectors)):
            raise GeneratorDefinitionError(
                f"factor {self.name!r} must declare at most one ActiveWhen rule per selector"
            )

    @property
    def stochastic(self) -> bool:
        return True

    @property
    def dependencies(self) -> tuple[str, ...]:
        return ()

    def validate_dependencies(self, available: set[str]) -> None:
        referenced = (*self.dependencies, *(rule.factor for rule in self.active_when))
        missing = [name for name in referenced if name not in available]
        if missing:
            raise GeneratorDefinitionError(
                f"factor {self.name!r} references factors that are not defined earlier: {missing}"
            )

    def is_active(self, parameters: ParameterValues) -> bool:
        """Return whether all declared activation rules match the supplied parameters."""
        return all(rule.matches(parameters) for rule in self.active_when)

    @abstractmethod
    def sample(self, rng: random.Random, values: ParameterValues) -> Any:
        """Sample this factor using the supplied deterministic RNG."""

    @abstractmethod
    def at_quantile(self, quantile: float, values: ParameterValues) -> Any:
        """Resolve this factor at a deterministic quantile."""

    def describe(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "kind": type(self).__name__,
            "description": self.description,
            "unit": self.unit,
            "stochastic": self.stochastic,
            "dependencies": list(self.dependencies),
            "active_when": [rule.describe() for rule in self.active_when],
        }

    def normalize_override(self, value: Any) -> Any:
        _ensure_json_value(value, field=f"{self.name} override")
        return value


@dataclass(frozen=True, kw_only=True)
class UniformFloat(Factor):
    low: float
    high: float

    def __post_init__(self) -> None:
        super().__post_init__()
        low = _validate_finite(self.low, field=f"{self.name}.low")
        high = _validate_finite(self.high, field=f"{self.name}.high")
        if low >= high:
            raise GeneratorDefinitionError(f"{self.name}: low must be smaller than high")

    def sample(self, rng: random.Random, values: ParameterValues) -> float:
        del values
        return rng.uniform(float(self.low), float(self.high))

    def at_quantile(self, quantile: float, values: ParameterValues) -> float:
        del values
        q = _quantile(quantile)
        return float(self.low) + q * (float(self.high) - float(self.low))

    def describe(self) -> dict[str, Any]:
        return {**super().describe(), "low": self.low, "high": self.high}

    def normalize_override(self, value: Any) -> float:
        if not isinstance(value, (int, float)) or isinstance(value, bool):
            raise SamplingError(f"{self.name}: override must be numeric")
        result = float(value)
        if not math.isfinite(result):
            raise SamplingError(f"{self.name}: override must be finite")
        return result


@dataclass(frozen=True, kw_only=True)
class UniformInt(Factor):
    low: int
    high: int

    def __post_init__(self) -> None:
        super().__post_init__()
        if isinstance(self.low, bool) or isinstance(self.high, bool):
            raise GeneratorDefinitionError(f"{self.name}: integer bounds cannot be booleans")
        if int(self.low) >= int(self.high):
            raise GeneratorDefinitionError(f"{self.name}: low must be smaller than high")

    def sample(self, rng: random.Random, values: ParameterValues) -> int:
        del values
        return rng.randint(int(self.low), int(self.high))

    def at_quantile(self, quantile: float, values: ParameterValues) -> int:
        del values
        q = _quantile(quantile)
        count = int(self.high) - int(self.low) + 1
        index = min(int(q * count), count - 1)
        return int(self.low) + index

    def describe(self) -> dict[str, Any]:
        return {**super().describe(), "low": self.low, "high": self.high}

    def normalize_override(self, value: Any) -> int:
        if not isinstance(value, (int, float)) or isinstance(value, bool):
            raise SamplingError(f"{self.name}: override must be an integer")
        result = int(value)
        if float(value) != float(result):
            raise SamplingError(f"{self.name}: override must be an integer")
        return result


@dataclass(frozen=True, kw_only=True)
class UniformChoice(Factor):
    choices: tuple[Any, ...]

    def __post_init__(self) -> None:
        super().__post_init__()
        choices = tuple(self.choices)
        object.__setattr__(self, "choices", choices)
        if len(choices) < 2:
            raise GeneratorDefinitionError(f"{self.name}: provide at least two choices")
        for index, choice in enumerate(choices):
            _ensure_json_value(choice, field=f"{self.name}.choices[{index}]")
            if any(_same_choice(choice, earlier) for earlier in choices[:index]):
                raise GeneratorDefinitionError(
                    f"{self.name}: choices contain duplicate value {choice!r}; "
                    "UniformChoice samples unique choices uniformly"
                )

    def sample(self, rng: random.Random, values: ParameterValues) -> Any:
        del values
        return self.choices[rng.randrange(len(self.choices))]

    def at_quantile(self, quantile: float, values: ParameterValues) -> Any:
        del values
        q = _quantile(quantile)
        index = round(q * (len(self.choices) - 1))
        return self.choices[index]

    def describe(self) -> dict[str, Any]:
        return {**super().describe(), "choices": list(self.choices)}

    def normalize_override(self, value: Any) -> Any:
        if not any(type(value) is type(choice) and value == choice for choice in self.choices):
            raise SamplingError(
                f"{self.name}: override {value!r} is not one of the authored choices"
            )
        return value


@dataclass(frozen=True, kw_only=True)
class RelativeUniformFloat(Factor):
    """
    Uniformly sample inside a feasible interval derived from an earlier factor.

    This factor represents a genuine conditional size or placement dependency on an earlier
    reference. Choose it or an independent factor from target-category joint variation rather than
    a global default. A residual invalid parent-fit region between otherwise independent targets
    is normally represented by a derived cap or constraint.

    `hard_min` and `hard_max` narrow the conditional interval before sampling;
    they do not clip an already sampled value. This avoids a probability spike
    at the safeguard boundary.
    """

    reference: str
    ratio_low: float
    ratio_high: float
    offset: float = 0.0
    hard_min: float | None = None
    hard_max: float | None = None

    def __post_init__(self) -> None:
        super().__post_init__()
        _validate_name(self.reference, kind="reference")
        ratio_low = _validate_finite(self.ratio_low, field=f"{self.name}.ratio_low")
        ratio_high = _validate_finite(self.ratio_high, field=f"{self.name}.ratio_high")
        _validate_finite(self.offset, field=f"{self.name}.offset")
        if ratio_low >= ratio_high:
            raise GeneratorDefinitionError(f"{self.name}: ratio_low must be below ratio_high")
        if self.hard_min is not None:
            _validate_finite(self.hard_min, field=f"{self.name}.hard_min")
        if self.hard_max is not None:
            _validate_finite(self.hard_max, field=f"{self.name}.hard_max")
        if (
            self.hard_min is not None
            and self.hard_max is not None
            and float(self.hard_min) >= float(self.hard_max)
        ):
            raise GeneratorDefinitionError(f"{self.name}: hard_min must be below hard_max")

    @property
    def dependencies(self) -> tuple[str, ...]:
        return (self.reference,)

    def bounds_for_ratios(
        self,
        values: ParameterValues,
        *,
        ratio_low: float,
        ratio_high: float,
    ) -> tuple[float, float]:
        """Resolve a ratio interval against this sample's reference value.

        Viewer-edited population ranges use this method so changing the parent factor does not
        silently turn a relative factor into an independent absolute measurement. Equal ratio
        bounds are accepted here to let the viewer pin a factor to one ratio.
        """

        if (
            not isinstance(ratio_low, (int, float))
            or isinstance(ratio_low, bool)
            or not math.isfinite(float(ratio_low))
        ):
            raise SamplingError(f"{self.name}: sampling ratio minimum must be finite")
        if (
            not isinstance(ratio_high, (int, float))
            or isinstance(ratio_high, bool)
            or not math.isfinite(float(ratio_high))
        ):
            raise SamplingError(f"{self.name}: sampling ratio maximum must be finite")
        ratio_low_f = float(ratio_low)
        ratio_high_f = float(ratio_high)
        if ratio_low_f > ratio_high_f:
            raise SamplingError(f"{self.name}: sampling ratio minimum must not exceed maximum")

        raw_reference = values.get(self.reference)
        if not isinstance(raw_reference, (int, float)) or isinstance(raw_reference, bool):
            raise SamplingError(
                f"{self.name}: reference {self.reference!r} must resolve to a number"
            )
        reference = float(raw_reference)
        low = reference * ratio_low_f + float(self.offset)
        high = reference * ratio_high_f + float(self.offset)
        if self.hard_min is not None:
            low = max(low, float(self.hard_min))
        if self.hard_max is not None:
            high = min(high, float(self.hard_max))
        if low > high:
            raise SamplingError(
                f"{self.name}: no feasible interval after safeguards; low={low:.6g}, "
                f"high={high:.6g}, reference {self.reference}={reference:.6g}"
            )
        return low, high

    def bounds(self, values: ParameterValues) -> tuple[float, float]:
        return self.bounds_for_ratios(
            values,
            ratio_low=float(self.ratio_low),
            ratio_high=float(self.ratio_high),
        )

    def sample(self, rng: random.Random, values: ParameterValues) -> float:
        low, high = self.bounds(values)
        return rng.uniform(low, high)

    def at_quantile(self, quantile: float, values: ParameterValues) -> float:
        q = _quantile(quantile)
        low, high = self.bounds(values)
        return low + q * (high - low)

    def describe(self) -> dict[str, Any]:
        return {
            **super().describe(),
            "reference": self.reference,
            "ratio_low": self.ratio_low,
            "ratio_high": self.ratio_high,
            "offset": self.offset,
            "hard_min": self.hard_min,
            "hard_max": self.hard_max,
        }

    def normalize_override(self, value: Any) -> float:
        if not isinstance(value, (int, float)) or isinstance(value, bool):
            raise SamplingError(f"{self.name}: override must be numeric")
        result = float(value)
        if not math.isfinite(result):
            raise SamplingError(f"{self.name}: override must be finite")
        return result


@dataclass(frozen=True, kw_only=True)
class Derived(Factor):
    derive: Any
    depends_on: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        super().__post_init__()
        if not callable(self.derive):
            raise GeneratorDefinitionError(f"{self.name}: derive must be callable")
        dependencies = tuple(self.depends_on)
        object.__setattr__(self, "depends_on", dependencies)
        for dependency in dependencies:
            _validate_name(dependency, kind="derived dependency")

    @property
    def stochastic(self) -> bool:
        return False

    @property
    def dependencies(self) -> tuple[str, ...]:
        return self.depends_on

    def sample(self, rng: random.Random, values: ParameterValues) -> Any:
        del rng
        return self._resolve(values)

    def at_quantile(self, quantile: float, values: ParameterValues) -> Any:
        del quantile
        return self._resolve(values)

    def _resolve(self, values: ParameterValues) -> Any:
        try:
            value = self.derive(values)
        except Exception as exc:
            raise SamplingError(f"{self.name}: derived expression failed: {exc}") from exc
        _ensure_json_value(value, field=self.name)
        return value
