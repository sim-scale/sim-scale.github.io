from __future__ import annotations

import json
import math
import random
import re
from dataclasses import dataclass, field
from typing import Any, Callable, Mapping, Sequence

from .errors import GeneratorDefinitionError, SamplingError
from .factors import (
    ActiveWhen,
    Derived,
    Factor,
    ParameterValues,
    RelativeUniformFloat,
    UniformChoice,
    UniformFloat,
    UniformInt,
)

_SLUG_RE = re.compile(r"^[a-z][a-z0-9_-]*$")
ConstraintPredicate = Callable[[ParameterValues], bool]
PopulationPredicate = Callable[[Sequence[ParameterValues]], bool]
BuildFunction = Callable[[ParameterValues], object]
TestFunction = Callable[[object, ParameterValues], object]


@dataclass(frozen=True, kw_only=True)
class GeneratorDesign:
    """Concise category-level reasoning that must precede generator implementation."""

    coverage: str
    factors: str
    components: str
    physics_and_task: str

    def __post_init__(self) -> None:
        for field_name in ("coverage", "factors", "components", "physics_and_task"):
            value = getattr(self, field_name)
            if not isinstance(value, str) or not value.strip():
                raise GeneratorDefinitionError(
                    f"generator design field {field_name!r} must be a non-empty string"
                )

    def describe(self) -> dict[str, str]:
        return {
            "coverage": self.coverage,
            "factors": self.factors,
            "components": self.components,
            "physics_and_task": self.physics_and_task,
        }


def _validate_relationship_name(name: str, *, kind: str) -> None:
    if not _SLUG_RE.fullmatch(name):
        raise GeneratorDefinitionError(f"{kind} name {name!r} must be a lowercase slug")


def _validate_part_name(value: object, *, relationship: str, field_name: str) -> None:
    if not isinstance(value, str) or not value.strip():
        raise GeneratorDefinitionError(
            f"relationship {relationship!r} {field_name} must be a non-empty part name"
        )


def _validate_element_name(value: object, *, relationship: str, field_name: str) -> None:
    if value is not None and (not isinstance(value, str) or not value.strip()):
        raise GeneratorDefinitionError(
            f"relationship {relationship!r} {field_name} must be a non-empty element name"
        )


def _validate_contact_tolerance(value: object, *, relationship: str) -> float:
    try:
        tolerance = float(value)
    except (TypeError, ValueError) as exc:
        raise GeneratorDefinitionError(
            f"relationship {relationship!r} contact_tolerance must be numeric"
        ) from exc
    if not math.isfinite(tolerance) or tolerance < 0.0:
        raise GeneratorDefinitionError(
            f"relationship {relationship!r} contact_tolerance must be finite and non-negative"
        )
    return tolerance


def _validate_active_when(
    rules: Sequence[ActiveWhen],
    *,
    relationship: str,
) -> tuple[ActiveWhen, ...]:
    active_when = tuple(rules)
    if not all(isinstance(rule, ActiveWhen) for rule in active_when):
        raise GeneratorDefinitionError(
            f"relationship {relationship!r} active_when entries must be ActiveWhen instances"
        )
    selectors = [rule.factor for rule in active_when]
    if len(selectors) != len(set(selectors)):
        raise GeneratorDefinitionError(
            f"relationship {relationship!r} must declare at most one ActiveWhen rule per selector"
        )
    return active_when


def _validate_geometry_pair(
    *,
    relationship: str,
    first_part: str,
    second_part: str,
    first_element: str | None,
    second_element: str | None,
) -> None:
    if first_part == second_part:
        if first_element is None or second_element is None:
            raise GeneratorDefinitionError(
                f"relationship {relationship!r} within one part must name both elements"
            )
        if first_element == second_element:
            raise GeneratorDefinitionError(
                f"relationship {relationship!r} must reference two different elements"
            )


@dataclass(frozen=True, kw_only=True)
class RigidMount:
    """Declare a permanent, non-moving physical mount from a child to a parent."""

    name: str
    parent_part: str
    child_part: str
    parent_element: str | None = None
    child_element: str | None = None
    fixed_joint: str | None = None
    contact_tolerance: float = 1e-6
    active_when: tuple[ActiveWhen, ...] = ()

    def __post_init__(self) -> None:
        _validate_relationship_name(self.name, kind="rigid mount")
        _validate_part_name(self.parent_part, relationship=self.name, field_name="parent_part")
        _validate_part_name(self.child_part, relationship=self.name, field_name="child_part")
        _validate_element_name(
            self.parent_element, relationship=self.name, field_name="parent_element"
        )
        _validate_element_name(
            self.child_element, relationship=self.name, field_name="child_element"
        )
        _validate_geometry_pair(
            relationship=self.name,
            first_part=self.parent_part,
            second_part=self.child_part,
            first_element=self.parent_element,
            second_element=self.child_element,
        )
        if self.parent_part == self.child_part and self.fixed_joint is not None:
            raise GeneratorDefinitionError(
                f"rigid mount {self.name!r} within one part cannot declare fixed_joint"
            )
        if self.parent_part != self.child_part and (
            not isinstance(self.fixed_joint, str) or not self.fixed_joint.strip()
        ):
            raise GeneratorDefinitionError(
                f"rigid mount {self.name!r} between parts must declare fixed_joint"
            )
        object.__setattr__(
            self,
            "contact_tolerance",
            _validate_contact_tolerance(self.contact_tolerance, relationship=self.name),
        )
        object.__setattr__(
            self,
            "active_when",
            _validate_active_when(self.active_when, relationship=self.name),
        )

    def is_active(self, parameters: ParameterValues) -> bool:
        return all(rule.matches(parameters) for rule in self.active_when)

    def describe(self) -> dict[str, Any]:
        return {
            "kind": "rigid_mount",
            "name": self.name,
            "parent_part": self.parent_part,
            "child_part": self.child_part,
            "parent_element": self.parent_element,
            "child_element": self.child_element,
            "fixed_joint": self.fixed_joint,
            "contact_tolerance": self.contact_tolerance,
            "active_when": [rule.describe() for rule in self.active_when],
        }


@dataclass(frozen=True, kw_only=True)
class JointMount:
    """Declare a moving parent-child relationship backed by an Articraft articulation."""

    name: str
    joint: str
    parent_part: str
    child_part: str
    allowed_joint_types: tuple[str, ...] = ("revolute", "continuous", "prismatic", "floating")
    active_when: tuple[ActiveWhen, ...] = ()

    def __post_init__(self) -> None:
        _validate_relationship_name(self.name, kind="joint mount")
        _validate_part_name(self.parent_part, relationship=self.name, field_name="parent_part")
        _validate_part_name(self.child_part, relationship=self.name, field_name="child_part")
        if self.parent_part == self.child_part:
            raise GeneratorDefinitionError(
                f"joint mount {self.name!r} parent_part and child_part must differ"
            )
        if not isinstance(self.joint, str) or not self.joint.strip():
            raise GeneratorDefinitionError(
                f"joint mount {self.name!r} joint must be a non-empty articulation name"
            )
        allowed_joint_types = tuple(str(value).strip() for value in self.allowed_joint_types)
        valid_types = {"revolute", "continuous", "prismatic", "floating"}
        if not allowed_joint_types or any(
            not value or value not in valid_types for value in allowed_joint_types
        ):
            raise GeneratorDefinitionError(
                f"joint mount {self.name!r} allowed_joint_types must be a non-empty subset of "
                f"{sorted(valid_types)}; fixed joints belong in RigidMount"
            )
        if len(allowed_joint_types) != len(set(allowed_joint_types)):
            raise GeneratorDefinitionError(
                f"joint mount {self.name!r} allowed_joint_types must be unique"
            )
        object.__setattr__(self, "allowed_joint_types", allowed_joint_types)
        object.__setattr__(
            self,
            "active_when",
            _validate_active_when(self.active_when, relationship=self.name),
        )

    def is_active(self, parameters: ParameterValues) -> bool:
        return all(rule.matches(parameters) for rule in self.active_when)

    def describe(self) -> dict[str, Any]:
        return {
            "kind": "joint_mount",
            "name": self.name,
            "joint": self.joint,
            "parent_part": self.parent_part,
            "child_part": self.child_part,
            "allowed_joint_types": list(self.allowed_joint_types),
            "active_when": [rule.describe() for rule in self.active_when],
        }


@dataclass(frozen=True, kw_only=True)
class SupportContact:
    """Declare touching support without mechanical attachment or relative-motion semantics."""

    name: str
    supporting_part: str
    supported_part: str
    supporting_element: str | None = None
    supported_element: str | None = None
    contact_tolerance: float = 1e-6
    active_when: tuple[ActiveWhen, ...] = ()

    def __post_init__(self) -> None:
        _validate_relationship_name(self.name, kind="support contact")
        _validate_part_name(
            self.supporting_part, relationship=self.name, field_name="supporting_part"
        )
        _validate_part_name(
            self.supported_part, relationship=self.name, field_name="supported_part"
        )
        _validate_element_name(
            self.supporting_element, relationship=self.name, field_name="supporting_element"
        )
        _validate_element_name(
            self.supported_element, relationship=self.name, field_name="supported_element"
        )
        _validate_geometry_pair(
            relationship=self.name,
            first_part=self.supporting_part,
            second_part=self.supported_part,
            first_element=self.supporting_element,
            second_element=self.supported_element,
        )
        object.__setattr__(
            self,
            "contact_tolerance",
            _validate_contact_tolerance(self.contact_tolerance, relationship=self.name),
        )
        object.__setattr__(
            self,
            "active_when",
            _validate_active_when(self.active_when, relationship=self.name),
        )

    def is_active(self, parameters: ParameterValues) -> bool:
        return all(rule.matches(parameters) for rule in self.active_when)

    def describe(self) -> dict[str, Any]:
        return {
            "kind": "support_contact",
            "name": self.name,
            "supporting_part": self.supporting_part,
            "supported_part": self.supported_part,
            "supporting_element": self.supporting_element,
            "supported_element": self.supported_element,
            "contact_tolerance": self.contact_tolerance,
            "active_when": [rule.describe() for rule in self.active_when],
        }


PhysicalRelationship = RigidMount | JointMount | SupportContact


@dataclass(frozen=True, kw_only=True)
class Constraint:
    name: str
    predicate: ConstraintPredicate
    message: str

    def __post_init__(self) -> None:
        if not _SLUG_RE.fullmatch(self.name):
            raise GeneratorDefinitionError(
                f"constraint name {self.name!r} must be a lowercase slug"
            )
        if not callable(self.predicate):
            raise GeneratorDefinitionError(f"constraint {self.name!r} predicate is not callable")
        if not self.message.strip():
            raise GeneratorDefinitionError(f"constraint {self.name!r} needs a failure message")

    def evaluate(self, values: ParameterValues) -> tuple[bool, str]:
        try:
            return bool(self.predicate(values)), self.message
        except Exception as exc:
            return False, f"{self.message} Predicate raised {type(exc).__name__}: {exc}"


@dataclass(frozen=True, kw_only=True)
class PopulationCheck:
    name: str
    predicate: PopulationPredicate
    message: str

    def __post_init__(self) -> None:
        if not _SLUG_RE.fullmatch(self.name):
            raise GeneratorDefinitionError(
                f"population check name {self.name!r} must be a lowercase slug"
            )
        if not callable(self.predicate):
            raise GeneratorDefinitionError(
                f"population check {self.name!r} predicate is not callable"
            )
        if not self.message.strip():
            raise GeneratorDefinitionError(
                f"population check {self.name!r} needs a failure message"
            )

    def evaluate(self, samples: Sequence[ParameterValues]) -> tuple[bool, str]:
        try:
            return bool(self.predicate(samples)), self.message
        except Exception as exc:
            return False, f"{self.message} Predicate raised {type(exc).__name__}: {exc}"


@dataclass(frozen=True)
class ParameterSample:
    values: dict[str, Any]
    mode: str
    attempts: int
    seed: int | None = None
    quantiles: dict[str, float] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "values": self.values,
            "mode": self.mode,
            "attempts": self.attempts,
            "seed": self.seed,
            "quantiles": self.quantiles,
        }


@dataclass(frozen=True, kw_only=True)
class GeneratorSpec:
    name: str
    category: str
    description: str
    design: GeneratorDesign
    factors: tuple[Factor, ...]
    build: BuildFunction
    tests: TestFunction | None = None
    relationships: tuple[PhysicalRelationship, ...] = ()
    constraints: tuple[Constraint, ...] = ()
    population_checks: tuple[PopulationCheck, ...] = ()
    task_requirements: tuple[str, ...] = ()
    tags: tuple[str, ...] = ()
    schema_version: str = "0.1"
    max_sampling_attempts: int = 100

    def __post_init__(self) -> None:
        object.__setattr__(self, "factors", tuple(self.factors))
        object.__setattr__(self, "relationships", tuple(self.relationships))
        object.__setattr__(self, "constraints", tuple(self.constraints))
        object.__setattr__(self, "population_checks", tuple(self.population_checks))
        object.__setattr__(self, "task_requirements", tuple(self.task_requirements))
        object.__setattr__(self, "tags", tuple(self.tags))
        self.validate_definition()

    @property
    def stochastic_factor_names(self) -> tuple[str, ...]:
        return tuple(factor.name for factor in self.factors if factor.stochastic)

    def validate_definition(self) -> None:
        if not _SLUG_RE.fullmatch(self.name):
            raise GeneratorDefinitionError(f"generator name {self.name!r} must be a lowercase slug")
        if not self.category.strip():
            raise GeneratorDefinitionError("generator category must be non-empty")
        if not self.description.strip():
            raise GeneratorDefinitionError("generator description must be non-empty")
        if not isinstance(self.design, GeneratorDesign):
            raise GeneratorDefinitionError("generator design must be a GeneratorDesign instance")
        if self.schema_version != "0.1":
            raise GeneratorDefinitionError(
                f"unsupported generator schema {self.schema_version!r}; expected '0.1'"
            )
        if not self.factors:
            raise GeneratorDefinitionError("generator must define at least one factor")
        if not callable(self.build):
            raise GeneratorDefinitionError("generator build must be callable")
        if self.tests is not None and not callable(self.tests):
            raise GeneratorDefinitionError("generator tests must be callable or None")
        if self.max_sampling_attempts < 1:
            raise GeneratorDefinitionError("max_sampling_attempts must be at least 1")

        names: set[str] = set()
        factors_by_name: dict[str, Factor] = {}
        for factor in self.factors:
            if not isinstance(factor, Factor):
                raise GeneratorDefinitionError(
                    f"all factors must inherit Factor; got {type(factor).__name__}"
                )
            if factor.name in names:
                raise GeneratorDefinitionError(f"duplicate factor name {factor.name!r}")
            factor.validate_dependencies(names)
            for rule in factor.active_when:
                selector = factors_by_name[rule.factor]
                if isinstance(selector, UniformChoice):
                    invalid = [
                        value
                        for value in rule.values
                        if not any(
                            type(value) is type(choice) and value == choice
                            for choice in selector.choices
                        )
                    ]
                    if invalid:
                        raise GeneratorDefinitionError(
                            f"factor {factor.name!r} activation values {invalid!r} are not "
                            f"choices of selector {selector.name!r}"
                        )
                elif isinstance(selector, UniformInt):
                    invalid = [
                        value
                        for value in rule.values
                        if isinstance(value, bool)
                        or not isinstance(value, int)
                        or not int(selector.low) <= value <= int(selector.high)
                    ]
                    if invalid:
                        raise GeneratorDefinitionError(
                            f"factor {factor.name!r} activation values {invalid!r} are outside "
                            f"integer selector {selector.name!r}"
                        )
                else:
                    raise GeneratorDefinitionError(
                        f"factor {factor.name!r} activation selector {selector.name!r} must be "
                        "UniformChoice or UniformInt"
                    )
            names.add(factor.name)
            factors_by_name[factor.name] = factor

        relationship_names: list[str] = []
        for relationship in self.relationships:
            if not isinstance(relationship, (RigidMount, JointMount, SupportContact)):
                raise GeneratorDefinitionError(
                    "all relationships must be RigidMount, JointMount, or SupportContact "
                    f"instances; got {type(relationship).__name__}"
                )
            relationship_names.append(relationship.name)
            for rule in relationship.active_when:
                selector = factors_by_name.get(rule.factor)
                if selector is None:
                    raise GeneratorDefinitionError(
                        f"relationship {relationship.name!r} references unknown activation selector "
                        f"{rule.factor!r}"
                    )
                if isinstance(selector, UniformChoice):
                    invalid = [
                        value
                        for value in rule.values
                        if not any(
                            type(value) is type(choice) and value == choice
                            for choice in selector.choices
                        )
                    ]
                    if invalid:
                        raise GeneratorDefinitionError(
                            f"relationship {relationship.name!r} activation values {invalid!r} are "
                            f"not choices of selector {selector.name!r}"
                        )
                elif isinstance(selector, UniformInt):
                    invalid = [
                        value
                        for value in rule.values
                        if isinstance(value, bool)
                        or not isinstance(value, int)
                        or not int(selector.low) <= value <= int(selector.high)
                    ]
                    if invalid:
                        raise GeneratorDefinitionError(
                            f"relationship {relationship.name!r} activation values {invalid!r} are "
                            f"outside integer selector {selector.name!r}"
                        )
                else:
                    raise GeneratorDefinitionError(
                        f"relationship {relationship.name!r} activation selector "
                        f"{selector.name!r} must be UniformChoice or UniformInt"
                    )
        if len(relationship_names) != len(set(relationship_names)):
            raise GeneratorDefinitionError("relationship names must be unique")

        constraint_names = [constraint.name for constraint in self.constraints]
        if len(constraint_names) != len(set(constraint_names)):
            raise GeneratorDefinitionError("constraint names must be unique")
        check_names = [check.name for check in self.population_checks]
        if len(check_names) != len(set(check_names)):
            raise GeneratorDefinitionError("population check names must be unique")

    def _resolve(
        self,
        *,
        rng: random.Random | None,
        quantiles: Mapping[str, float] | None,
    ) -> dict[str, Any]:
        values: dict[str, Any] = {}
        for factor in self.factors:
            if quantiles is None:
                if rng is None:
                    raise AssertionError("rng is required for random sampling")
                value = factor.sample(rng, values)
            else:
                value = factor.at_quantile(float(quantiles.get(factor.name, 0.5)), values)
            values[factor.name] = value
        try:
            json.dumps(values)
        except (TypeError, ValueError) as exc:
            raise SamplingError(f"resolved parameters are not JSON-serializable: {exc}") from exc
        return values

    def failed_constraints(self, values: ParameterValues) -> list[dict[str, str]]:
        failures: list[dict[str, str]] = []
        for constraint in self.constraints:
            passed, message = constraint.evaluate(values)
            if not passed:
                failures.append({"name": constraint.name, "message": message})
        return failures

    def sample(self, *, seed: int) -> ParameterSample:
        rng = random.Random(int(seed))
        last_failures: list[dict[str, str]] = []
        for attempt in range(1, self.max_sampling_attempts + 1):
            values = self._resolve(rng=rng, quantiles=None)
            failures = self.failed_constraints(values)
            if not failures:
                return ParameterSample(
                    values=values,
                    mode="random",
                    attempts=attempt,
                    seed=int(seed),
                )
            last_failures = failures
        raise SamplingError(
            f"failed to satisfy constraints after {self.max_sampling_attempts} attempts: "
            f"{last_failures}"
        )

    def sample_quantiles(
        self,
        quantiles: Mapping[str, float],
        *,
        mode: str = "boundary",
    ) -> ParameterSample:
        values = self._resolve(rng=None, quantiles=quantiles)
        failures = self.failed_constraints(values)
        if failures:
            raise SamplingError(f"deterministic sample violates constraints: {failures}")
        return ParameterSample(
            values=values,
            mode=mode,
            attempts=1,
            quantiles={
                name: float(quantiles.get(name, 0.5)) for name in self.stochastic_factor_names
            },
        )

    def resolve_overrides(
        self,
        overrides: Mapping[str, Any],
        *,
        quantile: float = 0.5,
        check_constraints: bool = False,
    ) -> ParameterSample:
        known = {factor.name for factor in self.factors}
        unknown = sorted(set(overrides) - known)
        if unknown:
            raise SamplingError(f"unknown parameter overrides: {unknown}")

        values: dict[str, Any] = {}
        for factor in self.factors:
            if isinstance(factor, Derived):
                value = factor.at_quantile(quantile, values)
            elif factor.name in overrides:
                value = factor.normalize_override(overrides[factor.name])
                if isinstance(factor, RelativeUniformFloat):
                    minimum, maximum = factor.bounds(values)
                    if math.isclose(value, minimum, rel_tol=1e-12, abs_tol=1e-12):
                        value = minimum
                    elif math.isclose(value, maximum, rel_tol=1e-12, abs_tol=1e-12):
                        value = maximum
            else:
                value = factor.at_quantile(quantile, values)
            values[factor.name] = value

        if check_constraints:
            failures = self.failed_constraints(values)
            if failures:
                raise SamplingError(f"parameter overrides violate constraints: {failures}")
        return ParameterSample(
            values=values,
            mode="override",
            attempts=1,
            quantiles={
                factor.name: float(quantile)
                for factor in self.factors
                if factor.stochastic and factor.name not in overrides
            },
        )

    def sample_with_ranges(
        self,
        *,
        seed: int,
        ranges: Mapping[str, Mapping[str, Any]],
    ) -> ParameterSample:
        known = {factor.name for factor in self.factors if factor.stochastic}
        unknown = sorted(set(ranges) - known)
        if unknown:
            raise SamplingError(f"unknown parameter ranges: {unknown}")

        rng = random.Random(int(seed))
        last_failures: list[dict[str, str]] = []
        for attempt in range(1, self.max_sampling_attempts + 1):
            values: dict[str, Any] = {}
            for factor in self.factors:
                config = ranges.get(factor.name)
                if isinstance(factor, Derived):
                    value = factor.sample(rng, values)
                elif config is None:
                    value = factor.sample(rng, values)
                elif isinstance(factor, (UniformFloat, RelativeUniformFloat)):
                    raw_mode = config.get("mode")
                    if raw_mode is None:
                        mode = (
                            "relative" if isinstance(factor, RelativeUniformFloat) else "absolute"
                        )
                    elif raw_mode in {"absolute", "relative"}:
                        mode = str(raw_mode)
                    else:
                        raise SamplingError(
                            f"{factor.name}: continuous sampling mode must be absolute or relative"
                        )

                    minimum_config = factor.normalize_override(config.get("minimum"))
                    maximum_config = factor.normalize_override(config.get("maximum"))
                    if minimum_config > maximum_config:
                        label = "ratio " if mode == "relative" else ""
                        raise SamplingError(
                            f"{factor.name}: sampling {label}minimum must not exceed maximum"
                        )

                    if mode == "absolute":
                        minimum, maximum = minimum_config, maximum_config
                    else:
                        raw_reference = config.get("relative_to")
                        reference_name = (
                            factor.reference
                            if raw_reference is None and isinstance(factor, RelativeUniformFloat)
                            else raw_reference
                        )
                        if not isinstance(reference_name, str) or not reference_name:
                            raise SamplingError(
                                f"{factor.name}: relative sampling requires relative_to"
                            )
                        if reference_name not in values:
                            raise SamplingError(
                                f"{factor.name}: relative_to {reference_name!r} must name an "
                                "earlier resolved factor"
                            )
                        reference_value = values[reference_name]
                        if (
                            not isinstance(reference_value, (int, float))
                            or isinstance(reference_value, bool)
                            or not math.isfinite(float(reference_value))
                        ):
                            raise SamplingError(
                                f"{factor.name}: relative_to {reference_name!r} must resolve "
                                "to a finite number"
                            )
                        if (
                            isinstance(factor, RelativeUniformFloat)
                            and reference_name == factor.reference
                        ):
                            minimum, maximum = factor.bounds_for_ratios(
                                values,
                                ratio_low=minimum_config,
                                ratio_high=maximum_config,
                            )
                        else:
                            reference = float(reference_value)
                            minimum = reference * minimum_config
                            maximum = reference * maximum_config
                            if minimum > maximum:
                                raise SamplingError(
                                    f"{factor.name}: relative sampling produced a reversed "
                                    f"interval from {reference_name}={reference:.6g}"
                                )
                    value = rng.uniform(minimum, maximum)
                elif isinstance(factor, UniformInt):
                    minimum = factor.normalize_override(config.get("minimum"))
                    maximum = factor.normalize_override(config.get("maximum"))
                    if minimum > maximum:
                        raise SamplingError(
                            f"{factor.name}: sampling minimum must not exceed maximum"
                        )
                    value = rng.randint(minimum, maximum)
                elif isinstance(factor, UniformChoice):
                    allowed = config.get("choices")
                    if not isinstance(allowed, list) or not allowed:
                        raise SamplingError(
                            f"{factor.name}: categorical ranges require non-empty choices"
                        )
                    normalized = [factor.normalize_override(choice) for choice in allowed]
                    for index, choice in enumerate(normalized):
                        if any(
                            type(choice) is type(earlier) and choice == earlier
                            for earlier in normalized[:index]
                        ):
                            raise SamplingError(
                                f"{factor.name}: categorical ranges cannot contain duplicate "
                                f"choice {choice!r}"
                            )
                    value = normalized[rng.randrange(len(normalized))]
                else:
                    raise SamplingError(
                        f"{factor.name}: custom ranges are unsupported for {type(factor).__name__}"
                    )
                values[factor.name] = value

            failures = self.failed_constraints(values)
            if not failures:
                return ParameterSample(
                    values=values,
                    mode="custom-ranges",
                    attempts=attempt,
                    seed=int(seed),
                )
            last_failures = failures
        raise SamplingError(
            f"failed to satisfy constraints after {self.max_sampling_attempts} attempts "
            f"using viewer ranges: {last_failures}"
        )

    def describe(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "name": self.name,
            "category": self.category,
            "description": self.description,
            "design": self.design.describe(),
            "factors": [factor.describe() for factor in self.factors],
            "relationships": [relationship.describe() for relationship in self.relationships],
            "constraints": [
                {"name": constraint.name, "message": constraint.message}
                for constraint in self.constraints
            ],
            "population_checks": [
                {"name": check.name, "message": check.message} for check in self.population_checks
            ],
            "task_requirements": list(self.task_requirements),
            "tags": list(self.tags),
        }
