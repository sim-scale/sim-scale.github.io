from __future__ import annotations


class AssetEngineError(Exception):
    """Base exception for AssetEngine."""


class GeneratorDefinitionError(AssetEngineError, ValueError):
    """Raised when a generator contract is structurally invalid."""


class GeneratorLoadError(AssetEngineError):
    """Raised when a generator module cannot be loaded."""


class SamplingError(AssetEngineError):
    """Raised when a valid parameter sample cannot be produced."""


class MaterializationError(AssetEngineError):
    """Raised when one parameter sample cannot be materialized."""


class MountPlacementError(AssetEngineError, ValueError):
    """Raised when a rigid component cannot be placed and trimmed as declared."""
