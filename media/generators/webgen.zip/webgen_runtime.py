"""Run the procedural generators for the interactive demo: meshes of every part in its link frame,
and the joints that mount the parts, for a parameter setting of the demo's controls."""
from __future__ import annotations

import dataclasses
import json
import math
import re
from pathlib import Path

import numpy as np

BASE = Path(__file__).resolve().parent
CATS = json.loads((BASE / "categories.json").read_text())
_REGISTRY: dict[str, object] = {}
_GENERATORS: dict[str, object] = {}


def _patch_sdk():
    """Keep generated meshes in memory instead of writing OBJ files."""
    import sdk
    from sdk._core.v0.types import Mesh

    def mesh_from_geometry(geometry, name, *args, **kwargs):
        key = f"mem:{len(_REGISTRY)}"
        _REGISTRY[key] = geometry
        return Mesh(filename=key, name=str(name))

    def mesh_from_cadquery(model, name, *args, **kwargs):
        return mesh_from_geometry(model.to_geometry(), name)

    targets = [sdk]
    for mod in ("sdk.v0", "sdk._core.v0", "sdk._core.v0._mesh", "sdk._core.v0._mesh.booleans"):
        try:
            targets.append(__import__(mod, fromlist=["x"]))
        except Exception:
            pass
    for t in targets:
        if hasattr(t, "mesh_from_geometry"):
            t.mesh_from_geometry = mesh_from_geometry
        t.mesh_from_cadquery = mesh_from_cadquery
    if "mesh_from_cadquery" not in sdk.__all__:
        sdk.__all__.append("mesh_from_cadquery")


def _widen(spec, ranges):
    def wider(f):
        low, high = ranges[f.name]
        if hasattr(f, "ratio_low"):
            return dataclasses.replace(f, ratio_low=low, ratio_high=high)
        return dataclasses.replace(f, low=low, high=high)

    factors = tuple(wider(f) if f.name in ranges else f for f in spec.factors)
    return dataclasses.replace(spec, factors=factors)


def generator(key):
    if key not in _GENERATORS:
        from assetengine.loading import load_generator

        spec = load_generator(BASE / "generators" / f"{key}.py")
        _GENERATORS[key] = _widen(spec, {k: tuple(v) for k, v in CATS[key]["ranges"].items()})
    return _GENERATORS[key]


def _resolve(spec, overrides):
    """Values of all factors. A control setting is ["q", t] (position t in the current range of the
    factor) or ["abs", v] (the value v, kept within the current range of a factor whose range depends on
    another, such as a pot height relative to its diameter)."""
    values = {}
    for factor in spec.factors:
        value = overrides.get(factor.name, ["q", 0.5])
        if isinstance(value, (list, tuple)) and len(value) == 2 and value[0] == "q":
            value = factor.at_quantile(float(value[1]), values)
        elif isinstance(value, (list, tuple)) and len(value) == 2 and value[0] == "abs":
            lo, hi = factor.bounds(values) if hasattr(factor, "bounds") else (factor.low, factor.high)
            value = min(max(float(value[1]), lo), hi)
        values[factor.name] = value
    return values


def _positions(spec, cfg, values):
    """Slider positions (0 to 1) of the shown continuous controls for resolved values."""
    by_name = {f.name: f for f in spec.factors}
    out = {}
    for p in cfg["params"]:
        f = by_name[p["factor"]]
        if p["choices"] is None and type(f).__name__ in ("UniformFloat", "RelativeUniformFloat"):
            lo, hi = f.bounds(values) if hasattr(f, "bounds") else (f.low, f.high)
            out[p["factor"]] = 0.5 if hi <= lo else min(max((float(values[p["factor"]]) - lo) / (hi - lo), 0.0), 1.0)
    return out


def _active(factor, values):
    fn = getattr(factor, "is_active", None)
    if callable(fn):
        try:
            return bool(fn(values))
        except Exception:
            return True
    conditions = getattr(factor, "active_when", ()) or ()
    return all(values.get(c.factor) in tuple(c.values) for c in conditions)


def _rpy_matrix(rpy):
    r, p, y = rpy
    cr, sr, cp, sp, cy, sy = math.cos(r), math.sin(r), math.cos(p), math.sin(p), math.cos(y), math.sin(y)
    return np.array([[cy * cp, cy * sp * sr - sy * cr, cy * sp * cr + sy * sr],
                     [sy * cp, sy * sp * sr + cy * cr, sy * sp * cr - cy * sr],
                     [-sp, cp * sr, cp * cr]])


def _primitive(geometry):
    """Vertices and triangles of a box, cylinder (along z), or sphere."""
    kind = type(geometry).__name__
    if kind == "Box":
        sx, sy, sz = (0.5 * s for s in geometry.size)
        v = np.array([[x, y, z] for x in (-sx, sx) for y in (-sy, sy) for z in (-sz, sz)], float)
        f = np.array([[0, 1, 3], [0, 3, 2], [4, 6, 7], [4, 7, 5], [0, 4, 5], [0, 5, 1],
                      [2, 3, 7], [2, 7, 6], [0, 2, 6], [0, 6, 4], [1, 5, 7], [1, 7, 3]])
        # Unshared vertices per face, so that the box renders with flat shading.
        return v[f.reshape(-1)], np.arange(36).reshape(-1, 3)
    if kind == "Cylinder":
        n, r, h = 48, geometry.radius, geometry.length
        a = np.linspace(0, 2 * math.pi, n, endpoint=False)
        ring = np.stack([r * np.cos(a), r * np.sin(a)], 1)
        bottom = np.c_[ring, np.full(n, -h / 2)]
        top = np.c_[ring, np.full(n, h / 2)]
        v = np.vstack([bottom, top, bottom, top, [[0, 0, -h / 2], [0, 0, h / 2]]])
        f = []
        for i in range(n):
            j = (i + 1) % n
            f += [[i, j, n + j], [i, n + j, n + i]]
            f += [[4 * n, 2 * n + j, 2 * n + i], [4 * n + 1, 3 * n + i, 3 * n + j]]
        return v, np.array(f)
    if kind == "Sphere":
        r, nu, nv = geometry.radius, 32, 16
        v, f = [], []
        for i in range(nv + 1):
            t = math.pi * i / nv
            for j in range(nu):
                p = 2 * math.pi * j / nu
                v.append([r * math.sin(t) * math.cos(p), r * math.sin(t) * math.sin(p), r * math.cos(t)])
        for i in range(nv):
            for j in range(nu):
                a, b = i * nu + j, i * nu + (j + 1) % nu
                f += [[a, a + nu, b], [b, a + nu, b + nu]]
        return np.array(v, float), np.array(f)
    raise TypeError(kind)


def _geometry_arrays(geometry):
    kind = type(geometry).__name__
    if kind == "Mesh":
        g = _REGISTRY.get(geometry.filename)
        if g is None:
            g = geometry.source_geometry
        v = np.asarray(g.vertices, float).reshape(-1, 3)
        f = np.asarray(g.faces, np.int64).reshape(-1, 3)
        if geometry.scale is not None:
            v = v * np.asarray(geometry.scale, float)
        return v, f
    return _primitive(geometry)


def describe(key):
    """Controls of one category: its major parameters, as in the paper figures."""
    spec = generator(key)
    cfg = CATS[key]
    by_name = {f.name: f for f in spec.factors}
    controls = []
    label_of = {p["factor"]: p["label"] for p in cfg["params"]}
    group_of = {label: g["title"] for g in cfg.get("groups", []) for label in g["labels"]}
    for p in cfg["params"]:
        f = by_name[p["factor"]]
        kind = type(f).__name__
        shown = by_name.get(p.get("display") or p["factor"], f)
        item = {"label": p["label"], "factor": p["factor"], "unit": getattr(shown, "unit", None) or "",
                "derived": bool(p.get("display")), "relative": kind == "RelativeUniformFloat",
                "group": group_of.get(p["label"], cfg["title"])}
        if kind == "RelativeUniformFloat":
            ref = f.reference
            # The shown control for the reference, also when it is a variant of it (tall_neck_outer_diameter
            # for neck_outer_diameter); otherwise the reference name in words.
            match = label_of.get(ref) or next((l for fac, l in label_of.items() if fac.endswith(ref)), None)
            item["relative_to"] = match or ref.replace("_", " ").strip()
        if p["choices"] is not None:
            item.update(kind="choice", values=p["values"], labels=p["choices"])
        elif kind == "UniformInt":
            item.update(kind="int", low=f.low, high=f.high)
        else:
            item.update(kind="float")
        controls.append(item)
    order = [g["title"] for g in cfg.get("groups", [])]
    return {"key": key, "title": cfg["title"], "controls": controls, "view": cfg["view"], "groups": order}


def build(key, settings, fallback=None):
    """Build with the requested settings. When the generator rejects them (its own validity checks fail,
    as for some handle placements at the ends of the widened ranges), move the continuous controls from
    the last accepted settings (fallback) toward the request, and build the closest accepted setting."""
    try:
        out = _build_once(key, settings)
        out["adjusted"] = None
        return out
    except Exception as error:
        if not fallback:
            raise
        reason = str(error).strip().split("\n")[-1][:160]
    spec, cfg = generator(key), CATS[key]
    overrides = dict(cfg["base"])
    overrides.update(settings)
    wanted = _positions(spec, cfg, _resolve(spec, overrides))
    start = {k: float(v[1]) for k, v in fallback.items() if isinstance(v, list) and v and v[0] == "q"}
    choices = {k: v for k, v in settings.items() if not (isinstance(v, list) and v and v[0] in ("q", "abs"))}

    def mix(alpha):
        mixed = dict(settings)
        mixed.update(choices)
        for k, t in wanted.items():
            t0 = start.get(k, t)
            mixed[k] = ["q", t0 + alpha * (t - t0)]
        return mixed

    best, lo, hi = None, 0.0, 1.0
    try:
        best = (_build_once(key, mix(0.0)), mix(0.0))
    except Exception:
        out = _build_once(key, fallback)  # The new choice is rejected at these sizes: keep the last shape.
        out["adjusted"] = {"settings": fallback, "reason": reason, "reverted": True}
        return out
    for _ in range(7):
        mid = (lo + hi) / 2
        try:
            best = (_build_once(key, mix(mid)), mix(mid))
            lo = mid
        except Exception:
            hi = mid
    out, used = best
    out["adjusted"] = {"settings": used, "reason": reason, "reverted": False}
    return out


def _build_once(key, settings):
    spec = generator(key)
    cfg = CATS[key]
    overrides = {k: v for k, v in cfg["base"].items()}
    overrides.update(settings)
    values = _resolve(spec, overrides)
    _REGISTRY.clear()
    model = spec.build(values)
    accent = [(name, re.compile(rx)) for name, rx in cfg["accent"].items()]
    parts = []
    pieces = []
    for part in model.parts:
        for i, visual in enumerate(part.visuals):
            v, f = _geometry_arrays(visual.geometry)
            if len(f) == 0:
                continue
            o = visual.origin
            v = v @ _rpy_matrix(o.rpy).T + np.asarray(o.xyz, float)
            label = f"{part.name}/{visual.name or i}"
            finish = next((n for n, rx in accent if rx.search(label)), "body")
            pieces.append((part.name, label, finish, v, f))
    if cfg.get("decal") and pieces:
        # Paper-thin slabs, such as printed burner zones and touch buttons, take a darker shade (as in the
        # paper figures), so that they show on the surface they mark.
        allv = np.concatenate([p[3] for p in pieces])
        size = float(np.linalg.norm(allv.max(0) - allv.min(0)))
        marked = []
        for link, label, finish, v, f in pieces:
            extent = np.sort(v.max(0) - v.min(0))
            if finish == "body" and 2e-5 * size < extent[0] < .0025 * size and extent[0] < .05 * extent[1]:
                finish = "decal"
            marked.append((link, label, finish, v, f))
        pieces = marked
    for link, label, finish, v, f in pieces:
        parts.append({"link": link, "name": label, "finish": finish,
                      "positions": v.astype(np.float32).tobytes(),
                      "indices": f.astype(np.uint32).tobytes()})
    joints = []
    for a in model.articulations:
        t = a.articulation_type
        t = getattr(t, "value", t)
        lim = a.motion_limits
        joints.append({"parent": a.parent, "child": a.child, "type": str(t).lower(),
                       "xyz": list(a.origin.xyz), "rpy": list(a.origin.rpy), "axis": list(a.axis),
                       "lower": None if lim is None or lim.lower is None else float(lim.lower),
                       "upper": None if lim is None or lim.upper is None else float(lim.upper)})
    by_name = {f.name: f for f in spec.factors}
    shown = {}
    for p in cfg["params"]:
        f = by_name[p["factor"]]
        entry = {"active": _active(f, values), "value": values.get(p.get("display") or p["factor"])}
        if p["choices"] is None and type(f).__name__ in ("UniformFloat", "RelativeUniformFloat"):
            lo, hi = (f.bounds(values) if hasattr(f, "bounds") else (f.low, f.high))
            v = float(values[p["factor"]])
            entry.update(low=float(lo), high=float(hi), position=v,
                         t=0.5 if hi <= lo else min(max((v - lo) / (hi - lo), 0.0), 1.0))
        shown[p["factor"]] = entry
    return {"parts": parts, "joints": joints, "controls": shown}
