"""The small part of CadQuery that the refrigerator generator uses (boxes, translation, mirroring,
union, and cut), built on manifold, which also runs in the browser."""
from __future__ import annotations

import manifold3d
import numpy as np


class Workplane:
    def __init__(self, plane="XY", solid=None):
        self._solid = solid if solid is not None else manifold3d.Manifold()

    def box(self, length, width, height, centered=True):
        cube = manifold3d.Manifold.cube((float(length), float(width), float(height)), center=bool(centered))
        return Workplane(solid=self._solid + cube)

    def translate(self, vector):
        return Workplane(solid=self._solid.translate(tuple(float(v) for v in vector)))

    def mirror(self, plane="XY", *args, **kwargs):
        normal = {"XY": (0.0, 0.0, 1.0), "YZ": (1.0, 0.0, 0.0), "XZ": (0.0, 1.0, 0.0), "ZX": (0.0, 1.0, 0.0)}[plane]
        return Workplane(solid=self._solid.mirror(normal))

    def union(self, other, *args, **kwargs):
        return Workplane(solid=self._solid + other._solid)

    def cut(self, other, *args, **kwargs):
        return Workplane(solid=self._solid - other._solid)

    def to_geometry(self):
        from sdk import MeshGeometry

        mesh = self._solid.to_mesh()
        v = np.asarray(mesh.vert_properties, float)[:, :3]
        f = np.asarray(mesh.tri_verts, np.int64)
        return MeshGeometry(vertices=[tuple(p) for p in v], faces=[tuple(t) for t in f])
