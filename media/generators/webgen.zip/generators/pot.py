from __future__ import annotations

import math
from typing import Any, Mapping, Sequence

import manifold3d
import numpy as np

from assetengine import (
    ActiveWhen,
    Constraint,
    Derived,
    GeneratorDesign,
    GeneratorSpec,
    PopulationCheck,
    RelativeUniformFloat,
    RigidMount,
    UniformChoice,
    UniformFloat,
)
from assetengine.articraft import (
    ArticulatedObject,
    CylinderGeometry,
    ExtrudeGeometry,
    LatheGeometry,
    MeshGeometry,
    Origin,
    PipeGeometry,
    TestContext,
    mesh_from_geometry,
)

_RADIAL_SEGMENTS = 64
_WALL_SAMPLES = 12
_BEND_SEGMENTS = 14
_ROOT_STOCK = 0.025
_ROOT_OVERLAP = 0.004
_BODY_CLEARANCE = 0.004
_MOUNT_EDGE_MARGIN = 0.004
_SERIALIZED_VERTEX_STEP = 3e-6


def _as_manifold(geometry: MeshGeometry, *, context: str) -> manifold3d.Manifold:
    mesh = manifold3d.Mesh(
        np.asarray(geometry.vertices, dtype=np.float32),
        np.asarray(geometry.faces, dtype=np.uint32),
    )
    solid = manifold3d.Manifold(mesh)
    if solid.status() != manifold3d.Error.NoError:
        raise ValueError(f"{context} is not a valid manifold solid")
    return solid


def _mesh_from_manifold(solid: manifold3d.Manifold) -> MeshGeometry:
    output = solid.to_mesh()
    return MeshGeometry(
        vertices=[tuple(float(value) for value in row[:3]) for row in output.vert_properties],
        faces=[tuple(int(value) for value in row) for row in output.tri_verts],
    )


def _to_parent_frame(geometry: MeshGeometry, origin: Origin) -> MeshGeometry:
    roll, pitch, yaw = origin.rpy
    return (
        geometry.copy()
        .rotate_x(float(roll))
        .rotate_y(float(pitch))
        .rotate_z(float(yaw))
        .translate(*origin.xyz)
    )


def _to_child_frame(geometry: MeshGeometry, origin: Origin) -> MeshGeometry:
    roll, pitch, yaw = origin.rpy
    return (
        geometry.copy()
        .translate(*(-float(value) for value in origin.xyz))
        .rotate_z(-float(yaw))
        .rotate_y(-float(pitch))
        .rotate_x(-float(roll))
    )


def _regularize_serialized_mesh(geometry: MeshGeometry) -> MeshGeometry:
    """Keep distinct Boolean vertices distinct after six-decimal OBJ serialization."""
    vertices = np.asarray(geometry.vertices, dtype=float).copy()
    faces = np.asarray(geometry.faces, dtype=np.uint32)

    # Articraft serializes OBJ positions to six decimal places. Rare Boolean
    # boundary vertices can then collapse onto one coordinate and be welded by
    # importers. Separate only those serialization-equivalent vertices along the
    # handle's local tangential axis, well below the modeled dimensional scale.
    for _ in range(6):
        _, inverse, counts = np.unique(
            np.round(vertices, 6),
            axis=0,
            return_inverse=True,
            return_counts=True,
        )
        duplicate_groups = np.flatnonzero(counts > 1)
        if len(duplicate_groups) == 0:
            break
        for group in duplicate_groups:
            indices = np.flatnonzero(inverse == group)
            offsets = (
                np.arange(len(indices), dtype=float) - 0.5 * (len(indices) - 1)
            ) * _SERIALIZED_VERTEX_STEP
            vertices[indices, 1] += offsets
    else:
        raise ValueError("could not preserve trimmed mesh vertices during serialization")

    return MeshGeometry(
        vertices=[tuple(float(value) for value in row) for row in vertices],
        faces=[tuple(int(value) for value in row) for row in faces],
    )


def _trim_root_stock(
    *,
    body_geometry: MeshGeometry,
    cutter_geometry: MeshGeometry,
    extended_leg_local: MeshGeometry,
    parent_from_child: Origin,
    component_name: str,
    minimum_witness_volume: float,
) -> MeshGeometry:
    """Trim one handle root at the filled pot envelope and retain its exterior leg."""
    positioned = _to_parent_frame(extended_leg_local, parent_from_child)
    positioned_solid = _as_manifold(positioned, context=f"positioned {component_name}")
    body_solid = _as_manifold(body_geometry, context="pot body")
    body_witness = float((positioned_solid ^ body_solid).volume())
    if body_witness < minimum_witness_volume:
        raise ValueError(f"{component_name} did not positively intersect the pot wall")

    cutter_solid = _as_manifold(cutter_geometry, context="filled pot envelope")
    cutter_witness = float((positioned_solid ^ cutter_solid).volume())
    if cutter_witness < minimum_witness_volume:
        raise ValueError(f"{component_name} stock did not enter the filled pot envelope")

    components = list((positioned_solid - cutter_solid).decompose())
    if not components:
        raise ValueError(f"trimming removed the complete {component_name}")
    exterior = max(
        components,
        key=lambda component: max(
            vertex[0]
            for vertex in _to_child_frame(
                _mesh_from_manifold(component),
                parent_from_child,
            ).vertices
        ),
    )
    exterior_parent = _mesh_from_manifold(exterior)
    final_body_overlap = float(
        (_as_manifold(exterior_parent, context=f"trimmed {component_name}") ^ body_solid).volume()
    )
    final_cutter_overlap = float(
        (_as_manifold(exterior_parent, context=f"trimmed {component_name}") ^ cutter_solid).volume()
    )
    if final_body_overlap > 1e-8 or final_cutter_overlap > 1e-8:
        raise ValueError(f"trimmed {component_name} retained sacrificial stock")
    return _regularize_serialized_mesh(_to_child_frame(exterior_parent, parent_from_child))


def _outer_radius(
    pot_radius: float,
    bottom_inset: float,
    height_fraction: float,
    wall_profile: str,
) -> float:
    if wall_profile == "rounded_transition":
        progression = math.sin(0.5 * math.pi * height_fraction)
    else:
        progression = height_fraction
    return pot_radius - bottom_inset + bottom_inset * progression


def _pot_body_geometry(parameters: Mapping[str, Any]) -> LatheGeometry:
    radius = 0.5 * float(parameters["pot_diameter"])
    height = float(parameters["pot_height"])
    wall = float(parameters["wall_thickness"])
    base = float(parameters["base_thickness"])
    inset = float(parameters["bottom_inset"])
    rim_flare = float(parameters["rim_flare"])
    profile_kind = str(parameters["wall_profile"])

    profile: list[tuple[float, float]] = [(0.0, 0.0)]
    for index in range(_WALL_SAMPLES + 1):
        fraction = index / _WALL_SAMPLES
        profile.append(
            (
                _outer_radius(radius, inset, fraction, profile_kind),
                height * fraction,
            )
        )
    profile.append((radius + rim_flare, height))
    profile.append((radius - wall, height))
    for index in range(_WALL_SAMPLES - 1, -1, -1):
        fraction = index / _WALL_SAMPLES
        profile.append(
            (
                _outer_radius(radius, inset, fraction, profile_kind) - wall,
                base + (height - base) * fraction,
            )
        )
    profile.append((0.0, base))
    return LatheGeometry(profile, segments=_RADIAL_SEGMENTS, closed=True)


def _pot_mount_cutter_geometry(parameters: Mapping[str, Any]) -> LatheGeometry:
    radius = 0.5 * float(parameters["pot_diameter"])
    height = float(parameters["pot_height"])
    inset = float(parameters["bottom_inset"])
    rim_flare = float(parameters["rim_flare"])
    profile_kind = str(parameters["wall_profile"])

    profile: list[tuple[float, float]] = [(0.0, 0.0)]
    for index in range(_WALL_SAMPLES + 1):
        fraction = index / _WALL_SAMPLES
        profile.append(
            (
                _outer_radius(radius, inset, fraction, profile_kind),
                height * fraction,
            )
        )
    profile.extend(((radius + rim_flare, height), (0.0, height)))
    return LatheGeometry(profile, segments=_RADIAL_SEGMENTS, closed=True)


def _surface_radius_at_height(parameters: Mapping[str, Any], height: float) -> float:
    pot_height = float(parameters["pot_height"])
    return _outer_radius(
        0.5 * float(parameters["pot_diameter"]),
        float(parameters["bottom_inset"]),
        min(1.0, max(0.0, height / pot_height)),
        str(parameters["wall_profile"]),
    )


def _surface_x_at_height(
    parameters: Mapping[str, Any],
    height: float,
    tangent_offset: float = 0.0,
) -> float:
    radius = _surface_radius_at_height(parameters, height)
    offset = min(abs(float(tangent_offset)), radius)
    return math.sqrt(max(0.0, radius * radius - offset * offset))


def _resolved_mount_height(parameters: Mapping[str, Any]) -> float:
    height = float(parameters["pot_height"])
    base = float(parameters["base_thickness"])
    thickness = _handle_vertical_thickness(parameters)
    rise = float(parameters["handle_rise_angle"])
    target = height - float(parameters["handle_rim_offset"])
    lower = base + _MOUNT_EDGE_MARGIN + 0.5 * thickness
    upper = height - 0.001 - 0.5 * thickness * math.cos(rise)
    return min(max(target, lower), upper)


def _handle_vertical_thickness(parameters: Mapping[str, Any]) -> float:
    construction = str(parameters["handle_construction"])
    if construction == "open_band_loop":
        return float(parameters["band_vertical_thickness"])
    if construction == "open_tubular_loop":
        return float(parameters["tube_diameter"])
    return float(parameters["solid_grip_vertical_thickness"])


def _open_member_width(parameters: Mapping[str, Any]) -> float:
    if parameters["handle_construction"] == "open_band_loop":
        return float(parameters["band_member_width"])
    return float(parameters["tube_diameter"])


def _root_span(parameters: Mapping[str, Any]) -> float:
    outside_span = float(parameters["handle_outer_span"])
    if parameters["handle_construction"] == "solid_grip":
        return outside_span * float(parameters["solid_grip_root_width_ratio"])
    return outside_span


def _mount_origin_x(parameters: Mapping[str, Any]) -> float:
    mount_z = float(parameters["handle_mount_height"])
    thickness = _handle_vertical_thickness(parameters)
    rise = float(parameters["handle_rise_angle"])
    root_half_span = 0.5 * _root_span(parameters)
    lower_z = mount_z - 0.5 * thickness * math.cos(rise)
    radial_allowance = 0.5 * thickness * math.sin(rise)
    return (
        _surface_x_at_height(parameters, lower_z, root_half_span) - radial_allowance - _ROOT_OVERLAP
    )


def _surface_exit_local_x(
    parameters: Mapping[str, Any],
    *,
    local_z: float,
    tangent_offset: float,
) -> float:
    origin_x = _mount_origin_x(parameters)
    mount_z = float(parameters["handle_mount_height"])
    rise = float(parameters["handle_rise_angle"])
    cosine = math.cos(rise)
    sine = math.sin(rise)

    def clearance(local_x: float) -> float:
        point_x = origin_x + local_x * cosine - local_z * sine
        point_z = mount_z + local_x * sine + local_z * cosine
        return point_x - _surface_x_at_height(parameters, point_z, tangent_offset)

    if clearance(0.0) >= 0.0:
        return 0.0
    outside = 0.01
    while clearance(outside) < 0.0 and outside < 0.25:
        outside *= 2.0
    if clearance(outside) < 0.0:
        raise ValueError("handle root could not exit the pot envelope")
    inside = 0.0
    for _ in range(36):
        midpoint = 0.5 * (inside + outside)
        if clearance(midpoint) >= 0.0:
            outside = midpoint
        else:
            inside = midpoint
    return outside


def _handle_geometry_length(parameters: Mapping[str, Any]) -> float:
    return _surface_exit_local_x(parameters, local_z=0.0, tangent_offset=0.0) + float(
        parameters["handle_reach"]
    )


def _append_arc(
    points: list[tuple[float, float]],
    *,
    center_x: float,
    center_y: float,
    radius: float,
    start_angle: float,
    end_angle: float,
) -> None:
    for index in range(1, _BEND_SEGMENTS + 1):
        angle = start_angle + (end_angle - start_angle) * index / _BEND_SEGMENTS
        points.append(
            (
                center_x + radius * math.cos(angle),
                center_y + radius * math.sin(angle),
            )
        )


def _bridge_start(
    length: float,
    outside_span: float,
    member_width: float,
    roundness: float,
) -> float:
    return length - max(member_width, 0.5 * outside_span * roundness)


def _tube_bridge_start(
    length: float,
    outside_span: float,
    diameter: float,
    roundness: float,
) -> float:
    center_half_span = 0.5 * (outside_span - diameter)
    bend_radius = center_half_span * roundness
    return length - 0.5 * diameter - bend_radius


def _bridge_profile(
    length: float,
    outside_span: float,
    member_width: float,
    roundness: float,
) -> list[tuple[float, float]]:
    outer_half = 0.5 * outside_span
    inner_half = outer_half - member_width
    outer_radius = outer_half * roundness
    inner_radius = max(0.0, outer_radius - member_width)
    start = _bridge_start(length, outside_span, member_width, roundness)

    points: list[tuple[float, float]] = [(start, -outer_half)]
    if outer_radius <= 1e-12:
        points.extend(((length, -outer_half), (length, outer_half)))
    else:
        center_x = length - outer_radius
        points.append((center_x, -outer_half))
        _append_arc(
            points,
            center_x=center_x,
            center_y=-outer_half + outer_radius,
            radius=outer_radius,
            start_angle=-0.5 * math.pi,
            end_angle=0.0,
        )
        points.append((length, outer_half - outer_radius))
        _append_arc(
            points,
            center_x=center_x,
            center_y=outer_half - outer_radius,
            radius=outer_radius,
            start_angle=0.0,
            end_angle=0.5 * math.pi,
        )
    points.extend(((start, outer_half), (start, inner_half)))
    if inner_radius > 1e-12:
        center_x = length - outer_radius
        points.append((center_x, inner_half))
        _append_arc(
            points,
            center_x=center_x,
            center_y=inner_half - inner_radius,
            radius=inner_radius,
            start_angle=0.5 * math.pi,
            end_angle=0.0,
        )
        points.append((length - member_width, -inner_half + inner_radius))
        _append_arc(
            points,
            center_x=center_x,
            center_y=-inner_half + inner_radius,
            radius=inner_radius,
            start_angle=0.0,
            end_angle=-0.5 * math.pi,
        )
    points.append((start, -inner_half))
    return points


def _leg_geometry(
    length: float,
    member_width: float,
    thickness: float,
    center_y: float,
    *,
    root_stock: float,
) -> MeshGeometry:
    return ExtrudeGeometry(
        (
            (-root_stock, -0.5 * member_width),
            (length, -0.5 * member_width),
            (length, 0.5 * member_width),
            (-root_stock, 0.5 * member_width),
        ),
        thickness,
        cap=True,
        center=True,
        closed=True,
    ).translate(0.0, center_y, 0.0)


def _circle_profile(radius: float, segments: int = 16) -> list[tuple[float, float]]:
    return [
        (
            radius * math.cos(2.0 * math.pi * index / segments),
            radius * math.sin(2.0 * math.pi * index / segments),
        )
        for index in range(segments)
    ]


def _round_leg_geometry(
    length: float,
    diameter: float,
    center_y: float,
    *,
    root_stock: float,
) -> MeshGeometry:
    total_length = root_stock + length
    return (
        CylinderGeometry(
            0.5 * diameter,
            total_length,
            radial_segments=16,
            closed=True,
        )
        .rotate_y(0.5 * math.pi)
        .translate(0.5 * (length - root_stock), center_y, 0.0)
    )


def _tube_bridge_geometry(
    length: float,
    outside_span: float,
    diameter: float,
    roundness: float,
) -> MeshGeometry:
    radius = 0.5 * diameter
    center_half_span = 0.5 * (outside_span - diameter)
    bend_radius = center_half_span * roundness
    start_x = _tube_bridge_start(length, outside_span, diameter, roundness)
    distal_x = length - radius
    path: list[tuple[float, float, float]] = [(start_x, -center_half_span, 0.0)]
    lower_center_y = -center_half_span + bend_radius
    for index in range(1, _BEND_SEGMENTS + 1):
        angle = -0.5 * math.pi + 0.5 * math.pi * index / _BEND_SEGMENTS
        path.append(
            (
                start_x + bend_radius * math.cos(angle),
                lower_center_y + bend_radius * math.sin(angle),
                0.0,
            )
        )
    upper_tangent_y = center_half_span - bend_radius
    if upper_tangent_y > lower_center_y + 1e-9:
        path.append((distal_x, upper_tangent_y, 0.0))
    for index in range(1, _BEND_SEGMENTS + 1):
        angle = 0.5 * math.pi * index / _BEND_SEGMENTS
        path.append(
            (
                start_x + bend_radius * math.cos(angle),
                upper_tangent_y + bend_radius * math.sin(angle),
                0.0,
            )
        )
    return PipeGeometry(
        _circle_profile(radius),
        path,
        cap=True,
        closed=True,
        up_hint=(0.0, 0.0, 1.0),
    )


def _solid_grip_profile(
    length: float,
    root_width: float,
    outside_width: float,
    roundness: float,
    *,
    root_stock: float,
) -> list[tuple[float, float]]:
    outer_half = 0.5 * outside_width
    root_half = 0.5 * root_width
    corner_radius = outer_half * roundness
    tangent_x = length - corner_radius
    points: list[tuple[float, float]] = [
        (-root_stock, -root_half),
        (0.0, -root_half),
        (tangent_x, -outer_half),
    ]
    _append_arc(
        points,
        center_x=tangent_x,
        center_y=-outer_half + corner_radius,
        radius=corner_radius,
        start_angle=-0.5 * math.pi,
        end_angle=0.0,
    )
    points.append((length, outer_half - corner_radius))
    _append_arc(
        points,
        center_x=tangent_x,
        center_y=outer_half - corner_radius,
        radius=corner_radius,
        start_angle=0.0,
        end_angle=0.5 * math.pi,
    )
    points.extend(((0.0, root_half), (-root_stock, root_half)))
    return points


def _handle_origin(parameters: Mapping[str, Any], side: str) -> Origin:
    radial = _mount_origin_x(parameters)
    mount_z = float(parameters["handle_mount_height"])
    rise = float(parameters["handle_rise_angle"])
    if side == "right":
        return Origin(xyz=(radial, 0.0, mount_z), rpy=(0.0, -rise, 0.0))
    return Origin(xyz=(-radial, 0.0, mount_z), rpy=(0.0, -rise, math.pi))


def build_model(parameters: Mapping[str, Any]) -> ArticulatedObject:
    model = ArticulatedObject(name="ordinary_household_cooking_pot")
    neutral = model.material("neutral", rgba=(0.48, 0.50, 0.52, 1.0))
    pot = model.part("pot")

    body_geometry = _pot_body_geometry(parameters)
    cutter_geometry = _pot_mount_cutter_geometry(parameters)
    pot.visual(
        mesh_from_geometry(body_geometry, "pot_body"),
        origin=Origin(),
        material=neutral,
        name="pot_body",
    )

    construction = str(parameters["handle_construction"])
    thickness = _handle_vertical_thickness(parameters)
    outside_span = float(parameters["handle_outer_span"])
    roundness = float(parameters["handle_end_roundness"])
    geometry_length = _handle_geometry_length(parameters)

    for side in ("right", "left"):
        origin = _handle_origin(parameters, side)
        if construction == "solid_grip":
            root_span = _root_span(parameters)
            extended_grip = ExtrudeGeometry(
                _solid_grip_profile(
                    geometry_length,
                    root_span,
                    outside_span,
                    roundness,
                    root_stock=_ROOT_STOCK,
                ),
                thickness,
                cap=True,
                center=True,
                closed=True,
            )
            trimmed_grip = _trim_root_stock(
                body_geometry=body_geometry,
                cutter_geometry=cutter_geometry,
                extended_leg_local=extended_grip,
                parent_from_child=origin,
                component_name=f"{side} solid grip root",
                minimum_witness_volume=max(
                    1e-10,
                    0.05 * _ROOT_OVERLAP * root_span * thickness,
                ),
            )
            pot.visual(
                mesh_from_geometry(trimmed_grip, f"{side}_handle_grip"),
                origin=origin,
                material=neutral,
                name=f"{side}_handle_grip",
            )
            continue

        member_width = _open_member_width(parameters)
        if construction == "open_band_loop":
            bridge_start = _bridge_start(
                geometry_length,
                outside_span,
                member_width,
                roundness,
            )
        else:
            bridge_start = _tube_bridge_start(
                geometry_length,
                outside_span,
                member_width,
                roundness,
            )
        leg_center = 0.5 * (outside_span - member_width)
        witness = max(1e-10, 0.05 * _ROOT_OVERLAP * member_width * thickness)
        for root_name, center_y in (("lower", -leg_center), ("upper", leg_center)):
            if construction == "open_band_loop":
                extended_leg = _leg_geometry(
                    bridge_start,
                    member_width,
                    thickness,
                    center_y,
                    root_stock=_ROOT_STOCK,
                )
            else:
                extended_leg = _round_leg_geometry(
                    bridge_start,
                    member_width,
                    center_y,
                    root_stock=_ROOT_STOCK,
                )
            trimmed_leg = _trim_root_stock(
                body_geometry=body_geometry,
                cutter_geometry=cutter_geometry,
                extended_leg_local=extended_leg,
                parent_from_child=origin,
                component_name=f"{side} handle {root_name} root",
                minimum_witness_volume=witness,
            )
            pot.visual(
                mesh_from_geometry(trimmed_leg, f"{side}_handle_{root_name}_leg"),
                origin=origin,
                material=neutral,
                name=f"{side}_handle_{root_name}_leg",
            )
        if construction == "open_band_loop":
            bridge = ExtrudeGeometry(
                _bridge_profile(geometry_length, outside_span, member_width, roundness),
                thickness,
                cap=True,
                center=True,
                closed=True,
            )
        else:
            bridge = _tube_bridge_geometry(
                geometry_length,
                outside_span,
                member_width,
                roundness,
            )
        pot.visual(
            mesh_from_geometry(bridge, f"{side}_handle_bridge"),
            origin=origin,
            material=neutral,
            name=f"{side}_handle_bridge",
        )

    return model


def run_tests(model: ArticulatedObject, parameters: Mapping[str, Any]):
    def value(name: str) -> float:
        return float(parameters[name])

    ctx = TestContext(model)
    ctx.check_model_valid()
    construction = str(parameters["handle_construction"])
    thickness = _handle_vertical_thickness(parameters)
    checks: list[tuple[str, bool]] = [
        (
            "open-cooking-cavity-has-positive-depth",
            value("pot_height") > value("base_thickness"),
        ),
        (
            "open-rim-retains-positive-radius",
            0.5 * value("pot_diameter") > value("wall_thickness"),
        ),
        (
            "bottom-inset-stays-inside-pot-radius",
            value("bottom_inset") < 0.5 * value("pot_diameter") - value("wall_thickness"),
        ),
        (
            "handle-reach-is-transparent-target-cap",
            abs(
                value("handle_reach")
                - min(value("handle_reach_target"), 0.25 * value("pot_diameter"))
            )
            <= 1e-9,
        ),
        (
            "handle-span-is-transparent-target-cap",
            abs(
                value("handle_outer_span")
                - min(value("handle_outer_span_target"), 0.40 * value("pot_diameter"))
            )
            <= 1e-9,
        ),
        (
            "handle-mount-height-is-derived-from-rim-offset-and-root-fit",
            abs(value("handle_mount_height") - _resolved_mount_height(parameters)) <= 1e-9,
        ),
        (
            "handle-mount-keeps-bottom-edge-on-side-wall",
            value("handle_mount_height") - 0.5 * thickness
            > value("base_thickness") + 0.5 * _MOUNT_EDGE_MARGIN,
        ),
        (
            "complete-handle-root-stays-on-upper-side-wall",
            value("handle_mount_height") + 0.5 * thickness * math.cos(value("handle_rise_angle"))
            <= value("pot_height") - 0.0009,
        ),
    ]
    if construction == "solid_grip":
        checks.append(
            (
                "solid-grip-root-is-narrower-than-distal-grip",
                0.0 < _root_span(parameters) < value("handle_outer_span"),
            )
        )
    else:
        member_width = _open_member_width(parameters)
        geometry_length = _handle_geometry_length(parameters)
        if construction == "open_band_loop":
            bridge_start = _bridge_start(
                geometry_length,
                value("handle_outer_span"),
                member_width,
                value("handle_end_roundness"),
            )
        else:
            bridge_start = _tube_bridge_start(
                geometry_length,
                value("handle_outer_span"),
                member_width,
                value("handle_end_roundness"),
            )
        checks.extend(
            (
                (
                    "each-open-handle-retains-a-bounded-opening",
                    value("handle_outer_span") > 2.0 * member_width,
                ),
                (
                    "open-handle-bend-remains-outside-pot-envelope",
                    bridge_start
                    > _surface_exit_local_x(parameters, local_z=0.0, tangent_offset=0.0)
                    + _BODY_CLEARANCE,
                ),
            )
        )
    for name, passed in checks:
        ctx.check(name, passed)
    return ctx.report()


def _covers_bounds(
    samples: Sequence[Mapping[str, Any]],
    factor: str,
    *,
    minimum_at_most: float,
    maximum_at_least: float,
) -> bool:
    values = [float(sample[factor]) for sample in samples]
    return min(values) <= minimum_at_most and max(values) >= maximum_at_least


def _covers_choice(samples: Sequence[Mapping[str, Any]], factor: str, choices: set[str]) -> bool:
    return {str(sample[factor]) for sample in samples} >= choices


GENERATOR = GeneratorSpec(
    name="cooking-pot-1",
    category="cooking_pot",
    description=(
        "Ordinary round household cooking pots and stock pots with an open cooking cavity and "
        "exactly two opposed side handles; no lid, decorative form, or accessory is added."
    ),
    design=GeneratorDesign(
        coverage=(
            "Covers ordinary round household pots from compact family cooking pots through tall "
            "stock pots, including straight-tapered and rounded-transition side walls, flat "
            "cooktop bases, subtly flared rims, and paired broad-band loops, tubular loops, or "
            "solid short side grips. The continuous "
            "diameter and height-ratio envelope includes common roughly 3-16 quart proportions "
            "without splitting size aliases. Pressure cookers, cauldrons, oval/decorative bodies, "
            "Dutch-oven bail handles, lids, baskets, utensils, and unrelated accessories are "
            "excluded."
        ),
        factors=(
            "Diameter is independent, while usable body height and bottom inset scale with diameter "
            "because ordinary height bands and taper envelopes move materially with pot size. Wall, "
            "base, rim, handle member, rise, and rounding dimensions retain independent ordinary "
            "variation. Handle reach and tangential outside span begin as independent human-scale "
            "targets; explicit derived caps only remove the oversized-handle corner on small pots. "
            "An independent absolute rim offset keeps grips in the observed upper-sidewall band on "
            "both low cooking pots and tall stockpots; only each root footprint, rather than the "
            "complete risen grip, is fit-capped below the rim."
        ),
        components=(
            "The watertight lathed shell varies diameter, height, wall transition, taper, thickness, "
            "base thickness, and rim flare while preserving a real open cavity. Each of exactly two "
            "mirrored handles varies outward reach, tangential span, thickness, distal roundness, "
            "rise, and rim offset. Broad rectangular-band and round tubular open loops use two root "
            "legs and a continuous outer bridge; solid molded-style grips taper from one broad root."
        ),
        physics_and_task=(
            "The pot body is the root. Each open loop has two independently named structural roots "
            "and each solid grip has one broad finite root. Every root carries fixed inward "
            "sacrificial stock, positively intersects the curved wall, and is trimmed at a filled "
            "body envelope so no stock enters the cavity. Open-loop bridges seat to both legs. "
            "Every assembly has exactly two opposed semantic handles; bounded openings and four "
            "root footprints apply only to the open-loop families. No robot, hand, or tool clearance "
            "is inferred."
        ),
    ),
    factors=(
        UniformFloat(
            name="pot_diameter",
            low=0.18,
            high=0.32,
            description="Outside diameter at the ordinary upper side wall before rim flare.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="pot_height",
            reference="pot_diameter",
            ratio_low=0.45,
            ratio_high=0.90,
            description="Body height from flat underside to open rim, scaling across pot sizes.",
            unit="m",
        ),
        UniformChoice(
            name="wall_profile",
            choices=("straight_taper", "rounded_transition"),
            description="Outer side-wall path from the smaller base footprint to the upper wall.",
        ),
        RelativeUniformFloat(
            name="bottom_inset",
            reference="pot_diameter",
            ratio_low=0.0,
            ratio_high=0.045,
            description="Radial inset of the flat bottom footprint from the upper wall.",
            unit="m",
        ),
        UniformFloat(
            name="wall_thickness",
            low=0.0015,
            high=0.0040,
            description="Radial solid thickness of the pot side wall.",
            unit="m",
        ),
        UniformFloat(
            name="base_thickness",
            low=0.003,
            high=0.009,
            description="Vertical solid thickness beneath the cooking cavity.",
            unit="m",
        ),
        UniformFloat(
            name="rim_flare",
            low=0.0004,
            high=0.006,
            description="Outward radial extension of the reinforced or pouring rim.",
            unit="m",
        ),
        UniformChoice(
            name="handle_construction",
            choices=("open_band_loop", "open_tubular_loop", "solid_grip"),
            description=(
                "Distinct common side-handle topology and member-section construction used by "
                "both opposed handles."
            ),
        ),
        UniformFloat(
            name="handle_reach_target",
            low=0.030,
            high=0.070,
            description="Independent target exposed radial reach of each side handle.",
            unit="m",
        ),
        Derived(
            name="handle_reach",
            derive=lambda p: min(p["handle_reach_target"], 0.25 * p["pot_diameter"]),
            depends_on=("handle_reach_target", "pot_diameter"),
            description="Realized reach after the explicit small-pot proportional cap.",
            unit="m",
        ),
        UniformFloat(
            name="handle_outer_span_target",
            low=0.055,
            high=0.105,
            description="Independent target tangential outside span of each side handle.",
            unit="m",
        ),
        Derived(
            name="handle_outer_span",
            derive=lambda p: min(p["handle_outer_span_target"], 0.40 * p["pot_diameter"]),
            depends_on=("handle_outer_span_target", "pot_diameter"),
            description="Realized tangential outside span after the small-pot fit cap.",
            unit="m",
        ),
        UniformFloat(
            name="band_member_width",
            low=0.008,
            high=0.020,
            description="Tangential solid width of each broad-band loop leg and bend.",
            unit="m",
            active_when=(ActiveWhen(factor="handle_construction", values=("open_band_loop",)),),
        ),
        UniformFloat(
            name="band_vertical_thickness",
            low=0.005,
            high=0.016,
            description="Vertical thickness normal to the broad-band loop plane.",
            unit="m",
            active_when=(ActiveWhen(factor="handle_construction", values=("open_band_loop",)),),
        ),
        UniformFloat(
            name="tube_diameter",
            low=0.006,
            high=0.014,
            description="Circular cross-section diameter of each tubular loop member.",
            unit="m",
            active_when=(ActiveWhen(factor="handle_construction", values=("open_tubular_loop",)),),
        ),
        UniformFloat(
            name="solid_grip_root_width_ratio",
            low=0.45,
            high=0.80,
            description="Broad solid-grip root span relative to its tangential distal span.",
            unit="ratio",
            active_when=(ActiveWhen(factor="handle_construction", values=("solid_grip",)),),
        ),
        UniformFloat(
            name="solid_grip_vertical_thickness",
            low=0.012,
            high=0.025,
            description="Vertical thickness of each molded-style solid side grip.",
            unit="m",
            active_when=(ActiveWhen(factor="handle_construction", values=("solid_grip",)),),
        ),
        UniformFloat(
            name="handle_end_roundness",
            low=0.25,
            high=1.0,
            description="Distal corner or bend radius coordinate for the selected handle construction.",
            unit="ratio",
        ),
        UniformFloat(
            name="handle_rise_angle",
            low=0.0,
            high=math.radians(40.0),
            description="Upward angle of both opposed handles from horizontal, up to 40 degrees.",
            unit="rad",
        ),
        UniformFloat(
            name="handle_rim_offset",
            low=0.008,
            high=0.030,
            description="Absolute vertical offset from the open rim to each handle root center.",
            unit="m",
        ),
        Derived(
            name="handle_mount_height",
            derive=_resolved_mount_height,
            depends_on=(
                "handle_construction",
                "handle_rim_offset",
                "pot_height",
                "base_thickness",
                "band_vertical_thickness",
                "tube_diameter",
                "solid_grip_vertical_thickness",
                "handle_rise_angle",
            ),
            description="Realized upper-sidewall height after transparent finite-root fit caps.",
            unit="m",
        ),
    ),
    relationships=(
        RigidMount(
            name="right-handle-lower-root-mounted-to-pot",
            parent_part="pot",
            parent_element="pot_body",
            child_part="pot",
            child_element="right_handle_lower_leg",
            active_when=(
                ActiveWhen(
                    factor="handle_construction",
                    values=("open_band_loop", "open_tubular_loop"),
                ),
            ),
        ),
        RigidMount(
            name="right-handle-upper-root-mounted-to-pot",
            parent_part="pot",
            parent_element="pot_body",
            child_part="pot",
            child_element="right_handle_upper_leg",
            active_when=(
                ActiveWhen(
                    factor="handle_construction",
                    values=("open_band_loop", "open_tubular_loop"),
                ),
            ),
        ),
        RigidMount(
            name="right-handle-bridge-mounted-to-lower-leg",
            parent_part="pot",
            parent_element="right_handle_lower_leg",
            child_part="pot",
            child_element="right_handle_bridge",
            active_when=(
                ActiveWhen(
                    factor="handle_construction",
                    values=("open_band_loop", "open_tubular_loop"),
                ),
            ),
        ),
        RigidMount(
            name="right-handle-bridge-mounted-to-upper-leg",
            parent_part="pot",
            parent_element="right_handle_upper_leg",
            child_part="pot",
            child_element="right_handle_bridge",
            active_when=(
                ActiveWhen(
                    factor="handle_construction",
                    values=("open_band_loop", "open_tubular_loop"),
                ),
            ),
        ),
        RigidMount(
            name="left-handle-lower-root-mounted-to-pot",
            parent_part="pot",
            parent_element="pot_body",
            child_part="pot",
            child_element="left_handle_lower_leg",
            active_when=(
                ActiveWhen(
                    factor="handle_construction",
                    values=("open_band_loop", "open_tubular_loop"),
                ),
            ),
        ),
        RigidMount(
            name="left-handle-upper-root-mounted-to-pot",
            parent_part="pot",
            parent_element="pot_body",
            child_part="pot",
            child_element="left_handle_upper_leg",
            active_when=(
                ActiveWhen(
                    factor="handle_construction",
                    values=("open_band_loop", "open_tubular_loop"),
                ),
            ),
        ),
        RigidMount(
            name="left-handle-bridge-mounted-to-lower-leg",
            parent_part="pot",
            parent_element="left_handle_lower_leg",
            child_part="pot",
            child_element="left_handle_bridge",
            active_when=(
                ActiveWhen(
                    factor="handle_construction",
                    values=("open_band_loop", "open_tubular_loop"),
                ),
            ),
        ),
        RigidMount(
            name="left-handle-bridge-mounted-to-upper-leg",
            parent_part="pot",
            parent_element="left_handle_upper_leg",
            child_part="pot",
            child_element="left_handle_bridge",
            active_when=(
                ActiveWhen(
                    factor="handle_construction",
                    values=("open_band_loop", "open_tubular_loop"),
                ),
            ),
        ),
        RigidMount(
            name="right-solid-grip-mounted-to-pot",
            parent_part="pot",
            parent_element="pot_body",
            child_part="pot",
            child_element="right_handle_grip",
            active_when=(ActiveWhen(factor="handle_construction", values=("solid_grip",)),),
        ),
        RigidMount(
            name="left-solid-grip-mounted-to-pot",
            parent_part="pot",
            parent_element="pot_body",
            child_part="pot",
            child_element="left_handle_grip",
            active_when=(ActiveWhen(factor="handle_construction", values=("solid_grip",)),),
        ),
    ),
    constraints=(
        Constraint(
            name="handle-loop-retains-opening",
            predicate=lambda p: (
                p["handle_construction"] == "solid_grip"
                or p["handle_outer_span"] > 2.0 * _open_member_width(p)
            ),
            message="The two U-loop legs must leave a positive tangential opening.",
        ),
        Constraint(
            name="handle-bend-starts-outside-body",
            predicate=lambda p: (
                p["handle_construction"] == "solid_grip"
                or (
                    p["handle_reach"]
                    > (
                        max(
                            p["band_member_width"],
                            0.5 * p["handle_outer_span"] * p["handle_end_roundness"],
                        )
                        if p["handle_construction"] == "open_band_loop"
                        else 0.5 * p["tube_diameter"]
                        + 0.5
                        * (p["handle_outer_span"] - p["tube_diameter"])
                        * p["handle_end_roundness"]
                    )
                    + _BODY_CLEARANCE
                )
            ),
            message="The distal handle bend must start beyond the curved pot envelope.",
        ),
        Constraint(
            name="mount-target-has-valid-fit-interval",
            predicate=lambda p: (
                p["base_thickness"] + _MOUNT_EDGE_MARGIN + 0.5 * _handle_vertical_thickness(p)
                < p["pot_height"]
                - 0.001
                - 0.5 * _handle_vertical_thickness(p) * math.cos(p["handle_rise_angle"])
            ),
            message="The pot wall must have a positive safe interval for the paired handles.",
        ),
    ),
    population_checks=(
        PopulationCheck(
            name="covers-household-pot-diameters",
            predicate=lambda samples: _covers_bounds(
                samples,
                "pot_diameter",
                minimum_at_most=0.182,
                maximum_at_least=0.318,
            ),
            message="Population must cover compact and large ordinary household diameters.",
        ),
        PopulationCheck(
            name="covers-pot-height-ratios",
            predicate=lambda samples: _covers_bounds(
                [{"ratio": sample["pot_height"] / sample["pot_diameter"]} for sample in samples],
                "ratio",
                minimum_at_most=0.46,
                maximum_at_least=0.89,
            ),
            message="Population must cover lower cooking pots and tall stock-pot proportions.",
        ),
        PopulationCheck(
            name="covers-common-wall-paths",
            predicate=lambda samples: _covers_choice(
                samples,
                "wall_profile",
                {"straight_taper", "rounded_transition"},
            ),
            message="Population must include both common side-wall transition families.",
        ),
        PopulationCheck(
            name="covers-common-handle-constructions",
            predicate=lambda samples: _covers_choice(
                samples,
                "handle_construction",
                {"open_band_loop", "open_tubular_loop", "solid_grip"},
            ),
            message="Population must cover broad-band loops, tubular loops, and solid side grips.",
        ),
        PopulationCheck(
            name="covers-handle-target-reach",
            predicate=lambda samples: _covers_bounds(
                samples,
                "handle_reach_target",
                minimum_at_most=0.031,
                maximum_at_least=0.069,
            ),
            message="Population must exercise the ordinary independent handle-reach target.",
        ),
        PopulationCheck(
            name="covers-handle-target-span",
            predicate=lambda samples: _covers_bounds(
                samples,
                "handle_outer_span_target",
                minimum_at_most=0.057,
                maximum_at_least=0.103,
            ),
            message="Population must exercise narrow and broad ordinary handle-span targets.",
        ),
        PopulationCheck(
            name="covers-family-specific-handle-sections",
            predicate=lambda samples: (
                _covers_bounds(
                    samples,
                    "band_member_width",
                    minimum_at_most=0.0085,
                    maximum_at_least=0.0195,
                )
                and _covers_bounds(
                    samples,
                    "band_vertical_thickness",
                    minimum_at_most=0.0055,
                    maximum_at_least=0.0155,
                )
                and _covers_bounds(
                    samples,
                    "tube_diameter",
                    minimum_at_most=0.0065,
                    maximum_at_least=0.0135,
                )
                and _covers_bounds(
                    samples,
                    "solid_grip_vertical_thickness",
                    minimum_at_most=0.0127,
                    maximum_at_least=0.0243,
                )
            ),
            message="Population must cover every family-specific section factor's marginal envelope.",
        ),
        PopulationCheck(
            name="covers-handle-bend-and-rise",
            predicate=lambda samples: (
                _covers_bounds(
                    samples,
                    "handle_end_roundness",
                    minimum_at_most=0.27,
                    maximum_at_least=0.98,
                )
                and _covers_bounds(
                    samples,
                    "handle_rise_angle",
                    minimum_at_most=math.radians(1.0),
                    maximum_at_least=math.radians(39.0),
                )
            ),
            message="Population must cover modestly squared through rounded and level through risen handles.",
        ),
        PopulationCheck(
            name="covers-upper-sidewall-rim-offsets",
            predicate=lambda samples: _covers_bounds(
                samples,
                "handle_rim_offset",
                minimum_at_most=0.0087,
                maximum_at_least=0.0293,
            ),
            message="Population must cover near-rim and modestly lower upper-sidewall handles.",
        ),
    ),
    build=build_model,
    tests=run_tests,
    task_requirements=(
        "The final object must be an ordinary round household cooking pot or stock pot with a real open cooking cavity.",
        "The final object must have exactly two opposed side handles and no lid or unrelated accessory.",
        "Each open-loop handle must retain a bounded opening and two independently seated wall roots; each solid grip must retain one broad finite wall root.",
    ),
    tags=("cooking pot", "stock pot", "two handles", "open vessel", "household cookware"),
)
