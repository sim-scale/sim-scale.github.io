from __future__ import annotations

import math
from typing import Any, Mapping, Sequence

from assetengine import (
    ActiveWhen,
    Constraint,
    Derived,
    GeneratorDesign,
    GeneratorSpec,
    PopulationCheck,
    RelativeUniformFloat,
    RigidMount,
    UniformChoice,
    UniformFloat,
)
from assetengine.articraft import (
    ArticulatedObject,
    Box,
    Cylinder,
    LatheGeometry,
    Material,
    Origin,
    TestContext,
    WirePolylineGeometry,
    mesh_from_geometry,
    tube_from_spline_points,
)

_SEGMENTS = 40
_MATERIAL = Material("neutral_lamp", rgba=(0.66, 0.65, 0.61, 1.0))


def _pick(parameters: Mapping[str, Any], suffix: str) -> float:
    return float(parameters[f"{parameters['construction']}_{suffix}"])


def _base_geometry(parameters: Mapping[str, Any]) -> LatheGeometry:
    radius = float(parameters["base_diameter"]) / 2.0
    height = float(parameters["base_height"])
    support_radius = float(parameters["support_radius"])
    profile_kind = str(parameters["base_profile"])
    if parameters["construction"] != "table" or profile_kind == "disc":
        profile = ((0.0, 0.0), (radius, 0.0), (radius, height), (0.0, height))
    elif profile_kind == "tapered":
        top_radius = max(radius * 0.36, support_radius * 1.35)
        profile = (
            (0.0, 0.0),
            (radius, 0.0),
            (radius, height * 0.12),
            (top_radius, height),
            (0.0, height),
        )
    else:
        top_radius = max(radius * 0.28, support_radius * 1.35)
        outer = []
        for index in range(13):
            t = index / 12.0
            eased = 3.0 * t * t - 2.0 * t * t * t
            body_radius = radius + (top_radius - radius) * eased
            outer.append((body_radius + radius * 0.10 * math.sin(math.pi * t), height * t))
        profile = ((0.0, 0.0), *outer, (0.0, height))
    return LatheGeometry(profile, segments=_SEGMENTS, closed=True)


def _shade_geometry(parameters: Mapping[str, Any], *, neck_at_top: bool) -> LatheGeometry:
    bottom_radius = float(parameters["shade_bottom_diameter"]) / 2.0
    height = float(parameters["shade_height"])
    wall = float(parameters["shade_wall_thickness"])
    socket_radius = float(parameters["socket_radius"])
    shade_top = max(
        bottom_radius * float(parameters["shade_top_diameter_ratio"]),
        socket_radius + 2.5 * wall,
    )
    inner_bottom = bottom_radius - wall
    neck_length = min(height * 0.16, 0.025)
    if neck_at_top:
        outer = (
            (bottom_radius, -height / 2.0),
            (shade_top, height / 2.0),
        )
        inner = (
            (inner_bottom, -height / 2.0),
            (shade_top - wall, height / 2.0),
        )
        return LatheGeometry.from_shell_profiles(
            outer, inner, segments=_SEGMENTS, start_cap="flat", end_cap="flat"
        )
    else:
        outer = (
            (socket_radius + wall, -height / 2.0),
            (socket_radius + wall, -height / 2.0 + neck_length),
            (shade_top, -height / 2.0 + 2.0 * neck_length),
            (bottom_radius, height / 2.0),
        )
        inner = (
            (socket_radius, -height / 2.0),
            (socket_radius, -height / 2.0 + neck_length),
            (shade_top - wall, -height / 2.0 + 2.0 * neck_length),
            (inner_bottom, height / 2.0),
        )
    return LatheGeometry.from_shell_profiles(
        outer, inner, segments=_SEGMENTS, start_cap="flat", end_cap="flat"
    )


def _add_pedestal_mount(lamp, parameters: Mapping[str, Any], shade_origin_z: float) -> None:
    height = float(parameters["shade_height"])
    wall = float(parameters["shade_wall_thickness"])
    socket_radius = float(parameters["socket_radius"])
    bottom_radius = float(parameters["shade_bottom_diameter"]) / 2.0
    shade_top = max(
        bottom_radius * float(parameters["shade_top_diameter_ratio"]),
        socket_radius + 2.5 * wall,
    )
    neck_length = min(height * 0.16, 0.025)
    collar = LatheGeometry.from_shell_profiles(
        ((socket_radius + wall, -neck_length / 2.0), (socket_radius + wall, neck_length / 2.0)),
        ((socket_radius, -neck_length / 2.0), (socket_radius, neck_length / 2.0)),
        segments=_SEGMENTS,
        start_cap="flat",
        end_cap="flat",
    )
    mount_z = shade_origin_z + height / 2.0 - neck_length / 2.0
    lamp.visual(
        mesh_from_geometry(collar, "shade_mount_collar"),
        origin=Origin(xyz=(0.0, 0.0, mount_z)),
        material=_MATERIAL,
        name="shade_mount",
    )
    spoke_t = 1.0 - neck_length / (2.0 * height)
    inner_top = (bottom_radius - wall) + (shade_top - wall - (bottom_radius - wall)) * spoke_t
    collar_outer = socket_radius + wall
    arm_length = inner_top - collar_outer + 2.0 * wall
    arm_center = (inner_top + collar_outer) / 2.0
    for name, x, y, size in (
        ("shade_spoke_x_positive", arm_center, 0.0, (arm_length, wall, wall)),
        ("shade_spoke_x_negative", -arm_center, 0.0, (arm_length, wall, wall)),
        ("shade_spoke_y_positive", 0.0, arm_center, (wall, arm_length, wall)),
        ("shade_spoke_y_negative", 0.0, -arm_center, (wall, arm_length, wall)),
    ):
        lamp.visual(
            Box(size),
            origin=Origin(xyz=(x, y, mount_z)),
            material=_MATERIAL,
            name=name,
        )


def _task_support(parameters: Mapping[str, Any]):
    base_height = float(parameters["base_height"])
    lower_height = float(parameters["support_length"])
    reach = float(parameters["task_horizontal_reach"])
    drop = reach * float(parameters["task_head_drop_ratio"])
    peak = (reach * 0.35, 0.0, base_height + lower_height + reach * 0.50)
    endpoint = (reach, 0.0, peak[2] - drop)
    points = (
        (0.0, 0.0, base_height),
        (0.0, 0.0, base_height + lower_height),
        peak,
        endpoint,
    )
    if parameters["task_support_style"] == "segmented":
        geometry = WirePolylineGeometry(
            points,
            radius=float(parameters["support_radius"]),
            radial_segments=20,
            cap_ends=True,
            corner_mode="bevel",
            up_hint=(0.0, 1.0, 0.0),
        )
    else:
        geometry = tube_from_spline_points(
            points,
            radius=float(parameters["support_radius"]),
            radial_segments=20,
            cap_ends=True,
            samples_per_segment=12,
            spline="catmull_rom",
            alpha=0.5,
            up_hint=(0.0, 1.0, 0.0),
        )
    dx, dz = endpoint[0] - peak[0], endpoint[2] - peak[2]
    length = math.hypot(dx, dz)
    return geometry, endpoint, (dx / length, 0.0, dz / length)


def build_model(parameters: Mapping[str, Any]) -> ArticulatedObject:
    model = ArticulatedObject(name="lamp")
    lamp = model.part("lamp")
    base_height = float(parameters["base_height"])
    support_length = float(parameters["support_length"])
    support_radius = float(parameters["support_radius"])
    socket_radius = float(parameters["socket_radius"])
    socket_length = float(parameters["socket_length"])
    shade_height = float(parameters["shade_height"])
    lamp.visual(
        mesh_from_geometry(_base_geometry(parameters), "lamp_base"),
        material=_MATERIAL,
        name="base",
    )
    if parameters["construction"] == "task":
        support_geometry, endpoint, direction = _task_support(parameters)
        lamp.visual(
            mesh_from_geometry(support_geometry, "task_support"),
            material=_MATERIAL,
            name="support",
        )
        tilt = math.atan2(direction[0], direction[2])
        socket_center = tuple(endpoint[i] + direction[i] * socket_length / 2.0 for i in range(3))
        shade_center = tuple(endpoint[i] + direction[i] * shade_height / 2.0 for i in range(3))
        lamp.visual(
            Cylinder(socket_radius, socket_length),
            origin=Origin(xyz=socket_center, rpy=(0.0, tilt, 0.0)),
            material=_MATERIAL,
            name="socket",
        )
        lamp.visual(
            mesh_from_geometry(_shade_geometry(parameters, neck_at_top=False), "task_shade"),
            origin=Origin(xyz=shade_center, rpy=(0.0, tilt, 0.0)),
            material=_MATERIAL,
            name="shade_shell",
        )
    elif parameters["construction"] == "floor" and parameters["floor_head_style"] == "uplight":
        support_top = base_height + support_length
        lamp.visual(
            Cylinder(support_radius, support_length),
            origin=Origin(xyz=(0.0, 0.0, base_height + support_length / 2.0)),
            material=_MATERIAL,
            name="support",
        )
        lamp.visual(
            Cylinder(socket_radius, socket_length),
            origin=Origin(xyz=(0.0, 0.0, support_top + socket_length / 2.0)),
            material=_MATERIAL,
            name="socket",
        )
        lamp.visual(
            mesh_from_geometry(_shade_geometry(parameters, neck_at_top=False), "uplight_shade"),
            origin=Origin(xyz=(0.0, 0.0, support_top + shade_height / 2.0)),
            material=_MATERIAL,
            name="shade_shell",
        )
    else:
        support_top = base_height + support_length
        lamp.visual(
            Cylinder(support_radius, support_length),
            origin=Origin(xyz=(0.0, 0.0, base_height + support_length / 2.0)),
            material=_MATERIAL,
            name="support",
        )
        lamp.visual(
            Cylinder(socket_radius, socket_length),
            origin=Origin(xyz=(0.0, 0.0, support_top + socket_length / 2.0)),
            material=_MATERIAL,
            name="socket",
        )
        shade_origin_z = support_top + socket_length - shade_height / 2.0
        lamp.visual(
            mesh_from_geometry(_shade_geometry(parameters, neck_at_top=True), "pedestal_shade"),
            origin=Origin(xyz=(0.0, 0.0, shade_origin_z)),
            material=_MATERIAL,
            name="shade_shell",
        )
        _add_pedestal_mount(lamp, parameters, shade_origin_z)
    return model


def run_tests(model: ArticulatedObject, parameters: Mapping[str, Any]):
    ctx = TestContext(model)
    ctx.check("recognized-construction", parameters["construction"] in {"table", "floor", "task"})
    ctx.check("positive-base-height", float(parameters["base_height"]) > 0.0)
    ctx.check(
        "open-shade-cavity",
        float(parameters["shade_bottom_diameter"])
        > 2.0 * float(parameters["shade_wall_thickness"]),
    )
    ctx.check(
        "shade-neck-surrounds-socket",
        float(parameters["shade_bottom_diameter"]) * float(parameters["shade_top_diameter_ratio"])
        >= 2.0 * float(parameters["socket_radius"]),
    )
    if parameters["construction"] == "task":
        ctx.check(
            "task-head-above-base",
            float(parameters["support_length"])
            + float(parameters["task_horizontal_reach"])
            * (0.50 - float(parameters["task_head_drop_ratio"]))
            > 0.08,
        )
    return ctx.report()


def _covers_choices(samples: Sequence[Mapping[str, Any]], factor: str, expected: set[str]) -> bool:
    return expected.issubset({str(sample[factor]) for sample in samples})


def _conditional_float(
    name: str,
    construction: str,
    low: float,
    high: float,
    description: str,
) -> UniformFloat:
    return UniformFloat(
        name=name,
        low=low,
        high=high,
        description=description,
        unit="m",
        active_when=(ActiveWhen(factor="construction", values=(construction,)),),
    )


GENERATOR = GeneratorSpec(
    name="lamp",
    category="lamp",
    description="Ordinary freestanding table, floor, and directed task lamps with hollow shades.",
    design=GeneratorDesign(
        coverage=(
            "Covers common table lamps (about 0.25-0.9 m, including disc, tapered, and rounded "
            "body bases), floor lamps (about 1.2-1.9 m on broad disc bases), and directed "
            "task lamps (about 0.3-0.8 m reach envelope). Floor heads include downward shades and "
            "upward torchieres; task supports include smooth goosenecks and rigid segmented paths. "
            "All retain a base, continuous support, socket housing, and hollow shade. Excludes ceiling, "
            "wall-mounted, clamp, chandelier, multi-head, novelty, and rare sculptural lamps."
        ),
        factors=(
            "Construction conditions separated envelopes. Table: base diameter 0.14-0.34 m, "
            "base/body height 0.32-0.82 of diameter, support 0.16-0.52 m, shade 0.18-0.44 m. "
            "Floor: base 0.22-0.42 m by 0.018-0.055 m, support 1.10-1.65 m, shade 0.22-0.48 m. "
            "Task: base 0.14-0.26 m by 0.018-0.05 m, rise 0.20-0.46 m, reach 0.18-0.42 m, shade "
            "0.10-0.22 m. Base, support, reach, and shade remain independent within each regime; "
            "shade height is strongly diameter-relative. A transparent table-only ratio and "
            "clearance constraint removes the residual invalid crossed boundary region while "
            "socket housing dimensions remain independent in their ordinary component envelope."
        ),
        components=(
            "Table base/body outline varies among disc, tapered, and smooth rounded profiles; "
            "floor/task bases remain low discs. Support thickness and length vary by regime, with "
            "smooth continuous or deliberately elbowed members for task lamps. Pedestal shades use "
            "open upper/lower rims and an integrated four-spoke socket carrier; directed task and "
            "uplight heads use ordinary closed-back reflector shells. Thin wall is incidental."
        ),
        physics_and_task=(
            "A planar base supports a permanent base-support-socket-shade load path. Each complete "
            "child is placed directly at its parent surface. Pedestal shade spiders and directed "
            "head collars seat along finite cylindrical socket interfaces; every shade preserves "
            "genuine light-opening free space. No robot-specific threshold is inferred."
        ),
    ),
    factors=(
        UniformChoice(
            name="construction",
            choices=("table", "floor", "task"),
            description="Separated freestanding lamp topology and scale regime.",
        ),
        UniformChoice(
            name="base_profile",
            choices=("disc", "tapered", "rounded"),
            description="Visible table-lamp base/body outline; other regimes use a disc.",
            active_when=(ActiveWhen(factor="construction", values=("table",)),),
        ),
        UniformChoice(
            name="floor_head_style",
            choices=("downshade", "uplight"),
            description="Straight floor lamp with a downward shade or upward torchiere bowl.",
            active_when=(ActiveWhen(factor="construction", values=("floor",)),),
        ),
        UniformChoice(
            name="task_support_style",
            choices=("gooseneck", "segmented"),
            description="Smooth flexible-looking neck or rigid visibly elbowed task support.",
            active_when=(ActiveWhen(factor="construction", values=("task",)),),
        ),
        _conditional_float("table_base_diameter", "table", 0.14, 0.34, "Table base diameter."),
        _conditional_float("floor_base_diameter", "floor", 0.22, 0.42, "Floor disc diameter."),
        _conditional_float("task_base_diameter", "task", 0.14, 0.26, "Task disc diameter."),
        Derived(
            name="base_diameter",
            derive=lambda p: _pick(p, "base_diameter"),
            depends_on=(
                "construction",
                "table_base_diameter",
                "floor_base_diameter",
                "task_base_diameter",
            ),
            description="Construction-selected base diameter.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="table_base_height",
            reference="table_base_diameter",
            ratio_low=0.32,
            ratio_high=0.82,
            hard_min=0.05,
            hard_max=0.28,
            description="Table base/body height relative to its diameter.",
            unit="m",
            active_when=(ActiveWhen(factor="construction", values=("table",)),),
        ),
        _conditional_float("floor_base_height", "floor", 0.018, 0.055, "Floor disc thickness."),
        _conditional_float("task_base_height", "task", 0.018, 0.050, "Task disc thickness."),
        Derived(
            name="base_height",
            derive=lambda p: _pick(p, "base_height"),
            depends_on=(
                "construction",
                "table_base_height",
                "floor_base_height",
                "task_base_height",
            ),
            description="Construction-selected base height.",
            unit="m",
        ),
        _conditional_float(
            "table_support_length", "table", 0.16, 0.52, "Table upright support length."
        ),
        _conditional_float(
            "floor_support_length", "floor", 1.10, 1.65, "Floor upright support length."
        ),
        _conditional_float("task_support_length", "task", 0.20, 0.46, "Task support initial rise."),
        Derived(
            name="support_length",
            derive=lambda p: _pick(p, "support_length"),
            depends_on=(
                "construction",
                "table_support_length",
                "floor_support_length",
                "task_support_length",
            ),
            description="Selected support length or initial rise.",
            unit="m",
        ),
        _conditional_float("table_support_radius", "table", 0.008, 0.024, "Table support radius."),
        _conditional_float("floor_support_radius", "floor", 0.006, 0.014, "Floor pole radius."),
        _conditional_float("task_support_radius", "task", 0.006, 0.012, "Task support radius."),
        Derived(
            name="support_radius",
            derive=lambda p: _pick(p, "support_radius"),
            depends_on=(
                "construction",
                "table_support_radius",
                "floor_support_radius",
                "task_support_radius",
            ),
            description="Selected support-member radius.",
            unit="m",
        ),
        UniformFloat(
            name="socket_radius",
            low=0.014,
            high=0.022,
            description="Ordinary bulb-socket housing radius, independent of pole thickness.",
            unit="m",
        ),
        UniformFloat(
            name="socket_length",
            low=0.035,
            high=0.060,
            description="Ordinary bulb-socket housing length, independent of pole thickness.",
            unit="m",
        ),
        _conditional_float(
            "table_shade_bottom_diameter", "table", 0.18, 0.44, "Table shade opening diameter."
        ),
        _conditional_float(
            "floor_shade_bottom_diameter", "floor", 0.22, 0.48, "Floor shade opening diameter."
        ),
        _conditional_float(
            "task_shade_bottom_diameter", "task", 0.10, 0.22, "Task shade opening diameter."
        ),
        Derived(
            name="shade_bottom_diameter",
            derive=lambda p: _pick(p, "shade_bottom_diameter"),
            depends_on=(
                "construction",
                "table_shade_bottom_diameter",
                "floor_shade_bottom_diameter",
                "task_shade_bottom_diameter",
            ),
            description="Selected shade main-opening diameter.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="shade_height",
            reference="shade_bottom_diameter",
            ratio_low=0.42,
            ratio_high=0.68,
            hard_min=0.055,
            hard_max=0.30,
            description="Shade axial height correlated with opening diameter.",
            unit="m",
        ),
        UniformFloat(
            name="pedestal_shade_top_diameter_ratio",
            low=0.48,
            high=1.0,
            description="Pedestal shade top-to-bottom diameter ratio.",
            unit="ratio",
            active_when=(ActiveWhen(factor="construction", values=("table", "floor")),),
        ),
        UniformFloat(
            name="task_shade_top_diameter_ratio",
            low=0.42,
            high=0.76,
            description="Task shade rear-neck to opening diameter ratio.",
            unit="ratio",
            active_when=(ActiveWhen(factor="construction", values=("task",)),),
        ),
        Derived(
            name="shade_top_diameter_ratio",
            derive=lambda p: float(
                p["task_shade_top_diameter_ratio"]
                if p["construction"] == "task"
                else p["pedestal_shade_top_diameter_ratio"]
            ),
            depends_on=(
                "construction",
                "pedestal_shade_top_diameter_ratio",
                "task_shade_top_diameter_ratio",
            ),
            description="Selected shade taper ratio.",
            unit="ratio",
        ),
        _conditional_float(
            "task_horizontal_reach", "task", 0.18, 0.42, "Task head horizontal reach."
        ),
        UniformFloat(
            name="task_head_drop_ratio",
            low=0.25,
            high=0.65,
            description="Terminal head drop divided by task reach.",
            unit="ratio",
            active_when=(ActiveWhen(factor="construction", values=("task",)),),
        ),
        Derived(
            name="shade_wall_thickness",
            derive=lambda p: max(0.0025, min(0.005, p["shade_bottom_diameter"] * 0.018)),
            depends_on=("shade_bottom_diameter",),
            description="Thin shade wall derived from shade scale.",
            unit="m",
        ),
    ),
    constraints=(
        Constraint(
            name="ordinary-table-shade-to-base-ratio",
            predicate=lambda p: (
                p["construction"] != "table"
                or 0.75 <= float(p["shade_bottom_diameter"]) / float(p["base_diameter"]) <= 2.20
            ),
            message="Table shade/base diameter ratio must stay within the ordinary joint envelope.",
        ),
        Constraint(
            name="table-shade-clears-body",
            predicate=lambda p: (
                p["construction"] != "table"
                or float(p["support_length"]) + float(p["socket_length"])
                >= float(p["shade_height"]) + 0.02
            ),
            message="Table shade lower rim must remain above the base/body.",
        ),
    ),
    relationships=(
        RigidMount(
            name="support-mounted-to-base",
            parent_part="lamp",
            parent_element="base",
            child_part="lamp",
            child_element="support",
            contact_tolerance=1e-6,
        ),
        RigidMount(
            name="socket-mounted-to-support",
            parent_part="lamp",
            parent_element="support",
            child_part="lamp",
            child_element="socket",
            contact_tolerance=1e-6,
        ),
        RigidMount(
            name="table-shade-mounted-to-socket",
            parent_part="lamp",
            parent_element="socket",
            child_part="lamp",
            child_element="shade_mount",
            contact_tolerance=1e-6,
            active_when=(ActiveWhen(factor="construction", values=("table",)),),
        ),
        RigidMount(
            name="floor-downshade-mounted-to-socket",
            parent_part="lamp",
            parent_element="socket",
            child_part="lamp",
            child_element="shade_mount",
            contact_tolerance=1e-6,
            active_when=(
                ActiveWhen(factor="construction", values=("floor",)),
                ActiveWhen(factor="floor_head_style", values=("downshade",)),
            ),
        ),
        RigidMount(
            name="uplight-shade-mounted-to-socket",
            parent_part="lamp",
            parent_element="socket",
            child_part="lamp",
            child_element="shade_shell",
            contact_tolerance=1e-6,
            active_when=(
                ActiveWhen(factor="construction", values=("floor",)),
                ActiveWhen(factor="floor_head_style", values=("uplight",)),
            ),
        ),
        RigidMount(
            name="task-shade-mounted-to-socket",
            parent_part="lamp",
            parent_element="socket",
            child_part="lamp",
            child_element="shade_shell",
            contact_tolerance=1e-6,
            active_when=(ActiveWhen(factor="construction", values=("task",)),),
        ),
    ),
    build=build_model,
    tests=run_tests,
    population_checks=(
        PopulationCheck(
            name="covers-constructions",
            predicate=lambda samples: _covers_choices(
                samples, "construction", {"table", "floor", "task"}
            ),
            message="Population must include table, floor, and task constructions.",
        ),
    ),
    task_requirements=(
        "Every lamp must have a planar freestanding base, a continuous load path to the head, "
        "and a genuine open shade cavity.",
    ),
    tags=("lamp", "table lamp", "floor lamp", "task lamp", "hollow shade"),
)
