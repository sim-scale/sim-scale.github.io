from __future__ import annotations

from math import cos, pi, sin, sqrt
from typing import Any, Mapping, Sequence

from assetengine import (
    ActiveWhen,
    Constraint,
    Derived,
    GeneratorDesign,
    GeneratorSpec,
    PopulationCheck,
    RelativeUniformFloat,
    RigidMount,
    UniformChoice,
    UniformFloat,
)
from assetengine.articraft import (
    ArticulatedObject,
    Box,
    Cylinder,
    CylinderGeometry,
    ExtrudeGeometry,
    MeshGeometry,
    Origin,
    TestContext,
    mesh_from_geometry,
)


def _resolved_long_span(parameters: Mapping[str, Any]) -> float:
    key = "low_top_long_span" if parameters["height_regime"] == "low" else "standard_top_long_span"
    return float(parameters[key])


def _resolved_height(parameters: Mapping[str, Any]) -> float:
    key = (
        "low_overall_height" if parameters["height_regime"] == "low" else "standard_overall_height"
    )
    return float(parameters[key])


def _resolved_short_span(parameters: Mapping[str, Any]) -> float:
    if parameters["top_shape"] == "round":
        return float(parameters["top_long_span"])
    return float(parameters["nonround_top_short_span"])


def _regular_frustum(
    *, top_radius: float, bottom_radius: float, height: float, sides: int, square: bool
) -> MeshGeometry:
    geometry = MeshGeometry()
    phase = pi / 4.0 if square else 0.0
    top_ring: list[int] = []
    bottom_ring: list[int] = []
    for index in range(sides):
        angle = phase + 2.0 * pi * index / sides
        top_ring.append(
            geometry.add_vertex(top_radius * cos(angle), top_radius * sin(angle), 0.5 * height)
        )
        bottom_ring.append(
            geometry.add_vertex(
                bottom_radius * cos(angle), bottom_radius * sin(angle), -0.5 * height
            )
        )
    top_center = geometry.add_vertex(0.0, 0.0, 0.5 * height)
    bottom_center = geometry.add_vertex(0.0, 0.0, -0.5 * height)
    for index in range(sides):
        following = (index + 1) % sides
        geometry.add_face(top_ring[index], bottom_ring[index], bottom_ring[following])
        geometry.add_face(top_ring[index], bottom_ring[following], top_ring[following])
        geometry.add_face(top_center, top_ring[index], top_ring[following])
        geometry.add_face(bottom_center, bottom_ring[following], bottom_ring[index])
    return geometry


def _top_geometry(parameters: Mapping[str, Any]):
    length = float(parameters["top_long_span"])
    depth = float(parameters["top_short_span"])
    thickness = float(parameters["top_thickness"])
    if parameters["top_shape"] == "rectangle":
        return Box((length, depth, thickness))
    if parameters["top_shape"] == "round":
        return Cylinder(radius=0.5 * length, length=thickness)
    geometry = CylinderGeometry(0.5, thickness, radial_segments=48)
    geometry.scale(length, depth, 1.0)
    return mesh_from_geometry(geometry, "oval_tabletop")


def _leg_geometry(parameters: Mapping[str, Any], support_height: float, name: str):
    top_size = float(parameters["leg_top_size"])
    bottom_size = top_size * float(parameters["leg_bottom_to_top_ratio"])
    is_square = parameters["leg_profile"] == "square"
    scale = sqrt(2.0) if is_square else 1.0
    geometry = _regular_frustum(
        top_radius=0.5 * top_size * scale,
        bottom_radius=0.5 * bottom_size * scale,
        height=support_height,
        sides=4 if is_square else 32,
        square=is_square,
    )
    return mesh_from_geometry(geometry, name)


def _trestle_geometry(
    *, support_height: float, member_width: float, transverse_span: float, name: str
):
    frame_width = min(0.72 * member_width, 0.14 * transverse_span)
    center_post_width = min(0.72 * member_width, 0.18 * transverse_span)
    frame_top = -(support_height - frame_width)
    profile = (
        (0.0, -0.5 * transverse_span),
        (-support_height, -0.5 * transverse_span),
        (-support_height, 0.5 * transverse_span),
        (0.0, 0.5 * transverse_span),
        (0.0, 0.5 * transverse_span - frame_width),
        (frame_top, 0.5 * transverse_span - frame_width),
        (frame_top, 0.5 * center_post_width),
        (0.0, 0.5 * center_post_width),
        (0.0, -0.5 * center_post_width),
        (frame_top, -0.5 * center_post_width),
        (frame_top, -0.5 * transverse_span + frame_width),
        (0.0, -0.5 * transverse_span + frame_width),
    )
    geometry = ExtrudeGeometry(profile, member_width)
    geometry.rotate_y(0.5 * pi)
    return mesh_from_geometry(geometry, name)


def build_model(parameters: Mapping[str, Any]):
    model = ArticulatedObject(name="table")
    table = model.part("table")
    height = float(parameters["overall_height"])
    length = float(parameters["top_long_span"])
    depth = float(parameters["top_short_span"])
    thickness = float(parameters["top_thickness"])
    support_height = height - thickness
    table.visual(
        _top_geometry(parameters),
        origin=Origin(xyz=(0.0, 0.0, height - 0.5 * thickness)),
        name="tabletop",
    )

    if parameters["support_construction"] == "four_leg":
        top_size = float(parameters["leg_top_size"])
        inset_x = max(0.5 * top_size, float(parameters["leg_inset_ratio"]) * length)
        inset_y = max(0.5 * top_size, float(parameters["leg_inset_ratio"]) * depth)
        x_center = 0.5 * length - inset_x
        y_center = 0.5 * depth - inset_y
        if parameters["top_shape"] != "rectangle":
            x_center *= 0.68
            y_center *= 0.68
        for name, x_sign, y_sign in (
            ("leg_front_left", -1.0, -1.0),
            ("leg_front_right", 1.0, -1.0),
            ("leg_back_left", -1.0, 1.0),
            ("leg_back_right", 1.0, 1.0),
        ):
            table.visual(
                _leg_geometry(parameters, support_height, name),
                origin=Origin(xyz=(x_sign * x_center, y_sign * y_center, 0.5 * support_height)),
                name=name,
            )
    elif parameters["support_construction"] == "pedestal":
        column_span = float(parameters["pedestal_column_span"])
        base_span = float(parameters["pedestal_base_span"])
        base_thickness = float(parameters["pedestal_base_thickness"])
        column_height = support_height - base_thickness
        if parameters["pedestal_profile"] == "round":
            base_geometry = Cylinder(radius=0.5 * base_span, length=base_thickness)
            column_geometry = Cylinder(radius=0.5 * column_span, length=column_height)
        else:
            base_geometry = Box((base_span, base_span, base_thickness))
            column_geometry = Box((column_span, column_span, column_height))
        table.visual(
            base_geometry, origin=Origin(xyz=(0.0, 0.0, 0.5 * base_thickness)), name="pedestal_base"
        )
        table.visual(
            column_geometry,
            origin=Origin(xyz=(0.0, 0.0, base_thickness + 0.5 * column_height)),
            name="pedestal_column",
        )
    else:
        member_width = float(parameters["trestle_member_width"])
        transverse_span = float(parameters["trestle_transverse_span_ratio"]) * depth
        x_center = (0.5 - float(parameters["trestle_end_inset_ratio"])) * length
        if parameters["top_shape"] == "oval":
            transverse_ratio = float(parameters["trestle_transverse_span_ratio"])
            ellipse_x_at_beam_corner = 0.5 * length * sqrt(1.0 - transverse_ratio**2)
            x_center = min(x_center, ellipse_x_at_beam_corner - 0.5 * member_width - 0.001)
        for name, x in (("left_trestle", -x_center), ("right_trestle", x_center)):
            table.visual(
                _trestle_geometry(
                    support_height=support_height,
                    member_width=member_width,
                    transverse_span=transverse_span,
                    name=name,
                ),
                origin=Origin(xyz=(x, 0.0, 0.0)),
                name=name,
            )
        stretcher_length = 2.0 * x_center - member_width
        stretcher_size = 0.62 * member_width
        stretcher_height = float(parameters["trestle_stretcher_height_ratio"]) * support_height
        table.visual(
            Box((stretcher_length, stretcher_size, stretcher_size)),
            origin=Origin(xyz=(0.0, 0.0, stretcher_height)),
            name="trestle_stretcher",
        )
    return model


def run_tests(model: ArticulatedObject, parameters: Mapping[str, Any]):
    ctx = TestContext(model)
    height = float(parameters["overall_height"])
    thickness = float(parameters["top_thickness"])
    length = float(parameters["top_long_span"])
    depth = float(parameters["top_short_span"])
    ctx.check("tabletop-has-positive-support-height", height > thickness + 0.20)
    ctx.check("tabletop-long-span-is-not-shorter", length + 1e-9 >= depth)
    ctx.check("tabletop-is-broad-relative-to-thickness", depth > 5.0 * thickness)
    if parameters["support_construction"] == "four_leg":
        ctx.check(
            "four-leg-roots-fit-under-tabletop", float(parameters["leg_top_size"]) < 0.35 * depth
        )
    elif parameters["support_construction"] == "pedestal":
        ctx.check(
            "pedestal-base-remains-within-tabletop-plan",
            float(parameters["pedestal_base_span"]) < depth,
        )
    else:
        ctx.check(
            "trestle-stretcher-retains-positive-length",
            (1.0 - 2.0 * float(parameters["trestle_end_inset_ratio"])) * length
            > float(parameters["trestle_member_width"]),
        )
    return ctx.report()


def _covers_choices(samples: Sequence[Mapping[str, Any]], factor: str, choices: set[str]) -> bool:
    return {str(sample[factor]) for sample in samples} >= choices


def _covers_bounds(
    samples: Sequence[Mapping[str, Any]], factor: str, *, low_at_most: float, high_at_least: float
) -> bool:
    values = [float(sample[factor]) for sample in samples]
    return min(values) <= low_at_most and max(values) >= high_at_least


GENERATOR = GeneratorSpec(
    name="table",
    category="table",
    description="Procedural ordinary household tables spanning low and chair-height surfaces, common top plans, and four-leg, central-pedestal, or trestle support constructions.",
    design=GeneratorDesign(
        coverage=(
            "Ordinary freestanding household tables include low coffee/occasional surfaces 0.35-0.55 m high with 0.45-1.40 m long tops, and separated chair-height dining, work, cafe, and console surfaces 0.68-0.80 m high with 0.60-2.10 m long tops. Rectangle, circular, and oval plans combine with four-leg and pedestal bases; rectangular or oval tops also use common open two-end trestle frames. Circular diameters stop at 1.50 m while long non-round tops retain the 2.10 m envelope. Non-round depth is 0.32-1.05 m within 22-100% of length. Wall-mounted, folding, extending, nesting, storage, glass-only, sculptural, and outdoor picnic tables are excluded as adjacent or specialized constructions."
        ),
        factors=(
            "Height regime is a separated geometric interval rather than a product-name alias; height and long-span envelopes are conditional on it. Top shape is independent of height, while a named circular cap removes only the unsupported large-diameter tail and preserves long non-round tables. Non-round short span follows the long span through its ordinary aspect envelope and hard furniture-depth bounds. Top thickness, leg section, leg taper, and support placement vary independently subject to named fit constraints. Single pedestals require balanced top aspect and a floor base spanning both plan axes. Pedestal column/base spans scale with the top short span; trestle end inset and transverse span are ratios because those interfaces move with the tabletop footprint. All stochastic factors are uniform."
        ),
        components=(
            "The tabletop varies in rectangle, circular, or smooth oval outline, both planar spans, thickness, and two distinct vertical regimes. Four-leg frames vary square or round section, straight-to-tapered profile, section size, and inset. Pedestals vary round or square columns and matching broad floor bases. Trestles have two coherent open end frames, each with top and floor beams, paired side uprights, a central stretcher post, and two genuine openings, plus a low connecting stretcher. Edge molding, joinery hardware, aprons, finish, and small feet are incidental or construction-specific details kept out of this neutral geometry model."
        ),
        physics_and_task=(
            "The tabletop is the root of one rigid table assembly. Each of four legs seats its complete top face against the underside; a pedestal column seats between tabletop and floor base; and both trestle end-frame beams seat against the tabletop while the stretcher meets both posts. Every permanent interface has an active RigidMount. All support families terminate at a common z=0 floor plane with a broad four-point, pedestal-base, or two-foot footprint; no robot-specific stability margin is inferred."
        ),
    ),
    factors=(
        UniformChoice(
            name="height_regime",
            choices=("low", "standard"),
            description="Separated low-surface or chair-height vertical geometry regime.",
        ),
        UniformChoice(
            name="top_shape",
            choices=("rectangle", "round", "oval"),
            description="Common tabletop plan outline.",
        ),
        UniformChoice(
            name="support_construction",
            choices=("four_leg", "pedestal", "trestle"),
            description="Distinct load-bearing support topology beneath the tabletop.",
        ),
        UniformFloat(
            name="low_overall_height",
            low=0.35,
            high=0.55,
            active_when=(ActiveWhen(factor="height_regime", values=("low",)),),
            description="Floor-to-top height for low coffee and occasional tables.",
            unit="m",
        ),
        UniformFloat(
            name="standard_overall_height",
            low=0.68,
            high=0.80,
            active_when=(ActiveWhen(factor="height_regime", values=("standard",)),),
            description="Floor-to-top height for dining, cafe, work, and console tables.",
            unit="m",
        ),
        Derived(
            name="overall_height",
            derive=_resolved_height,
            depends_on=("height_regime", "low_overall_height", "standard_overall_height"),
            description="Active regime's resolved floor-to-top height.",
            unit="m",
        ),
        UniformFloat(
            name="low_top_long_span",
            low=0.45,
            high=1.40,
            active_when=(ActiveWhen(factor="height_regime", values=("low",)),),
            description="Largest plan span for low tables.",
            unit="m",
        ),
        UniformFloat(
            name="standard_top_long_span",
            low=0.60,
            high=2.10,
            active_when=(ActiveWhen(factor="height_regime", values=("standard",)),),
            description="Largest plan span for chair-height tables.",
            unit="m",
        ),
        Derived(
            name="top_long_span",
            derive=_resolved_long_span,
            depends_on=("height_regime", "low_top_long_span", "standard_top_long_span"),
            description="Active regime's resolved largest tabletop plan span.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="nonround_top_short_span",
            reference="top_long_span",
            ratio_low=0.22,
            ratio_high=1.0,
            hard_min=0.32,
            hard_max=1.05,
            active_when=(ActiveWhen(factor="top_shape", values=("rectangle", "oval")),),
            description="Short plan span for non-round tops, including narrow consoles and broad tables.",
            unit="m",
        ),
        Derived(
            name="top_short_span",
            derive=_resolved_short_span,
            depends_on=("top_shape", "top_long_span", "nonround_top_short_span"),
            description="Resolved tabletop short span; equal to diameter for round tops.",
            unit="m",
        ),
        UniformFloat(
            name="top_thickness",
            low=0.018,
            high=0.065,
            description="Visible tabletop slab thickness.",
            unit="m",
        ),
        UniformChoice(
            name="leg_profile",
            choices=("square", "round"),
            active_when=(ActiveWhen(factor="support_construction", values=("four_leg",)),),
            description="Square or circular four-leg member cross-section.",
        ),
        UniformFloat(
            name="leg_top_size",
            low=0.035,
            high=0.090,
            active_when=(ActiveWhen(factor="support_construction", values=("four_leg",)),),
            description="Width or diameter of each leg's complete tabletop contact face.",
            unit="m",
        ),
        UniformFloat(
            name="leg_bottom_to_top_ratio",
            low=0.62,
            high=1.0,
            active_when=(ActiveWhen(factor="support_construction", values=("four_leg",)),),
            description="Bottom-to-top section ratio from visibly tapered to straight legs.",
            unit="ratio",
        ),
        UniformFloat(
            name="leg_inset_ratio",
            low=0.055,
            high=0.16,
            active_when=(ActiveWhen(factor="support_construction", values=("four_leg",)),),
            description="Inset of each leg center from its nearby tabletop edges as a plan-span ratio.",
            unit="ratio",
        ),
        UniformChoice(
            name="pedestal_profile",
            choices=("round", "square"),
            active_when=(ActiveWhen(factor="support_construction", values=("pedestal",)),),
            description="Matching circular or square pedestal column and floor-base plan.",
        ),
        RelativeUniformFloat(
            name="pedestal_column_span",
            reference="top_short_span",
            ratio_low=0.10,
            ratio_high=0.24,
            hard_min=0.075,
            hard_max=0.24,
            active_when=(ActiveWhen(factor="support_construction", values=("pedestal",)),),
            description="Pedestal column diameter or width relative to tabletop short span.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="pedestal_base_span",
            reference="top_short_span",
            ratio_low=0.46,
            ratio_high=0.76,
            hard_min=0.18,
            active_when=(ActiveWhen(factor="support_construction", values=("pedestal",)),),
            description="Broad pedestal floor-base diameter or width relative to the tabletop.",
            unit="m",
        ),
        UniformFloat(
            name="pedestal_base_thickness",
            low=0.020,
            high=0.060,
            active_when=(ActiveWhen(factor="support_construction", values=("pedestal",)),),
            description="Vertical thickness of the pedestal's floor base.",
            unit="m",
        ),
        UniformFloat(
            name="trestle_member_width",
            low=0.050,
            high=0.120,
            active_when=(ActiveWhen(factor="support_construction", values=("trestle",)),),
            description="Longitudinal thickness of each solid trestle end frame.",
            unit="m",
        ),
        UniformFloat(
            name="trestle_end_inset_ratio",
            low=0.10,
            high=0.23,
            active_when=(ActiveWhen(factor="support_construction", values=("trestle",)),),
            description="Longitudinal inset of each end frame relative to tabletop length.",
            unit="ratio",
        ),
        UniformFloat(
            name="trestle_transverse_span_ratio",
            low=0.60,
            high=0.90,
            active_when=(ActiveWhen(factor="support_construction", values=("trestle",)),),
            description="End-frame foot and upper-beam span relative to tabletop depth.",
            unit="ratio",
        ),
        UniformFloat(
            name="trestle_stretcher_height_ratio",
            low=0.24,
            high=0.48,
            active_when=(ActiveWhen(factor="support_construction", values=("trestle",)),),
            description="Stretcher center height relative to clear support height.",
            unit="ratio",
        ),
    ),
    relationships=(
        *tuple(
            RigidMount(
                name=f"{name}-mounted-to-tabletop",
                parent_part="table",
                parent_element="tabletop",
                child_part="table",
                child_element=name,
                active_when=(ActiveWhen(factor="support_construction", values=("four_leg",)),),
            )
            for name in ("leg_front_left", "leg_front_right", "leg_back_left", "leg_back_right")
        ),
        RigidMount(
            name="pedestal-column-mounted-to-tabletop",
            parent_part="table",
            parent_element="tabletop",
            child_part="table",
            child_element="pedestal_column",
            active_when=(ActiveWhen(factor="support_construction", values=("pedestal",)),),
        ),
        RigidMount(
            name="pedestal-base-mounted-to-column",
            parent_part="table",
            parent_element="pedestal_column",
            child_part="table",
            child_element="pedestal_base",
            active_when=(ActiveWhen(factor="support_construction", values=("pedestal",)),),
        ),
        RigidMount(
            name="left-trestle-mounted-to-tabletop",
            parent_part="table",
            parent_element="tabletop",
            child_part="table",
            child_element="left_trestle",
            active_when=(ActiveWhen(factor="support_construction", values=("trestle",)),),
        ),
        RigidMount(
            name="right-trestle-mounted-to-tabletop",
            parent_part="table",
            parent_element="tabletop",
            child_part="table",
            child_element="right_trestle",
            active_when=(ActiveWhen(factor="support_construction", values=("trestle",)),),
        ),
        RigidMount(
            name="trestle-stretcher-mounted-to-left-post",
            parent_part="table",
            parent_element="left_trestle",
            child_part="table",
            child_element="trestle_stretcher",
            active_when=(ActiveWhen(factor="support_construction", values=("trestle",)),),
        ),
        RigidMount(
            name="trestle-stretcher-mounted-to-right-post",
            parent_part="table",
            parent_element="right_trestle",
            child_part="table",
            child_element="trestle_stretcher",
            active_when=(ActiveWhen(factor="support_construction", values=("trestle",)),),
        ),
    ),
    constraints=(
        Constraint(
            name="round-tops-use-radially-coherent-supports",
            predicate=lambda p: (
                not (p["top_shape"] == "round" and p["support_construction"] == "trestle")
            ),
            message="Ordinary round tables in scope use four legs or a central pedestal.",
        ),
        Constraint(
            name="round-top-diameter-stays-in-ordinary-household-envelope",
            predicate=lambda p: p["top_shape"] != "round" or p["top_long_span"] <= 1.50,
            message="Round tops stop at the ordinary 1.50 m household diameter envelope.",
        ),
        Constraint(
            name="single-pedestal-top-span",
            predicate=lambda p: (
                p["support_construction"] != "pedestal" or p["top_long_span"] <= 1.30
            ),
            message="A single central pedestal is limited to ordinary compact tabletop spans.",
        ),
        Constraint(
            name="single-pedestal-plan-and-footprint-are-balanced",
            predicate=lambda p: (
                p["support_construction"] != "pedestal"
                or (
                    p["top_short_span"] >= 0.65 * p["top_long_span"]
                    and p["pedestal_base_span"] >= 0.38 * p["top_long_span"]
                )
            ),
            message=(
                "A radial single pedestal requires a compact tabletop aspect and a floor base "
                "that supports both plan axes."
            ),
        ),
        Constraint(
            name="trestle-requires-room-for-two-end-frames",
            predicate=lambda p: (
                p["support_construction"] != "trestle"
                or (
                    p["top_long_span"] >= 0.75
                    and (1.0 - 2.0 * p["trestle_end_inset_ratio"]) * p["top_long_span"]
                    > 2.0 * p["trestle_member_width"]
                )
            ),
            message="A trestle top must admit two distinct end frames and a positive stretcher.",
        ),
        Constraint(
            name="support-members-fit-tabletop-depth",
            predicate=lambda p: (
                p["support_construction"] != "four_leg"
                or p["leg_top_size"] < 0.30 * p["top_short_span"]
            ),
            message="Four complete leg roots must fit within the tabletop short span.",
        ),
    ),
    build=build_model,
    tests=run_tests,
    population_checks=(
        PopulationCheck(
            name="covers-top-plan-families",
            predicate=lambda samples: _covers_choices(
                samples, "top_shape", {"rectangle", "round", "oval"}
            ),
            message="Validation samples must cover rectangular, round, and oval tops.",
        ),
        PopulationCheck(
            name="covers-support-constructions",
            predicate=lambda samples: _covers_choices(
                samples, "support_construction", {"four_leg", "pedestal", "trestle"}
            ),
            message="Validation samples must cover four-leg, pedestal, and trestle supports.",
        ),
        PopulationCheck(
            name="covers-height-regimes",
            predicate=lambda samples: _covers_choices(
                samples, "height_regime", {"low", "standard"}
            ),
            message="Validation samples must cover low and standard table heights.",
        ),
        PopulationCheck(
            name="covers-overall-height-envelope",
            predicate=lambda samples: _covers_bounds(
                samples, "overall_height", low_at_most=0.37, high_at_least=0.78
            ),
            message="Validation samples must reach both ordinary vertical regimes.",
        ),
        PopulationCheck(
            name="covers-tabletop-long-span-envelope",
            predicate=lambda samples: _covers_bounds(
                samples, "top_long_span", low_at_most=0.50, high_at_least=1.95
            ),
            message="Validation samples must reach compact and long ordinary table sizes.",
        ),
    ),
    task_requirements=(
        "Must form a freestanding table with a broad horizontal top and a rigid support path to a floor-level footprint.",
    ),
    tags=("table", "furniture", "tabletop", "four-leg", "pedestal", "trestle"),
)
