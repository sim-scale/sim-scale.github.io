from __future__ import annotations

from typing import Any, Mapping

import cadquery as cq

from assetengine import (
    ActiveWhen,
    Derived,
    GeneratorDesign,
    GeneratorSpec,
    JointMount,
    PopulationCheck,
    UniformChoice,
    UniformFloat,
)
from assetengine.articraft import (
    ArticulatedObject,
    ArticulationType,
    MotionLimits,
    Origin,
    TestContext,
    mesh_from_cadquery,
)

FAMILIES = ("top_freezer", "bottom_freezer", "side_by_side", "french_door")


def _selected(p: Mapping[str, Any], stem: str) -> float:
    return float(p[f"{stem}_{p['door_layout']}"])


def _cabinet(
    width: float,
    depth: float,
    height: float,
    wall: float,
    layout: str,
    division: float,
) -> cq.Workplane:
    outer = cq.Workplane("XY").box(width, depth, height).translate((0, 0, height / 2))
    cavity = (
        cq.Workplane("XY")
        .box(width - 2 * wall, depth - wall + 0.004, height - 2 * wall)
        .translate((0, -(wall + 0.004) / 2, height / 2))
    )
    shell = outer.cut(cavity)
    if layout == "side_by_side":
        divider = (
            cq.Workplane("XY")
            .box(wall, depth - wall, height - 2 * wall)
            .translate((division, -wall / 2, height / 2))
        )
    else:
        divider = (
            cq.Workplane("XY")
            .box(width - 2 * wall, depth - wall, wall)
            .translate((0, -wall / 2, division))
        )
    return shell.union(divider)


def _bar_handle(
    *,
    center_x: float,
    center_z: float,
    horizontal: bool,
    length: float,
    door_thickness: float,
    clearance: float,
    section: float,
) -> cq.Workplane:
    bar_y = -(door_thickness + clearance + section / 2)
    if horizontal:
        bar = (
            cq.Workplane("XY").box(length, section, section).translate((center_x, bar_y, center_z))
        )
        root_xs = (center_x - length / 2 + section / 2, center_x + length / 2 - section / 2)
        roots = None
        for root_x in root_xs:
            root = (
                cq.Workplane("XY")
                .box(section, clearance + section, section)
                .translate(
                    (root_x, -(door_thickness + (clearance + section) / 2 - 0.001), center_z)
                )
            )
            roots = root if roots is None else roots.union(root)
    else:
        bar = (
            cq.Workplane("XY").box(section, section, length).translate((center_x, bar_y, center_z))
        )
        root_zs = (center_z - length / 2 + section / 2, center_z + length / 2 - section / 2)
        roots = None
        for root_z in root_zs:
            root = (
                cq.Workplane("XY")
                .box(section, clearance + section, section)
                .translate(
                    (center_x, -(door_thickness + (clearance + section) / 2 - 0.001), root_z)
                )
            )
            roots = root if roots is None else roots.union(root)
    return bar.union(roots)


def _door(
    width: float,
    height: float,
    thickness: float,
    projection: float,
    section: float,
    direction: float,
    horizontal: bool,
    handle_high: bool = False,
) -> cq.Workplane:
    center_x = direction * width / 2
    panel = (
        cq.Workplane("XY")
        .box(width, thickness, height)
        .translate((center_x, -thickness / 2, height / 2))
    )
    if horizontal:
        handle = _bar_handle(
            center_x=center_x,
            center_z=(0.82 if handle_high else 0.18) * height,
            horizontal=True,
            length=0.62 * width,
            door_thickness=thickness,
            clearance=projection,
            section=section,
        )
    else:
        handle_x = direction * (width - max(0.055, 0.10 * width))
        handle = _bar_handle(
            center_x=handle_x,
            center_z=height / 2,
            horizontal=False,
            length=0.62 * height,
            door_thickness=thickness,
            clearance=projection,
            section=section,
        )
    return panel.union(handle)


def _drawer(
    width: float,
    depth: float,
    height: float,
    thickness: float,
    wall: float,
    gap: float,
    projection: float,
    section: float,
) -> cq.Workplane:
    front = (
        cq.Workplane("XY").box(width, thickness, height).translate((0, -thickness / 2, height / 2))
    )
    bin_clearance = max(0.012, gap)
    bin_width = width - 2 * wall - 2 * bin_clearance
    bin_depth = depth - wall - 2 * bin_clearance
    bin_height = height - 2 * wall - 2 * bin_clearance
    bin_wall = min(0.018, 0.45 * wall)
    bin_floor = (
        cq.Workplane("XY")
        .box(bin_width, bin_depth, bin_wall)
        .translate((0, bin_depth / 2 - 0.001, wall + bin_clearance + bin_wall / 2))
    )
    side_z = wall + bin_clearance + bin_height / 2
    side_y = bin_depth / 2 - 0.001
    left_side = (
        cq.Workplane("XY")
        .box(bin_wall, bin_depth, bin_height)
        .translate((-bin_width / 2 + bin_wall / 2, side_y, side_z))
    )
    right_side = left_side.mirror("YZ")
    back = (
        cq.Workplane("XY")
        .box(bin_width, bin_wall, bin_height)
        .translate((0, bin_depth - bin_wall / 2 - 0.001, side_z))
    )
    handle = _bar_handle(
        center_x=0,
        center_z=0.78 * height,
        horizontal=True,
        length=0.58 * width,
        door_thickness=thickness,
        clearance=projection,
        section=section,
    )
    return front.union(bin_floor).union(left_side).union(right_side).union(back).union(handle)


def _swing(
    model: ArticulatedObject,
    cabinet: Any,
    *,
    part: str,
    joint: str,
    origin: tuple[float, float, float],
    width: float,
    height: float,
    thickness: float,
    projection: float,
    section: float,
    direction: float,
    horizontal: bool,
    handle_high: bool = False,
) -> None:
    child = model.part(part)
    child.visual(
        mesh_from_cadquery(
            _door(
                width,
                height,
                thickness,
                projection,
                section,
                direction,
                horizontal,
                handle_high,
            ),
            f"{part}_panel",
        ),
        name=f"{part}_panel",
    )
    model.articulation(
        joint,
        ArticulationType.REVOLUTE,
        parent=cabinet,
        child=child,
        origin=Origin(xyz=origin),
        axis=(0, 0, -1 if direction > 0 else 1),
        motion_limits=MotionLimits(lower=0, upper=1.57, effort=35, velocity=1),
    )


def _slide(
    model: ArticulatedObject,
    cabinet: Any,
    *,
    origin: tuple[float, float, float],
    width: float,
    depth: float,
    height: float,
    thickness: float,
    wall: float,
    gap: float,
    projection: float,
    section: float,
) -> None:
    child = model.part("freezer_drawer")
    child.visual(
        mesh_from_cadquery(
            _drawer(width, depth, height, thickness, wall, gap, projection, section),
            "freezer_drawer_front",
        ),
        name="freezer_drawer_front",
    )
    model.articulation(
        "cabinet_to_freezer_drawer",
        ArticulationType.PRISMATIC,
        parent=cabinet,
        child=child,
        origin=Origin(xyz=origin),
        axis=(0, -1, 0),
        motion_limits=MotionLimits(lower=0, upper=0.42 * depth, effort=80, velocity=0.35),
    )


def build_model(p: Mapping[str, Any]) -> ArticulatedObject:
    layout = str(p["door_layout"])
    width, height, depth = (
        float(p[k]) for k in ("overall_width", "overall_height", "overall_depth")
    )
    wall, thickness, gap = (
        float(p[k]) for k in ("cabinet_wall_thickness", "door_thickness", "door_gap")
    )
    projection, section = (float(p[k]) for k in ("handle_projection", "handle_section"))
    front_y = -depth / 2
    if layout == "top_freezer":
        division = height * (1 - float(p["freezer_fraction_top_freezer"]))
    elif layout == "bottom_freezer":
        division = height * float(p["freezer_fraction_bottom_freezer"])
    elif layout == "side_by_side":
        division = -width / 2 + width * float(p["left_fraction_side_by_side"])
    else:
        division = height * (1 - float(p["upper_fraction_french_door"]))
    model = ArticulatedObject(name="refrigerator")
    body = model.part("cabinet")
    body.visual(
        mesh_from_cadquery(_cabinet(width, depth, height, wall, layout, division), "cabinet_shell"),
        name="cabinet_shell",
    )

    common = dict(thickness=thickness, projection=projection, section=section)
    if layout == "top_freezer":
        upper_h = float(p["freezer_fraction_top_freezer"]) * height
        lower_h = height - upper_h - 1.5 * gap
        door_w, hinge_x = width - 2 * gap, -width / 2 + gap
        _swing(
            model,
            body,
            part="lower_door",
            joint="cabinet_to_lower_door",
            origin=(hinge_x, front_y, gap),
            width=door_w,
            height=lower_h,
            direction=1,
            horizontal=True,
            handle_high=True,
            **common,
        )
        _swing(
            model,
            body,
            part="upper_door",
            joint="cabinet_to_upper_door",
            origin=(hinge_x, front_y, lower_h + 2 * gap),
            width=door_w,
            height=upper_h - 2 * gap,
            direction=1,
            horizontal=True,
            **common,
        )
    elif layout == "bottom_freezer":
        freezer_h = float(p["freezer_fraction_bottom_freezer"]) * height
        door_w, hinge_x = width - 2 * gap, -width / 2 + gap
        _slide(
            model,
            body,
            origin=(0, front_y, gap),
            width=door_w,
            depth=depth,
            height=freezer_h - 2 * gap,
            wall=wall,
            gap=gap,
            **common,
        )
        _swing(
            model,
            body,
            part="main_door",
            joint="cabinet_to_main_door",
            origin=(hinge_x, front_y, freezer_h + gap / 2),
            width=door_w,
            height=height - freezer_h - 1.5 * gap,
            direction=1,
            horizontal=True,
            **common,
        )
    elif layout == "side_by_side":
        left_w = float(p["left_fraction_side_by_side"]) * width
        _swing(
            model,
            body,
            part="left_door",
            joint="cabinet_to_left_door",
            origin=(-width / 2 + gap, front_y, gap),
            width=left_w - 1.5 * gap,
            height=height - 2 * gap,
            direction=1,
            horizontal=False,
            **common,
        )
        _swing(
            model,
            body,
            part="right_door",
            joint="cabinet_to_right_door",
            origin=(width / 2 - gap, front_y, gap),
            width=width - left_w - 1.5 * gap,
            height=height - 2 * gap,
            direction=-1,
            horizontal=False,
            **common,
        )
    else:
        upper_h = float(p["upper_fraction_french_door"]) * height
        freezer_h, half_w = height - upper_h - 1.5 * gap, width / 2
        _slide(
            model,
            body,
            origin=(0, front_y, gap),
            width=width - 2 * gap,
            depth=depth,
            height=freezer_h - 2 * gap,
            wall=wall,
            gap=gap,
            **common,
        )
        _swing(
            model,
            body,
            part="left_door",
            joint="cabinet_to_left_door",
            origin=(-width / 2 + gap, front_y, freezer_h + gap / 2),
            width=half_w - 1.5 * gap,
            height=upper_h,
            direction=1,
            horizontal=False,
            **common,
        )
        _swing(
            model,
            body,
            part="right_door",
            joint="cabinet_to_right_door",
            origin=(width / 2 - gap, front_y, freezer_h + gap / 2),
            width=half_w - 1.5 * gap,
            height=upper_h,
            direction=-1,
            horizontal=False,
            **common,
        )
    return model


def run_tests(model: ArticulatedObject, p: Mapping[str, Any]):
    ctx = TestContext(model)
    width, height, depth = (
        float(p[k]) for k in ("overall_width", "overall_height", "overall_depth")
    )
    wall, gap = float(p["cabinet_wall_thickness"]), float(p["door_gap"])
    ctx.check("ordinary-positive-envelope", width > 0.5 and depth > 0.5 and height > 1.5)
    ctx.check("cabinet-retains-cavity", width > 2 * wall and depth > wall and height > 2 * wall)
    ctx.check("door-gaps-fit-envelope", gap < 0.025 * min(width, height))
    layout = str(p["door_layout"])
    if layout in {"bottom_freezer", "french_door"}:
        ctx.allow_overlap(
            model.get_part("cabinet"),
            model.get_part("freezer_drawer"),
            elem_a="cabinet_shell",
            elem_b="freezer_drawer_front",
            reason=(
                "The compiler's whole-mesh containment overlap fallback treats the real open bin "
                "inside the true cabinet cavity as solid containment; source-bound probes verify "
                "the bin walls remain within their separated freezer region."
            ),
        )
    joints = {
        "top_freezer": ("cabinet_to_lower_door", "cabinet_to_upper_door"),
        "bottom_freezer": ("cabinet_to_main_door", "cabinet_to_freezer_drawer"),
        "side_by_side": ("cabinet_to_left_door", "cabinet_to_right_door"),
        "french_door": (
            "cabinet_to_left_door",
            "cabinet_to_right_door",
            "cabinet_to_freezer_drawer",
        ),
    }[layout]
    for name in joints:
        joint = model.get_articulation(name)
        child = model.get_part(joint.child)
        closed = ctx.part_world_aabb(child)
        with ctx.pose({joint: joint.motion_limits.upper}):
            opened = ctx.part_world_aabb(child)
        ctx.check(
            f"{name}-changes-pose",
            closed is not None
            and opened is not None
            and any(abs(opened[c][a] - closed[c][a]) > 0.05 for c in (0, 1) for a in range(3)),
        )
    return ctx.report()


def _dimension_factors(stem: str, ranges: Mapping[str, tuple[float, float]], label: str):
    return tuple(
        UniformFloat(
            name=f"{stem}_{family}",
            low=bounds[0],
            high=bounds[1],
            unit="m",
            active_when=(ActiveWhen(factor="door_layout", values=(family,)),),
            description=f"{label} of a {family.replace('_', '-')} refrigerator.",
        )
        for family, bounds in ranges.items()
    )


WIDTHS = {
    "top_freezer": (0.55, 0.84),
    "bottom_freezer": (0.70, 0.86),
    "side_by_side": (0.82, 1.02),
    "french_door": (0.76, 0.92),
}
HEIGHTS = {
    "top_freezer": (1.55, 1.75),
    "bottom_freezer": (1.68, 1.82),
    "side_by_side": (1.67, 1.82),
    "french_door": (1.70, 1.83),
}
DEPTHS = {
    "top_freezer": (0.55, 0.72),
    "bottom_freezer": (0.56, 0.72),
    "side_by_side": (0.55, 0.73),
    "french_door": (0.56, 0.74),
}


GENERATOR = GeneratorSpec(
    name="refrigerator",
    category="refrigerator",
    description="Articulated category-level generator for common full-size household refrigerators.",
    design=GeneratorDesign(
        coverage="Covers ordinary freestanding top-freezer, bottom-freezer, side-by-side, and three-door French-door refrigerators over their layout-specific 0.55-1.02 m widths, 1.55-1.83 m heights, and approximately 0.64-0.91 m complete closed depths after doors and handles. Excludes compact minibar, undercounter, built-in column, glass merchandiser, chest-freezer, rare specialty multi-door constructions, and optional dispenser-equipped fronts.",
        factors="Door layout selects genuinely different compartment and articulation topology. Width, height, and cabinet-only depth use separate layout-conditional absolute envelopes because narrow top-freezer and broad side-by-side/French-door regimes differ materially. Cabinet depth is calibrated so independent door thickness and handle reach still keep the complete closed object inside the ordinary total-depth envelope. Compartment divisions depend on layout, while shell wall, door thickness, seam gap, handle clearance, and handle section vary independently over ordinary overlapping manufacturing ranges.",
        components="A coherent hollow cabinet retains its back, floor, roof, side walls, and a family-aligned horizontal or vertical compartment divider. Insulated flat fronts carry genuine external bars with finite behind-bar clearance and two seated roots: horizontal on stacked fronts and vertical near paired-door meeting edges. Pull-out freezer fronts carry attached depth-bearing open bins. Door division and side-by-side asymmetry vary appreciably; trim, gaskets, shelves, dispensers, finish, and hinge hardware are incidental or optional and remain unmodeled.",
        physics_and_task="The cabinet is the root. Each front is a separate child with a declared JointMount. Swing doors revolve outward about their vertical hinge edges through a collision-free 90-degree access pose, while common bottom-freezer fronts translate outward on an idealized prismatic guide. Internal baskets and rail hardware are intentionally omitted. Handles form one continuous solid with their door fronts rather than using connector geometry.",
    ),
    factors=(
        UniformChoice(
            name="door_layout",
            choices=FAMILIES,
            description="Common full-size compartment and door topology.",
        ),
        *_dimension_factors("width", WIDTHS, "Overall width"),
        Derived(
            name="overall_width",
            derive=lambda p: _selected(p, "width"),
            depends_on=("door_layout", *tuple(f"width_{x}" for x in FAMILIES)),
            description="Active layout-specific overall width.",
            unit="m",
        ),
        *_dimension_factors("height", HEIGHTS, "Overall height"),
        Derived(
            name="overall_height",
            derive=lambda p: _selected(p, "height"),
            depends_on=("door_layout", *tuple(f"height_{x}" for x in FAMILIES)),
            description="Active layout-specific overall height.",
            unit="m",
        ),
        *_dimension_factors("depth", DEPTHS, "Cabinet depth excluding door and handle"),
        Derived(
            name="overall_depth",
            derive=lambda p: _selected(p, "depth"),
            depends_on=("door_layout", *tuple(f"depth_{x}" for x in FAMILIES)),
            description="Active layout-specific cabinet depth.",
            unit="m",
        ),
        UniformFloat(
            name="freezer_fraction_top_freezer",
            low=0.22,
            high=0.33,
            unit="ratio",
            active_when=(ActiveWhen(factor="door_layout", values=("top_freezer",)),),
            description="Upper freezer share of cabinet height.",
        ),
        UniformFloat(
            name="freezer_fraction_bottom_freezer",
            low=0.25,
            high=0.36,
            unit="ratio",
            active_when=(ActiveWhen(factor="door_layout", values=("bottom_freezer",)),),
            description="Lower freezer share of cabinet height.",
        ),
        UniformFloat(
            name="left_fraction_side_by_side",
            low=0.32,
            high=0.45,
            unit="ratio",
            active_when=(ActiveWhen(factor="door_layout", values=("side_by_side",)),),
            description="Left freezer share of cabinet width.",
        ),
        UniformFloat(
            name="upper_fraction_french_door",
            low=0.58,
            high=0.72,
            unit="ratio",
            active_when=(ActiveWhen(factor="door_layout", values=("french_door",)),),
            description="Upper paired-door share of cabinet height.",
        ),
        UniformFloat(
            name="cabinet_wall_thickness",
            low=0.028,
            high=0.045,
            unit="m",
            description="Visible insulated cabinet wall thickness.",
        ),
        UniformFloat(
            name="door_thickness",
            low=0.045,
            high=0.075,
            unit="m",
            description="Insulated exterior front thickness.",
        ),
        UniformFloat(
            name="door_gap",
            low=0.004,
            high=0.010,
            unit="m",
            description="Visible edge and compartment seam clearance.",
        ),
        UniformFloat(
            name="handle_projection",
            low=0.025,
            high=0.055,
            unit="m",
            description="Bar handle projection beyond the door face.",
        ),
        UniformFloat(
            name="handle_section",
            low=0.018,
            high=0.035,
            unit="m",
            description="Square grasp bar cross-section size.",
        ),
    ),
    relationships=(
        JointMount(
            name="lower-door-hinged-to-cabinet",
            joint="cabinet_to_lower_door",
            parent_part="cabinet",
            child_part="lower_door",
            allowed_joint_types=("revolute",),
            active_when=(ActiveWhen(factor="door_layout", values=("top_freezer",)),),
        ),
        JointMount(
            name="upper-door-hinged-to-cabinet",
            joint="cabinet_to_upper_door",
            parent_part="cabinet",
            child_part="upper_door",
            allowed_joint_types=("revolute",),
            active_when=(ActiveWhen(factor="door_layout", values=("top_freezer",)),),
        ),
        JointMount(
            name="main-door-hinged-to-cabinet",
            joint="cabinet_to_main_door",
            parent_part="cabinet",
            child_part="main_door",
            allowed_joint_types=("revolute",),
            active_when=(ActiveWhen(factor="door_layout", values=("bottom_freezer",)),),
        ),
        JointMount(
            name="left-door-hinged-to-cabinet",
            joint="cabinet_to_left_door",
            parent_part="cabinet",
            child_part="left_door",
            allowed_joint_types=("revolute",),
            active_when=(ActiveWhen(factor="door_layout", values=("side_by_side", "french_door")),),
        ),
        JointMount(
            name="right-door-hinged-to-cabinet",
            joint="cabinet_to_right_door",
            parent_part="cabinet",
            child_part="right_door",
            allowed_joint_types=("revolute",),
            active_when=(ActiveWhen(factor="door_layout", values=("side_by_side", "french_door")),),
        ),
        JointMount(
            name="freezer-drawer-guided-by-cabinet",
            joint="cabinet_to_freezer_drawer",
            parent_part="cabinet",
            child_part="freezer_drawer",
            allowed_joint_types=("prismatic",),
            active_when=(
                ActiveWhen(factor="door_layout", values=("bottom_freezer", "french_door")),
            ),
        ),
    ),
    population_checks=(
        PopulationCheck(
            name="covers-common-door-layouts",
            predicate=lambda s: {str(x["door_layout"]) for x in s} >= set(FAMILIES),
            message="Validation must exercise all four common layouts.",
        ),
    ),
    build=build_model,
    tests=run_tests,
    task_requirements=(
        "Retain a genuine enclosed storage cavity behind movable fronts.",
        "Articulate every door or freezer drawer outward in its ordinary direction.",
    ),
    tags=("refrigerator", "appliance", "hinged doors", "freezer drawer"),
)
