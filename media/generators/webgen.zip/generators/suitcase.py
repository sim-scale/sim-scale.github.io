from __future__ import annotations

import math
from typing import Any, Mapping, Sequence

from assetengine import (
    ActiveWhen,
    Constraint,
    Derived,
    GeneratorDesign,
    GeneratorSpec,
    JointMount,
    PopulationCheck,
    RelativeUniformFloat,
    RigidMount,
    UniformChoice,
    UniformFloat,
)
from assetengine.articraft import (
    ArticulatedObject,
    ArticulationType,
    Box,
    Cylinder,
    ExtrudeGeometry,
    MotionLimits,
    Origin,
    TestContext,
    mesh_from_geometry,
)

_CORNER_SEGMENTS = 6
_HANDLE_ROOT_STOCK = 0.004
_TROLLEY_CONTACT_TOLERANCE = 1e-6
_SLEEVE_WALL = 0.003


def _rounded_rectangle(
    width: float,
    height: float,
    radius: float,
    *,
    segments: int = _CORNER_SEGMENTS,
) -> list[tuple[float, float]]:
    """Return one counter-clockwise rounded rectangle centered on both axes."""
    half_width = 0.5 * width
    half_height = 0.5 * height
    radius = min(radius, half_width - 1e-5, half_height - 1e-5)
    corners = (
        (half_width - radius, -half_height + radius, -0.5 * math.pi),
        (half_width - radius, half_height - radius, 0.0),
        (-half_width + radius, half_height - radius, 0.5 * math.pi),
        (-half_width + radius, -half_height + radius, math.pi),
    )
    points: list[tuple[float, float]] = []
    for center_x, center_y, start_angle in corners:
        for index in range(segments + 1):
            angle = start_angle + 0.5 * math.pi * index / segments
            points.append(
                (
                    center_x + radius * math.cos(angle),
                    center_y + radius * math.sin(angle),
                )
            )
    return points


def _rounded_case_geometry(width: float, depth: float, height: float, radius: float):
    """Extrude a rounded front outline through depth into the suitcase frame."""
    return ExtrudeGeometry(
        _rounded_rectangle(width, height, radius),
        depth,
        cap=True,
        center=True,
        closed=True,
    ).rotate_x(0.5 * math.pi)


def _u_profile(span: float, rise: float, member_width: float) -> list[tuple[float, float]]:
    """A single connected, two-root U member with a rectangular section."""
    outer_half = 0.5 * span
    inner_half = outer_half - member_width
    bridge_bottom = rise - member_width
    return [
        (-outer_half, 0.0),
        (-inner_half, 0.0),
        (-inner_half, bridge_bottom),
        (inner_half, bridge_bottom),
        (inner_half, 0.0),
        (outer_half, 0.0),
        (outer_half, rise),
        (-outer_half, rise),
    ]


def _top_handle_geometry(span: float, rise: float, member_width: float, depth: float):
    return ExtrudeGeometry(
        _u_profile(span, rise, member_width),
        depth,
        cap=True,
        center=True,
        closed=True,
    ).rotate_x(0.5 * math.pi)


def _side_handle_geometry(span: float, rise: float, member_width: float, depth: float):
    # Profile X becomes -Z, profile Y becomes +X, and extrusion Z becomes -Y.
    return (
        ExtrudeGeometry(
            _u_profile(span, rise, member_width),
            depth,
            cap=True,
            center=True,
            closed=True,
        )
        .rotate_x(0.5 * math.pi)
        .rotate_y(0.5 * math.pi)
    )


def _family_is_spinner(parameters: Mapping[str, Any]) -> bool:
    return parameters["luggage_family"] != "softside_rollaboard"


def _body_corner_radius(parameters: Mapping[str, Any]) -> float:
    ratio = (
        parameters["hard_corner_ratio"]
        if parameters["luggage_family"] == "hardshell_spinner"
        else parameters["soft_corner_ratio"]
    )
    return float(parameters["case_width"]) * float(ratio)


def _front_relief(parameters: Mapping[str, Any]) -> float:
    return (
        float(parameters["hard_lid_relief"])
        if parameters["luggage_family"] == "hardshell_spinner"
        else float(parameters["soft_pocket_depth"])
    )


def _rail_length(parameters: Mapping[str, Any]) -> float:
    return float(parameters["trolley_extension"]) + float(parameters["rail_insertion"])


def _case_height(parameters: Mapping[str, Any]) -> float:
    return float(parameters["overall_height"]) - 1.65 * float(parameters["wheel_radius"])


def build_model(parameters: Mapping[str, Any]) -> ArticulatedObject:
    model = ArticulatedObject(name="suitcase")
    shell_material = model.material("neutral_shell", rgba=(0.46, 0.48, 0.51, 1.0))
    trim_material = model.material("neutral_trim", rgba=(0.25, 0.27, 0.30, 1.0))
    panel_material = model.material("neutral_panel", rgba=(0.39, 0.41, 0.44, 1.0))

    width = float(parameters["case_width"])
    depth = float(parameters["case_depth"])
    height = float(parameters["case_height"])
    wheel_radius = float(parameters["wheel_radius"])
    wheel_width = float(parameters["wheel_width"])
    body_bottom = 1.65 * wheel_radius
    body_center_z = body_bottom + 0.5 * height
    body_top = body_bottom + height
    corner_radius = float(parameters["body_corner_radius"])

    case = model.part("case")
    case.visual(
        mesh_from_geometry(
            _rounded_case_geometry(width, depth, height, corner_radius), "body_shell"
        ),
        origin=Origin(xyz=(0.0, 0.0, body_center_z)),
        material=shell_material,
        name="body_shell",
    )

    relief = float(parameters["front_relief"])
    if parameters["luggage_family"] == "hardshell_spinner":
        panel_width = 0.97 * width
        panel_height = 0.96 * height
        panel_z = body_center_z
        panel_radius = max(0.010, 0.82 * corner_radius)
        panel_name = "front_lid"
        closure_width = 0.965 * width
        closure_height = 0.955 * height
        closure_band = max(0.006, 0.018 * width)
        main_front_outer_y = -0.5 * depth - relief + 0.002
    else:
        panel_width = 0.82 * width
        panel_height = 0.50 * height
        panel_z = body_bottom + 0.39 * height
        panel_radius = max(0.008, 0.70 * corner_radius)
        panel_name = "front_pocket"
        closure_width = 0.90 * width
        closure_height = 0.90 * height
        closure_band = max(0.005, 0.014 * width)

        soft_panel_depth = 0.007
        main_front_outer_y = -0.5 * depth - soft_panel_depth + 0.002
        case.visual(
            mesh_from_geometry(
                _rounded_case_geometry(
                    closure_width,
                    soft_panel_depth,
                    closure_height,
                    0.72 * corner_radius,
                ),
                "soft_front_panel",
            ),
            origin=Origin(
                xyz=(
                    0.0,
                    -0.5 * depth - 0.5 * soft_panel_depth + 0.002,
                    body_center_z,
                )
            ),
            material=panel_material,
            name="soft_front_panel",
        )
    case.visual(
        mesh_from_geometry(
            _rounded_case_geometry(panel_width, relief, panel_height, panel_radius),
            panel_name,
        ),
        origin=Origin(xyz=(0.0, -0.5 * depth - 0.5 * relief + 0.002, panel_z)),
        material=panel_material,
        name=panel_name,
    )

    panel_outer_y = -0.5 * depth - relief + 0.002
    closure_depth = 0.006
    closure_y = main_front_outer_y - 0.5 * closure_depth + 0.001
    for closure_name, size, closure_z, closure_x in (
        (
            "main_closure_top",
            (closure_width, closure_depth, closure_band),
            body_center_z + 0.5 * closure_height,
            0.0,
        ),
        (
            "main_closure_bottom",
            (closure_width, closure_depth, closure_band),
            body_center_z - 0.5 * closure_height,
            0.0,
        ),
        (
            "main_closure_left",
            (closure_band, closure_depth, closure_height),
            body_center_z,
            -0.5 * closure_width,
        ),
        (
            "main_closure_right",
            (closure_band, closure_depth, closure_height),
            body_center_z,
            0.5 * closure_width,
        ),
    ):
        case.visual(
            Box(size),
            origin=Origin(xyz=(closure_x, closure_y, closure_z)),
            material=trim_material,
            name=closure_name,
        )

    if parameters["luggage_family"] == "hardshell_spinner":
        split_band = max(0.006, 0.016 * width)
        split_depth = 0.010
        split_y = -0.10 * depth
        for split_name, size, split_x, split_z in (
            (
                "hard_split_top",
                (width - split_band, split_depth, split_band),
                0.0,
                body_top,
            ),
            (
                "hard_split_bottom",
                (width - split_band, split_depth, split_band),
                0.0,
                body_bottom,
            ),
            (
                "hard_split_left",
                (split_band, split_depth, height - split_band),
                -0.5 * width,
                body_center_z,
            ),
            (
                "hard_split_right",
                (split_band, split_depth, height - split_band),
                0.5 * width,
                body_center_z,
            ),
        ):
            case.visual(
                Box(size),
                origin=Origin(xyz=(split_x, split_y, split_z)),
                material=trim_material,
                name=split_name,
            )
    else:
        case.visual(
            Box((0.72 * panel_width, 0.006, 0.006)),
            origin=Origin(
                xyz=(
                    0.0,
                    panel_outer_y - 0.002,
                    panel_z + 0.5 * panel_height - 0.010,
                )
            ),
            material=trim_material,
            name="pocket_zipper",
        )

    top_span = float(parameters["top_handle_span"])
    top_rise = float(parameters["top_handle_rise"])
    handle_member = float(parameters["carry_handle_member_width"])
    carry_depth = float(parameters["carry_handle_depth"])
    case.visual(
        mesh_from_geometry(
            _top_handle_geometry(top_span, top_rise, handle_member, carry_depth),
            "top_carry_handle",
        ),
        origin=Origin(xyz=(0.0, 0.0, body_top - _HANDLE_ROOT_STOCK)),
        material=trim_material,
        name="top_carry_handle",
    )

    if parameters["has_side_handle"]:
        case.visual(
            mesh_from_geometry(
                _side_handle_geometry(
                    float(parameters["side_handle_span"]),
                    float(parameters["side_handle_rise"]),
                    handle_member,
                    carry_depth,
                ),
                "side_carry_handle",
            ),
            origin=Origin(xyz=(0.5 * width - _HANDLE_ROOT_STOCK, 0.0, body_center_z)),
            material=trim_material,
            name="side_carry_handle",
        )

    x_offset = 0.5 * width - 1.05 * wheel_radius
    if _family_is_spinner(parameters):
        y_offsets = (
            0.5 * depth - 0.75 * wheel_width,
            -0.5 * depth + 0.75 * wheel_width,
        )
        wheel_positions = (
            ("wheel_left_rear", -x_offset, y_offsets[0]),
            ("wheel_left_front", -x_offset, y_offsets[1]),
            ("wheel_right_rear", x_offset, y_offsets[0]),
            ("wheel_right_front", x_offset, y_offsets[1]),
        )
        wheel_rpy = (0.0, 0.5 * math.pi, 0.0)
        housing_size = (
            1.8 * wheel_width,
            1.8 * wheel_width,
            1.10 * wheel_radius,
        )
    else:
        wheel_positions = (
            ("wheel_left_rear", -x_offset, 0.5 * depth - 0.35 * wheel_width),
            ("wheel_right_rear", x_offset, 0.5 * depth - 0.35 * wheel_width),
        )
        wheel_rpy = (0.0, 0.5 * math.pi, 0.0)
        housing_size = (
            1.6 * wheel_width,
            1.5 * wheel_radius,
            1.30 * wheel_radius,
        )
    for wheel_name, wheel_x, wheel_y in wheel_positions:
        case.visual(
            Cylinder(wheel_radius, wheel_width),
            origin=Origin(xyz=(wheel_x, wheel_y, wheel_radius), rpy=wheel_rpy),
            material=trim_material,
            name=wheel_name,
        )
        housing_name = wheel_name.replace("wheel", "wheel_housing")
        case.visual(
            Box(housing_size),
            origin=Origin(
                xyz=(
                    wheel_x,
                    wheel_y,
                    body_bottom - 0.35 * housing_size[2],
                )
            ),
            material=trim_material,
            name=housing_name,
        )

    rail_span = float(parameters["trolley_rail_span"])
    rail_thickness = float(parameters["trolley_rail_thickness"])
    rail_depth = float(parameters["trolley_rail_depth"])
    rail_length = float(parameters["rail_length"])
    grip_height = float(parameters["trolley_grip_height"])
    rail_y = 0.5 * depth + 0.5 * rail_depth
    for sleeve_name, sleeve_x in (
        ("trolley_left_sleeve", -0.5 * rail_span),
        ("trolley_right_sleeve", 0.5 * rail_span),
    ):
        sleeve_clearance = 0.001
        sleeve_outer_width = rail_thickness + 2.0 * (_SLEEVE_WALL + sleeve_clearance)
        sleeve_outer_depth = rail_depth + 2.0 * _SLEEVE_WALL
        case.visual(
            Box((sleeve_outer_width, _SLEEVE_WALL, rail_length)),
            origin=Origin(
                xyz=(
                    sleeve_x,
                    rail_y - 0.5 * rail_depth - 0.5 * _SLEEVE_WALL,
                    body_top - 0.5 * rail_length,
                )
            ),
            material=trim_material,
            name=sleeve_name,
        )
        for side_suffix, side_sign in (("left", -1.0), ("right", 1.0)):
            case.visual(
                Box((_SLEEVE_WALL, sleeve_outer_depth, rail_length)),
                origin=Origin(
                    xyz=(
                        sleeve_x
                        + side_sign
                        * (0.5 * rail_thickness + sleeve_clearance + 0.5 * _SLEEVE_WALL),
                        rail_y,
                        body_top - 0.5 * rail_length,
                    )
                ),
                material=trim_material,
                name=f"{sleeve_name}_{side_suffix}_wall",
            )

    trolley = model.part("trolley_handle")
    for rail_name, rail_x in (
        ("trolley_left_rail", -0.5 * rail_span),
        ("trolley_right_rail", 0.5 * rail_span),
    ):
        trolley.visual(
            Box((rail_thickness, rail_depth, rail_length)),
            origin=Origin(xyz=(rail_x, 0.0, 0.5 * rail_length)),
            material=trim_material,
            name=rail_name,
        )
    trolley.visual(
        Box((rail_span + rail_thickness, rail_depth, grip_height)),
        origin=Origin(xyz=(0.0, 0.0, rail_length + 0.50 * grip_height)),
        material=trim_material,
        name="trolley_grip",
    )
    model.articulation(
        "case_to_trolley",
        ArticulationType.PRISMATIC,
        parent=case,
        child=trolley,
        origin=Origin(
            xyz=(
                0.0,
                rail_y,
                body_top - float(parameters["rail_insertion"]),
            )
        ),
        axis=(0.0, 0.0, 1.0),
        motion_limits=MotionLimits(
            lower=-float(parameters["trolley_extension"]),
            upper=0.0,
            effort=90.0,
            velocity=0.45,
        ),
    )
    return model


def run_tests(model: ArticulatedObject, parameters: Mapping[str, Any]):
    ctx = TestContext(model)
    case = model.get_part("case")
    trolley = model.get_part("trolley_handle")
    joint = model.get_articulation("case_to_trolley")
    extension = float(parameters["trolley_extension"])
    ctx.check(
        "body dimensions remain positive",
        min(
            float(parameters["case_width"]),
            float(parameters["case_depth"]),
            float(parameters["case_height"]),
        )
        > 0.0,
    )
    ctx.check(
        "trolley rails retain insertion when extended",
        float(parameters["rail_insertion"]) >= 0.045,
    )
    ctx.expect_within(
        trolley,
        case,
        axes="x",
        name="trolley grip and rails stay within the case width",
    )
    ctx.expect_gap(
        trolley,
        case,
        axis="y",
        min_gap=-_TROLLEY_CONTACT_TOLERANCE,
        max_gap=_TROLLEY_CONTACT_TOLERANCE,
        negative_elem="body_shell",
        name="extended trolley remains seated on the rear guide plane",
    )
    extended_position = ctx.part_world_position(trolley)
    with ctx.pose({joint: -extension}):
        ctx.expect_within(
            trolley,
            case,
            axes="x",
            name="collapsed trolley remains laterally guided",
        )
        ctx.expect_gap(
            trolley,
            case,
            axis="y",
            min_gap=-_TROLLEY_CONTACT_TOLERANCE,
            max_gap=_TROLLEY_CONTACT_TOLERANCE,
            negative_elem="body_shell",
            name="collapsed trolley remains seated on the rear guide plane",
        )
        collapsed_position = ctx.part_world_position(trolley)
    ctx.check(
        "trolley retracts downward through its full authored travel",
        extended_position is not None
        and collapsed_position is not None
        and collapsed_position[2] <= extended_position[2] - extension + 1e-7,
    )
    return ctx.report()


def _covers_range(
    samples: Sequence[Mapping[str, Any]], name: str, low: float, high: float, tolerance: float
) -> bool:
    values = [float(sample[name]) for sample in samples]
    return min(values) <= low + tolerance and max(values) >= high - tolerance


GENERATOR = GeneratorSpec(
    name="suitcase",
    category="suitcase",
    description=(
        "Procedural ordinary rolling suitcases with hard-shell spinner, soft-sided spinner, "
        "and soft-sided two-wheel constructions, functional carry handles, and a retractable "
        "twin-rail trolley handle."
    ),
    design=GeneratorDesign(
        coverage=(
            "Common hardshell four-spinner, softside four-spinner, and softside two-wheel "
            "rollaboard families span 0.55-0.79 m overall heights. Width is 60-70% and depth "
            "36-45% of height, covering ordinary cabin through large checked cases (about "
            "0.33-0.55 m wide and 0.20-0.36 m deep). Hard shells have a raised clamshell lid and "
            "a perimeter split continuing through the sidewall depth; soft cases have a framed "
            "front panel, main zipper path, and zippered "
            "lower pocket. Every case has a top carry handle and twin-rail retractable trolley; "
            "side handles remain optional below 0.70 m and are retained on large checked cases. "
            "Trunks, garment bags, duffels, "
            "children's novelty luggage, aluminum-frame specialty cases, and decorative detail "
            "are excluded."
        ),
        factors=(
            "The construction/topology selector separates shell and wheel regimes that do not "
            "form one ordinary cross-product. Overall height is independent; width, depth, "
            "corner radius, wheel radius, handle spans, and rail placement scale with their "
            "observable parent dimensions. The trolley extension uses a decreasing height-relative "
            "envelope so extended grip heights remain in the ordinary human-use band. Hard-lid and "
            "soft-pocket reliefs are construction-conditional absolute dimensions. Carry-handle "
            "rise and member sizes retain independent human-scale targets, with transparent "
            "constraints removing only near-closed openings; a second constraint keeps side lifting "
            "handles on large checked cases. All stochastic factors are uniform."
        ),
        components=(
            "The rounded closed body varies in height, width, depth, corner radius, shell family, "
            "and family-specific front closure construction. Wheels vary by two-wheel versus "
            "four-spinner topology, radius, tread width, axle layout, and visible shell-mounted "
            "housing. The top and optional side U handles vary in span and clear rise. The rear "
            "trolley varies in extension, rail span, rail section, grip height, retained insertion, "
            "and fixed C-channel receiving sleeves. Logos, locks, zipper pulls, double-wheel caster "
            "variants, and decorative ribs remain incidental and fixed or omitted."
        ),
        physics_and_task=(
            "The closed case shell is the root. Family-specific panels and front/depth closure "
            "paths, caster or "
            "wheel housings, every wheel, and each carry handle meet the shell through finite "
            "authored footprints. Both carry handles are connected two-root U members with ordinary "
            "clear openings. The trolley is a separate connected U assembly on a prismatic "
            "JointMount; moving rails nest inside fixed rear C-channel sleeves, retain at least "
            "45 mm insertion when extended, and collapse to the top-rear grip seat. Wheels use "
            "side-to-side axles, visible shrouds/caster housings, and a common ground plane. No "
            "robot-specific clearance or strength is inferred."
        ),
    ),
    factors=(
        UniformChoice(
            name="luggage_family",
            choices=("hardshell_spinner", "softside_spinner", "softside_rollaboard"),
            description="Distinct ordinary shell construction and rolling-base topology.",
        ),
        UniformChoice(
            name="has_side_handle",
            choices=(False, True),
            description="Whether a second fixed U carry handle is mounted on the right side.",
        ),
        UniformFloat(
            name="overall_height",
            low=0.55,
            high=0.79,
            description="Ground-to-case-top height spanning cabin to large checked luggage.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="case_width",
            reference="overall_height",
            ratio_low=0.60,
            ratio_high=0.70,
            description="Side-to-side body width relative to overall case height.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="case_depth",
            reference="overall_height",
            ratio_low=0.36,
            ratio_high=0.45,
            description="Front-to-back closed depth relative to overall case height.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="wheel_radius",
            reference="overall_height",
            ratio_low=0.035,
            ratio_high=0.050,
            description="Rolling radius that scales mildly from cabin to checked cases.",
            unit="m",
        ),
        UniformFloat(
            name="wheel_width",
            low=0.014,
            high=0.024,
            description="Independent tread width for each wheel.",
            unit="m",
        ),
        Derived(
            name="case_height",
            derive=_case_height,
            depends_on=("overall_height", "wheel_radius"),
            description="Closed body height after subtracting the wheel projection.",
            unit="m",
        ),
        UniformFloat(
            name="hard_corner_ratio",
            low=0.055,
            high=0.12,
            active_when=(ActiveWhen(factor="luggage_family", values=("hardshell_spinner",)),),
            description="Hard-shell front-outline corner radius as a fraction of body width.",
            unit="ratio",
        ),
        UniformFloat(
            name="soft_corner_ratio",
            low=0.035,
            high=0.085,
            active_when=(
                ActiveWhen(
                    factor="luggage_family", values=("softside_spinner", "softside_rollaboard")
                ),
            ),
            description="Soft-sided front-outline corner radius as a fraction of body width.",
            unit="ratio",
        ),
        Derived(
            name="body_corner_radius",
            derive=_body_corner_radius,
            depends_on=("luggage_family", "case_width", "hard_corner_ratio", "soft_corner_ratio"),
            description="Construction-conditional physical body corner radius.",
            unit="m",
        ),
        UniformFloat(
            name="hard_lid_relief",
            low=0.008,
            high=0.018,
            active_when=(ActiveWhen(factor="luggage_family", values=("hardshell_spinner",)),),
            description="Raised depth of the hard-shell front half/lid.",
            unit="m",
        ),
        UniformFloat(
            name="soft_pocket_depth",
            low=0.012,
            high=0.035,
            active_when=(
                ActiveWhen(
                    factor="luggage_family", values=("softside_spinner", "softside_rollaboard")
                ),
            ),
            description="Projection of the common lower front fabric pocket.",
            unit="m",
        ),
        Derived(
            name="front_relief",
            derive=_front_relief,
            depends_on=("luggage_family", "hard_lid_relief", "soft_pocket_depth"),
            description="Active construction's front lid or pocket projection.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="top_handle_span",
            reference="case_width",
            ratio_low=0.28,
            ratio_high=0.44,
            description="Outside root-to-root span of the top carry handle.",
            unit="m",
        ),
        UniformFloat(
            name="top_handle_rise",
            low=0.035,
            high=0.060,
            description="Clear upward rise of the top U carry handle.",
            unit="m",
        ),
        UniformFloat(
            name="carry_handle_member_width",
            low=0.012,
            high=0.022,
            description="In-plane width of each carry-handle leg and bridge.",
            unit="m",
        ),
        UniformFloat(
            name="carry_handle_depth",
            low=0.016,
            high=0.030,
            description="Front-to-back grasp-section depth of the carry handles.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="side_handle_span",
            reference="case_height",
            ratio_low=0.22,
            ratio_high=0.34,
            active_when=(ActiveWhen(factor="has_side_handle", values=(True,)),),
            description="Vertical outside root-to-root span of the optional side handle.",
            unit="m",
        ),
        UniformFloat(
            name="side_handle_rise",
            low=0.032,
            high=0.058,
            active_when=(ActiveWhen(factor="has_side_handle", values=(True,)),),
            description="Outward rise of the optional side U carry handle.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="trolley_extension",
            reference="overall_height",
            ratio_low=-0.65,
            ratio_high=-0.35,
            offset=0.68,
            hard_min=0.20,
            hard_max=0.48,
            description="Retractable travel selected to keep extended grips in an ordinary band.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="trolley_rail_span",
            reference="case_width",
            ratio_low=0.34,
            ratio_high=0.52,
            description="Center-to-center span of the twin rear trolley rails.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="trolley_rail_thickness",
            reference="case_width",
            ratio_low=0.025,
            ratio_high=0.040,
            hard_min=0.010,
            hard_max=0.020,
            description="Side-to-side rectangular rail thickness.",
            unit="m",
        ),
        UniformFloat(
            name="trolley_rail_depth",
            low=0.010,
            high=0.018,
            description="Front-to-back depth of each trolley rail.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="rail_insertion",
            reference="case_height",
            ratio_low=0.08,
            ratio_high=0.15,
            hard_min=0.045,
            description="Rail length retained below the body top at full extension.",
            unit="m",
        ),
        Derived(
            name="rail_length",
            derive=_rail_length,
            depends_on=("trolley_extension", "rail_insertion"),
            description="Total visible rail length required for travel plus retained insertion.",
            unit="m",
        ),
        UniformFloat(
            name="trolley_grip_height",
            low=0.022,
            high=0.036,
            description="Vertical thickness of the trolley grip joining both rails.",
            unit="m",
        ),
    ),
    relationships=(
        RigidMount(
            name="front-panel-mounted-to-shell",
            parent_part="case",
            parent_element="body_shell",
            child_part="case",
            child_element="front_lid",
            active_when=(ActiveWhen(factor="luggage_family", values=("hardshell_spinner",)),),
        ),
        RigidMount(
            name="front-pocket-mounted-to-shell",
            parent_part="case",
            parent_element="body_shell",
            child_part="case",
            child_element="front_pocket",
            active_when=(
                ActiveWhen(
                    factor="luggage_family", values=("softside_spinner", "softside_rollaboard")
                ),
            ),
        ),
        RigidMount(
            name="soft-front-panel-mounted-to-shell",
            parent_part="case",
            parent_element="body_shell",
            child_part="case",
            child_element="soft_front_panel",
            active_when=(
                ActiveWhen(
                    factor="luggage_family",
                    values=("softside_spinner", "softside_rollaboard"),
                ),
            ),
        ),
        RigidMount(
            name="hard-main-closure-mounted-to-lid",
            parent_part="case",
            parent_element="front_lid",
            child_part="case",
            child_element="main_closure_top",
            active_when=(ActiveWhen(factor="luggage_family", values=("hardshell_spinner",)),),
        ),
        RigidMount(
            name="soft-main-closure-mounted-to-panel",
            parent_part="case",
            parent_element="soft_front_panel",
            child_part="case",
            child_element="main_closure_top",
            active_when=(
                ActiveWhen(
                    factor="luggage_family",
                    values=("softside_spinner", "softside_rollaboard"),
                ),
            ),
        ),
        RigidMount(
            name="hard-depth-split-mounted-to-shell",
            parent_part="case",
            parent_element="body_shell",
            child_part="case",
            child_element="hard_split_top",
            active_when=(ActiveWhen(factor="luggage_family", values=("hardshell_spinner",)),),
        ),
        RigidMount(
            name="pocket-zipper-mounted-to-pocket",
            parent_part="case",
            parent_element="front_pocket",
            child_part="case",
            child_element="pocket_zipper",
            active_when=(
                ActiveWhen(
                    factor="luggage_family",
                    values=("softside_spinner", "softside_rollaboard"),
                ),
            ),
        ),
        RigidMount(
            name="top-carry-handle-mounted-to-shell",
            parent_part="case",
            parent_element="body_shell",
            child_part="case",
            child_element="top_carry_handle",
        ),
        RigidMount(
            name="side-carry-handle-mounted-to-shell",
            parent_part="case",
            parent_element="body_shell",
            child_part="case",
            child_element="side_carry_handle",
            active_when=(ActiveWhen(factor="has_side_handle", values=(True,)),),
        ),
        RigidMount(
            name="left-rear-wheel-mounted-to-shell",
            parent_part="case",
            parent_element="body_shell",
            child_part="case",
            child_element="wheel_left_rear",
        ),
        RigidMount(
            name="right-rear-wheel-mounted-to-shell",
            parent_part="case",
            parent_element="body_shell",
            child_part="case",
            child_element="wheel_right_rear",
        ),
        RigidMount(
            name="left-front-spinner-mounted-to-shell",
            parent_part="case",
            parent_element="body_shell",
            child_part="case",
            child_element="wheel_left_front",
            active_when=(
                ActiveWhen(
                    factor="luggage_family", values=("hardshell_spinner", "softside_spinner")
                ),
            ),
        ),
        RigidMount(
            name="right-front-spinner-mounted-to-shell",
            parent_part="case",
            parent_element="body_shell",
            child_part="case",
            child_element="wheel_right_front",
            active_when=(
                ActiveWhen(
                    factor="luggage_family", values=("hardshell_spinner", "softside_spinner")
                ),
            ),
        ),
        RigidMount(
            name="left-rear-wheel-housing-mounted-to-shell",
            parent_part="case",
            parent_element="body_shell",
            child_part="case",
            child_element="wheel_housing_left_rear",
        ),
        RigidMount(
            name="right-rear-wheel-housing-mounted-to-shell",
            parent_part="case",
            parent_element="body_shell",
            child_part="case",
            child_element="wheel_housing_right_rear",
        ),
        RigidMount(
            name="left-front-caster-housing-mounted-to-shell",
            parent_part="case",
            parent_element="body_shell",
            child_part="case",
            child_element="wheel_housing_left_front",
            active_when=(
                ActiveWhen(
                    factor="luggage_family",
                    values=("hardshell_spinner", "softside_spinner"),
                ),
            ),
        ),
        RigidMount(
            name="right-front-caster-housing-mounted-to-shell",
            parent_part="case",
            parent_element="body_shell",
            child_part="case",
            child_element="wheel_housing_right_front",
            active_when=(
                ActiveWhen(
                    factor="luggage_family",
                    values=("hardshell_spinner", "softside_spinner"),
                ),
            ),
        ),
        RigidMount(
            name="left-trolley-sleeve-mounted-to-shell",
            parent_part="case",
            parent_element="body_shell",
            child_part="case",
            child_element="trolley_left_sleeve",
        ),
        RigidMount(
            name="right-trolley-sleeve-mounted-to-shell",
            parent_part="case",
            parent_element="body_shell",
            child_part="case",
            child_element="trolley_right_sleeve",
        ),
        JointMount(
            name="trolley-handle-guided-by-case",
            joint="case_to_trolley",
            parent_part="case",
            child_part="trolley_handle",
            allowed_joint_types=("prismatic",),
        ),
    ),
    build=build_model,
    tests=run_tests,
    constraints=(
        Constraint(
            name="top-carry-opening-remains-ordinary",
            predicate=lambda p: (
                p["top_handle_span"] - 2.0 * p["carry_handle_member_width"] >= 0.055
                and p["top_handle_rise"] - p["carry_handle_member_width"] >= 0.020
            ),
            message=(
                "Independent top-handle targets must retain an ordinary visible opening relative "
                "to the member section."
            ),
        ),
        Constraint(
            name="side-carry-opening-remains-ordinary",
            predicate=lambda p: (
                not p["has_side_handle"]
                or (
                    p["side_handle_span"] - 2.0 * p["carry_handle_member_width"] >= 0.065
                    and p["side_handle_rise"] - p["carry_handle_member_width"] >= 0.018
                )
            ),
            message=(
                "An active side handle must retain an ordinary visible opening relative to its "
                "member section."
            ),
        ),
        Constraint(
            name="large-checked-cases-retain-side-handle",
            predicate=lambda p: p["overall_height"] < 0.70 or p["has_side_handle"],
            message="Large checked cases retain the ordinary side lifting handle.",
        ),
    ),
    population_checks=(
        PopulationCheck(
            name="covers-common-families",
            predicate=lambda samples: (
                {sample["luggage_family"] for sample in samples}
                == {"hardshell_spinner", "softside_spinner", "softside_rollaboard"}
            ),
            message="Population must include all three authored shell/wheel families.",
        ),
        PopulationCheck(
            name="covers-side-handle-presence",
            predicate=lambda samples: (
                {sample["has_side_handle"] for sample in samples} == {False, True}
            ),
            message="Population must include cases with and without a side carry handle.",
        ),
        PopulationCheck(
            name="covers-overall-height-envelope",
            predicate=lambda samples: _covers_range(samples, "overall_height", 0.55, 0.79, 0.012),
            message="Population must exercise cabin and large checked heights.",
        ),
        PopulationCheck(
            name="covers-width-envelope",
            predicate=lambda samples: (
                min(float(s["case_width"]) for s in samples) <= 0.35
                and max(float(s["case_width"]) for s in samples) >= 0.53
            ),
            message="Population must exercise narrow cabin and broad checked case widths.",
        ),
        PopulationCheck(
            name="covers-trolley-travel-envelope",
            predicate=lambda samples: (
                min(float(s["trolley_extension"]) for s in samples) <= 0.33
                and max(float(s["trolley_extension"]) for s in samples) >= 0.40
            ),
            message="Population must exercise shorter and longer trolley travel envelopes.",
        ),
    ),
    task_requirements=(
        "Every suitcase must roll on two or four wheels that meet the shell and a common ground plane.",
        "Every suitcase must have a genuine two-root top carry handle mounted to the shell.",
        "The twin-rail trolley handle must retract through its prismatic travel while remaining connected to its rear guide plane without penetrating the shell.",
    ),
    tags=("suitcase", "luggage", "rolling", "telescoping_handle"),
)
