from __future__ import annotations

import math
from typing import Any, Mapping, Sequence

from assetengine import (
    ActiveWhen,
    Constraint,
    GeneratorDesign,
    GeneratorSpec,
    JointMount,
    PopulationCheck,
    RelativeUniformFloat,
    RigidMount,
    UniformChoice,
    UniformFloat,
    UniformInt,
)
from assetengine.articraft import (
    ArticulatedObject,
    ArticulationType,
    Box,
    Cylinder,
    MotionLimits,
    Origin,
    TestContext,
)

_WALL_THICKNESS = 0.035
_TOP_THICKNESS = 0.035
_BASE_THICKNESS = 0.055
_FRONT_APRON_HEIGHT = 0.120
_HINGE_HEIGHT = 0.080
_DOOR_THICKNESS = 0.045
_DOOR_GAP = 0.0
_HANDLE_ROOT_WIDTH = 0.030
_HANDLE_ROOT_HEIGHT = 0.035


def _burner_layout(parameters: Mapping[str, Any]) -> list[tuple[float, float, float]]:
    width = float(parameters["overall_width"])
    depth = float(parameters["overall_depth"])
    if parameters["surface_style"] == "smooth_electric":
        large = float(parameters["electric_large_zone_diameter"])
        small = float(parameters["electric_small_zone_diameter"])
    else:
        large = float(parameters["gas_large_cap_diameter"])
        small = float(parameters["gas_small_cap_diameter"])
    positions = [
        (-0.23 * width, -0.23 * depth, large),
        (0.23 * width, -0.23 * depth, small),
        (-0.23 * width, 0.23 * depth, small),
        (0.23 * width, 0.23 * depth, large),
    ]
    if int(parameters["burner_count"]) == 5:
        positions.append((0.0, 0.0, 0.92 * small))
    return positions


def build_model(parameters: Mapping[str, Any]) -> ArticulatedObject:
    width = float(parameters["overall_width"])
    depth = float(parameters["overall_depth"])
    body_height = float(parameters["cooktop_height"])
    window_width = float(parameters["window_width"])
    window_height = float(parameters["window_height"])
    handle_span = float(parameters["door_handle_span"])
    handle_projection = float(parameters["door_handle_projection"])
    open_angle = float(parameters["door_open_angle"])

    model = ArticulatedObject(name="oven_stove")
    metal = model.material("neutral_metal", rgba=(0.48, 0.50, 0.52, 1.0))
    dark = model.material("neutral_dark", rgba=(0.16, 0.17, 0.18, 1.0))
    cabinet = model.part("cabinet")

    wall_height = body_height - _TOP_THICKNESS
    cabinet.visual(
        Box((width, depth, _BASE_THICKNESS)),
        origin=Origin(xyz=(0.0, 0.0, 0.5 * _BASE_THICKNESS)),
        material=metal,
        name="cabinet_base",
    )
    for side, x in (
        ("left", -0.5 * width + 0.5 * _WALL_THICKNESS),
        ("right", 0.5 * width - 0.5 * _WALL_THICKNESS),
    ):
        cabinet.visual(
            Box((_WALL_THICKNESS, depth, wall_height)),
            origin=Origin(xyz=(x, 0.0, 0.5 * wall_height)),
            material=metal,
            name=f"{side}_wall",
        )
    cabinet.visual(
        Box((width - 2.0 * _WALL_THICKNESS, _WALL_THICKNESS, wall_height)),
        origin=Origin(xyz=(0.0, 0.5 * depth - 0.5 * _WALL_THICKNESS, 0.5 * wall_height)),
        material=dark,
        name="oven_back",
    )
    cabinet.visual(
        Box((width, depth, _TOP_THICKNESS)),
        origin=Origin(xyz=(0.0, 0.0, body_height - 0.5 * _TOP_THICKNESS)),
        material=metal,
        name="cooktop",
    )
    cabinet.visual(
        Box((width - 0.030, 0.025, 0.060)),
        origin=Origin(xyz=(0.0, -0.5 * depth + 0.0125, 0.030)),
        material=metal,
        name="storage_drawer_front",
    )

    if parameters["control_layout"] == "rear_backguard":
        panel_height, panel_depth = 0.225, 0.070
        panel_y = 0.5 * depth - 0.5 * panel_depth
        panel_z = body_height + 0.5 * panel_height
        knob_y = 0.5 * depth - panel_depth - 0.012
        knob_z = body_height + 0.53 * panel_height
        cabinet.visual(
            Box((width, 0.050, _FRONT_APRON_HEIGHT)),
            origin=Origin(
                xyz=(
                    0.0,
                    -0.5 * depth + 0.025,
                    body_height - _TOP_THICKNESS - 0.5 * _FRONT_APRON_HEIGHT,
                )
            ),
            material=metal,
            name="front_fascia",
        )
    else:
        panel_height, panel_depth = _FRONT_APRON_HEIGHT, 0.050
        panel_y = -0.5 * depth + 0.5 * panel_depth
        panel_z = body_height - _TOP_THICKNESS - 0.5 * panel_height
        knob_y = -0.5 * depth - 0.012
        knob_z = panel_z
    cabinet.visual(
        Box((width, panel_depth, panel_height)),
        origin=Origin(xyz=(0.0, panel_y, panel_z)),
        material=metal,
        name="control_panel",
    )
    burner_count = int(parameters["burner_count"])
    for index in range(burner_count):
        knob_x = (-0.38 + 0.55 * index / (burner_count - 1)) * width
        cabinet.visual(
            Cylinder(radius=0.021, length=0.024),
            origin=Origin(xyz=(knob_x, knob_y, knob_z), rpy=(0.5 * math.pi, 0.0, 0.0)),
            material=dark,
            name=f"control_knob_{index}",
        )
    cabinet.visual(
        Box((0.105, 0.010, 0.036)),
        origin=Origin(xyz=(0.32 * width, knob_y + 0.007, knob_z)),
        material=dark,
        name="oven_control_display",
    )

    surface_style = str(parameters["surface_style"])
    for index, (burner_x, burner_y, diameter) in enumerate(_burner_layout(parameters)):
        element_height = 0.0006 if surface_style == "smooth_electric" else 0.014
        element_z = (
            body_height - 0.5 * element_height
            if surface_style == "smooth_electric"
            else body_height + 0.5 * element_height
        )
        cabinet.visual(
            Cylinder(radius=0.5 * diameter, length=element_height),
            origin=Origin(xyz=(burner_x, burner_y, element_z)),
            material=dark,
            name=f"burner_{index}",
        )
        if surface_style == "gas_grates":
            grate_span = float(parameters["gas_grate_span"])
            grate_height = 0.012
            grate_width = 0.016
            grate_z = body_height + 0.028
            for suffix, size in (
                ("x", (grate_span, grate_width, grate_height)),
                ("y", (grate_width, grate_span, grate_height)),
            ):
                cabinet.visual(
                    Box(size),
                    origin=Origin(xyz=(burner_x, burner_y, grate_z)),
                    material=dark,
                    name=f"grate_{index}_{suffix}",
                )
            foot_height = grate_z - 0.5 * grate_height - body_height
            foot_offset = 0.5 * grate_span - 0.5 * grate_width
            for suffix, dx, dy in (
                ("left", -foot_offset, 0.0),
                ("right", foot_offset, 0.0),
                ("front", 0.0, -foot_offset),
                ("back", 0.0, foot_offset),
            ):
                cabinet.visual(
                    Box((grate_width, grate_width, foot_height)),
                    origin=Origin(
                        xyz=(
                            burner_x + dx,
                            burner_y + dy,
                            body_height + 0.5 * foot_height,
                        )
                    ),
                    material=dark,
                    name=f"grate_{index}_foot_{suffix}",
                )

    inner_width = width - 2.0 * _WALL_THICKNESS
    rack_z = _HINGE_HEIGHT + 0.31 * (body_height - _FRONT_APRON_HEIGHT - _HINGE_HEIGHT)
    for index in range(5):
        rack_y = (-0.22 + 0.11 * index) * depth
        cabinet.visual(
            Cylinder(radius=0.005, length=inner_width + 0.004),
            origin=Origin(xyz=(0.0, rack_y, rack_z), rpy=(0.0, 0.5 * math.pi, 0.0)),
            material=dark,
            name=f"oven_rack_bar_{index}",
        )

    door = model.part("oven_door")
    door_width = width - 0.020
    door_height = body_height - _FRONT_APRON_HEIGHT - _HINGE_HEIGHT - 0.025
    side_width = 0.5 * (door_width - window_width)
    rail_height = 0.5 * (door_height - window_height)
    door.visual(
        Box((side_width, _DOOR_THICKNESS, door_height)),
        origin=Origin(xyz=(-0.5 * door_width + 0.5 * side_width, 0.0, 0.5 * door_height)),
        material=metal,
        name="door_left_stile",
    )
    door.visual(
        Box((side_width, _DOOR_THICKNESS, door_height)),
        origin=Origin(xyz=(0.5 * door_width - 0.5 * side_width, 0.0, 0.5 * door_height)),
        material=metal,
        name="door_right_stile",
    )
    door.visual(
        Box((window_width, _DOOR_THICKNESS, rail_height)),
        origin=Origin(xyz=(0.0, 0.0, 0.5 * rail_height)),
        material=metal,
        name="door_lower_rail",
    )
    door.visual(
        Box((window_width, _DOOR_THICKNESS, rail_height)),
        origin=Origin(xyz=(0.0, 0.0, door_height - 0.5 * rail_height)),
        material=metal,
        name="door_upper_rail",
    )
    door.visual(
        Box((window_width + 0.018, 0.008, window_height + 0.018)),
        origin=Origin(xyz=(0.0, 0.010, 0.5 * door_height)),
        material=dark,
        name="door_window",
    )
    handle_z = door_height - 0.5 * rail_height
    for side, handle_x in (
        ("left", -0.5 * handle_span + 0.5 * _HANDLE_ROOT_WIDTH),
        ("right", 0.5 * handle_span - 0.5 * _HANDLE_ROOT_WIDTH),
    ):
        door.visual(
            Box((_HANDLE_ROOT_WIDTH, handle_projection, _HANDLE_ROOT_HEIGHT)),
            origin=Origin(
                xyz=(
                    handle_x,
                    -0.5 * _DOOR_THICKNESS - 0.5 * handle_projection,
                    handle_z,
                )
            ),
            material=metal,
            name=f"handle_root_{side}",
        )
    door.visual(
        Box((handle_span, 0.030, _HANDLE_ROOT_HEIGHT)),
        origin=Origin(xyz=(0.0, -0.5 * _DOOR_THICKNESS - handle_projection, handle_z)),
        material=metal,
        name="door_handle_bar",
    )
    model.articulation(
        "oven_door_hinge",
        ArticulationType.REVOLUTE,
        parent=cabinet,
        child=door,
        origin=Origin(
            xyz=(
                0.0,
                -0.5 * depth - _DOOR_GAP - 0.5 * _DOOR_THICKNESS,
                _HINGE_HEIGHT,
            )
        ),
        axis=(1.0, 0.0, 0.0),
        motion_limits=MotionLimits(effort=1.0, velocity=1.0, lower=0.0, upper=open_angle),
        meta={"qc_samples": [0.35 * open_angle, 0.70 * open_angle, open_angle]},
    )
    return model


def run_tests(model: ArticulatedObject, parameters: Mapping[str, Any]):
    width = float(parameters["overall_width"])
    body_height = float(parameters["cooktop_height"])
    ctx = TestContext(model)
    ctx.check_model_valid()
    if parameters["surface_style"] == "smooth_electric":
        large = float(parameters["electric_large_zone_diameter"])
        small = float(parameters["electric_small_zone_diameter"])
    else:
        large = float(parameters["gas_large_cap_diameter"])
        small = float(parameters["gas_small_cap_diameter"])
    ctx.check("burner-diameters-remain-ordered", large > small)
    ctx.check(
        "window-retains-substantial-door-frame",
        float(parameters["window_width"]) <= width - 0.14
        and float(parameters["window_height"])
        <= body_height - _FRONT_APRON_HEIGHT - _HINGE_HEIGHT - 0.16,
    )
    ctx.check(
        "handle-roots-retain-door-frame-material",
        float(parameters["door_handle_span"]) <= width - 0.04
        and float(parameters["door_handle_span"])
        >= float(parameters["window_width"]) + 2.0 * _HANDLE_ROOT_WIDTH,
    )
    ctx.check(
        "oven-cavity-has-positive-interior",
        width > 2.0 * _WALL_THICKNESS
        and float(parameters["overall_depth"]) > _WALL_THICKNESS
        and body_height > _BASE_THICKNESS + _TOP_THICKNESS + _FRONT_APRON_HEIGHT,
    )
    ctx.expect_joint_motion_axis(
        "oven_door_hinge",
        "oven_door",
        world_axis="y",
        direction="negative",
        min_delta=0.10,
        name="oven-door-swings-forward",
    )
    ctx.fail_if_articulation_overlaps(
        max_pose_samples=7,
        overlap_volume_tol=1e-8,
        name="oven-door-sweep-is-collision-free",
    )
    return ctx.report()


def _covers_choice(samples: Sequence[Mapping[str, Any]], factor: str, choices: set[object]) -> bool:
    return {sample[factor] for sample in samples} >= choices


def _covers_bounds(
    samples: Sequence[Mapping[str, Any]],
    factor: str,
    minimum_at_most: float,
    maximum_at_least: float,
) -> bool:
    values = [float(sample[factor]) for sample in samples]
    return min(values) <= minimum_at_most and max(values) >= maximum_at_least


GENERATOR = GeneratorSpec(
    name="oven_stove",
    category="oven_stove",
    description=(
        "Ordinary freestanding and slide-in household oven-ranges with a four- or "
        "five-position gas or smooth-electric cooktop, controls, an open oven cavity, "
        "and a forward-folding door."
    ),
    design=GeneratorDesign(
        coverage=(
            "The mainstream 30-inch-class household family spans 0.75-0.77 m widths, "
            "0.63-0.70 m depths, and 0.89-0.94 m cooking heights. Rear-backguard freestanding and "
            "low-front-control slide-in constructions each combine with four- or "
            "five-position smooth-electric and gas-grate cooktops. Every range retains "
            "a framed windowed hinged oven door, enclosed closed front, open interior cavity, "
            "rack, one control per cooking position, a distinct oven display, a lower drawer "
            "face, and a two-root horizontal handle. Compact and 36-inch pro-style ranges, wall "
            "ovens, separate cooktops, commercial ranges, double ovens, exposed-coil legacy "
            "ranges, wood stoves, countertop ovens, and decorative forms are excluded."
        ),
        factors=(
            "Mainstream cabinet width, depth, and cooktop height vary independently within the "
            "ordinary standard-width envelope. Control "
            "location, heat-source construction, and four/five-position layout are "
            "independent common topology choices. Electric-zone and gas-cap diameter intervals "
            "are construction-specific; gas grate span is separately conditional. Window "
            "spans and handle span scale with cabinet/body dimensions because their ordinary "
            "conditional envelopes move with the door, while handle projection and door "
            "opening angle use independent physical ranges. All stochastic factors are uniform."
        ),
        components=(
            "The connected cabinet shell exposes width, depth, height, control-panel placement, "
            "and a genuine front cavity. Cooktop construction varies between thin smooth-electric "
            "flush inset zones and smaller gas caps beneath elevated, footed cross grates; element "
            "count and construction-specific diameters vary. The oven door varies in framed window "
            "dimensions, handle span/projection, and opening angle. Cooking-control count follows "
            "element count, while wall, top, base, rack-stock, door thicknesses, and neutral finishes "
            "remain fixed as incidental detail rather than redundant controls."
        ),
        physics_and_task=(
            "Base, side walls, back, cooktop, apron/backguard, knobs, elements, and rack form "
            "one connected root cabinet; rear-control bodies add an ordinary fixed front fascia. "
            "Named rigid interfaces cover both cooktop side seats, panel, every active cooking "
            "control and burner, the oven display, both finite handle roots, and the window/frame "
            "seat. The separate door uses a bottom revolute JointMount and sweeps forward through "
            "its full sampled 80-90 degree range without cabinet collision. The shell leaves real "
            "interior free space; no robot-specific clearance or strength margin is inferred."
        ),
    ),
    factors=(
        UniformFloat(
            name="overall_width",
            low=0.75,
            high=0.77,
            description="Overall width within the mainstream 30-inch-class regime.",
            unit="m",
        ),
        UniformFloat(
            name="overall_depth",
            low=0.63,
            high=0.70,
            description="Independent front-to-back cabinet depth.",
            unit="m",
        ),
        UniformFloat(
            name="cooktop_height",
            low=0.89,
            high=0.94,
            description="Independent floor-to-cooking-surface height.",
            unit="m",
        ),
        UniformChoice(
            name="control_layout",
            choices=("rear_backguard", "front_apron"),
            description="Raised rear-control backguard or low front-control apron construction.",
        ),
        UniformChoice(
            name="surface_style",
            choices=("smooth_electric", "gas_grates"),
            description="Smooth electric zones or raised gas caps and cross grates.",
        ),
        UniformInt(
            name="burner_count",
            low=4,
            high=5,
            description="Four corner positions or four corners plus one center position.",
            unit="count",
        ),
        UniformFloat(
            name="electric_large_zone_diameter",
            low=0.20,
            high=0.25,
            active_when=(ActiveWhen(factor="surface_style", values=("smooth_electric",)),),
            description="Diameter of the larger flush electric cooking zones.",
            unit="m",
        ),
        UniformFloat(
            name="electric_small_zone_diameter",
            low=0.14,
            high=0.18,
            active_when=(ActiveWhen(factor="surface_style", values=("smooth_electric",)),),
            description="Diameter of the smaller flush electric cooking zones.",
            unit="m",
        ),
        UniformFloat(
            name="gas_large_cap_diameter",
            low=0.075,
            high=0.110,
            active_when=(ActiveWhen(factor="surface_style", values=("gas_grates",)),),
            description="Diameter of the larger gas burner caps beneath the grates.",
            unit="m",
        ),
        UniformFloat(
            name="gas_small_cap_diameter",
            low=0.055,
            high=0.080,
            active_when=(ActiveWhen(factor="surface_style", values=("gas_grates",)),),
            description="Diameter of the smaller gas burner caps beneath the grates.",
            unit="m",
        ),
        UniformFloat(
            name="gas_grate_span",
            low=0.19,
            high=0.24,
            active_when=(ActiveWhen(factor="surface_style", values=("gas_grates",)),),
            description="Outside span of each elevated, four-foot gas vessel support.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="window_width",
            reference="overall_width",
            ratio_low=0.45,
            ratio_high=0.70,
            description="Visible oven-window width relative to the cabinet width.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="window_height",
            reference="cooktop_height",
            ratio_low=0.28,
            ratio_high=0.42,
            hard_max=0.38,
            description="Visible oven-window height relative to the oven-front height.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="door_handle_span",
            reference="overall_width",
            ratio_low=0.78,
            ratio_high=0.92,
            description="Horizontal span of the oven-door pull.",
            unit="m",
        ),
        UniformFloat(
            name="door_handle_projection",
            low=0.045,
            high=0.075,
            description="Outward offset from door face to pull centerline.",
            unit="m",
        ),
        UniformFloat(
            name="door_open_angle",
            low=math.radians(80.0),
            high=math.radians(90.0),
            description="Maximum forward-folding oven-door travel from closed.",
            unit="rad",
        ),
    ),
    constraints=(
        Constraint(
            name="construction-specific-elements-remain-ordered",
            predicate=lambda p: (
                p["electric_large_zone_diameter"] > p["electric_small_zone_diameter"] + 0.015
                if p["surface_style"] == "smooth_electric"
                else p["gas_large_cap_diameter"] > p["gas_small_cap_diameter"] + 0.010
            ),
            message="Large cooking elements must remain larger within each construction.",
        ),
        Constraint(
            name="door-handle-roots-seat-on-frame",
            predicate=lambda p: (
                p["door_handle_span"] >= p["window_width"] + 2.0 * _HANDLE_ROOT_WIDTH
            ),
            message="Both handle roots must land on the solid side stiles.",
        ),
    ),
    relationships=(
        RigidMount(
            name="cooktop-seated-on-left-wall",
            parent_part="cabinet",
            parent_element="left_wall",
            child_part="cabinet",
            child_element="cooktop",
            contact_tolerance=2e-5,
        ),
        RigidMount(
            name="cooktop-seated-on-right-wall",
            parent_part="cabinet",
            parent_element="right_wall",
            child_part="cabinet",
            child_element="cooktop",
            contact_tolerance=2e-5,
        ),
        RigidMount(
            name="control-panel-mounted-to-cooktop",
            parent_part="cabinet",
            parent_element="cooktop",
            child_part="cabinet",
            child_element="control_panel",
            contact_tolerance=2e-5,
        ),
        *tuple(
            RigidMount(
                name=f"control-knob-{index}-mounted-to-panel",
                parent_part="cabinet",
                parent_element="control_panel",
                child_part="cabinet",
                child_element=f"control_knob_{index}",
                contact_tolerance=2e-5,
            )
            for index in range(4)
        ),
        RigidMount(
            name="control-knob-4-mounted-to-panel",
            parent_part="cabinet",
            parent_element="control_panel",
            child_part="cabinet",
            child_element="control_knob_4",
            contact_tolerance=2e-5,
            active_when=(ActiveWhen(factor="burner_count", values=(5,)),),
        ),
        RigidMount(
            name="oven-display-mounted-to-panel",
            parent_part="cabinet",
            parent_element="control_panel",
            child_part="cabinet",
            child_element="oven_control_display",
            contact_tolerance=2e-5,
        ),
        *tuple(
            RigidMount(
                name=f"burner-{index}-mounted-to-cooktop",
                parent_part="cabinet",
                parent_element="cooktop",
                child_part="cabinet",
                child_element=f"burner_{index}",
                contact_tolerance=2e-5,
            )
            for index in range(4)
        ),
        RigidMount(
            name="burner-4-mounted-to-cooktop",
            parent_part="cabinet",
            parent_element="cooktop",
            child_part="cabinet",
            child_element="burner_4",
            contact_tolerance=2e-5,
            active_when=(ActiveWhen(factor="burner_count", values=(5,)),),
        ),
        RigidMount(
            name="left-handle-root-seated-on-door",
            parent_part="oven_door",
            parent_element="door_left_stile",
            child_part="oven_door",
            child_element="handle_root_left",
            contact_tolerance=2e-5,
        ),
        RigidMount(
            name="right-handle-root-seated-on-door",
            parent_part="oven_door",
            parent_element="door_right_stile",
            child_part="oven_door",
            child_element="handle_root_right",
            contact_tolerance=2e-5,
        ),
        RigidMount(
            name="window-seated-in-door-frame",
            parent_part="oven_door",
            parent_element="door_upper_rail",
            child_part="oven_door",
            child_element="door_window",
            contact_tolerance=2e-5,
        ),
        JointMount(
            name="oven-door-hinged-to-cabinet",
            joint="oven_door_hinge",
            parent_part="cabinet",
            child_part="oven_door",
            allowed_joint_types=("revolute",),
        ),
    ),
    build=build_model,
    tests=run_tests,
    population_checks=(
        PopulationCheck(
            name="covers-mainstream-width-envelope",
            predicate=lambda samples: _covers_bounds(samples, "overall_width", 0.7505, 0.7695),
            message="Population must exercise the mainstream width envelope.",
        ),
        PopulationCheck(
            name="covers-control-constructions",
            predicate=lambda samples: _covers_choice(
                samples, "control_layout", {"rear_backguard", "front_apron"}
            ),
            message="Population must include rear- and front-control constructions.",
        ),
        PopulationCheck(
            name="covers-cooktop-constructions",
            predicate=lambda samples: _covers_choice(
                samples, "surface_style", {"smooth_electric", "gas_grates"}
            ),
            message="Population must include smooth-electric and gas-grate cooktops.",
        ),
        PopulationCheck(
            name="covers-four-and-five-position-layouts",
            predicate=lambda samples: _covers_choice(samples, "burner_count", {4, 5}),
            message="Population must include four- and five-position layouts.",
        ),
        PopulationCheck(
            name="covers-depth-envelope",
            predicate=lambda samples: _covers_bounds(samples, "overall_depth", 0.631, 0.699),
            message="Population must exercise the 0.63-0.70 m depth envelope.",
        ),
        PopulationCheck(
            name="covers-cooktop-height-envelope",
            predicate=lambda samples: _covers_bounds(samples, "cooktop_height", 0.891, 0.939),
            message="Population must exercise the 0.89-0.94 m height envelope.",
        ),
        PopulationCheck(
            name="covers-construction-specific-element-envelopes",
            predicate=lambda samples: (
                _covers_bounds(samples, "electric_large_zone_diameter", 0.202, 0.248)
                and _covers_bounds(samples, "electric_small_zone_diameter", 0.142, 0.178)
                and _covers_bounds(samples, "gas_large_cap_diameter", 0.077, 0.108)
                and _covers_bounds(samples, "gas_small_cap_diameter", 0.057, 0.078)
                and _covers_bounds(samples, "gas_grate_span", 0.192, 0.238)
            ),
            message="Population must exercise electric-zone, gas-cap, and grate envelopes.",
        ),
        PopulationCheck(
            name="covers-door-motion-envelope",
            predicate=lambda samples: _covers_bounds(
                samples,
                "door_open_angle",
                math.radians(80.0) + 0.005,
                math.radians(90.0) - 0.005,
            ),
            message="Population must exercise the oven-door opening-angle envelope.",
        ),
    ),
    task_requirements=(
        "Every instance must contain a genuine oven cavity beneath a multi-position cooktop.",
        "The oven door must remain hinged and open forward without collision.",
        "The two-root door handle and every active cooking element must remain mounted.",
    ),
    tags=("oven", "stove", "range", "gas", "electric", "hinged door"),
)
