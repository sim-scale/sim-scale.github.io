from __future__ import annotations

import math
from typing import Any, Mapping, Sequence

from assetengine import (
    ActiveWhen,
    Constraint,
    Derived,
    GeneratorDesign,
    GeneratorSpec,
    PopulationCheck,
    RelativeUniformFloat,
    RigidMount,
    UniformChoice,
    UniformFloat,
    UniformInt,
)
from assetengine.articraft import (
    ArticulatedObject,
    Cylinder,
    ExtrudeGeometry,
    ExtrudeWithHolesGeometry,
    LoftGeometry,
    Material,
    Origin,
    TestContext,
    mesh_from_geometry,
    rounded_rect_profile,
)


_NEUTRAL_MATERIAL = Material(name="neutral_appliance_material", rgba=(0.48, 0.49, 0.50, 1.0))
_SEAM_GAP = 0.002
_ZONE_MARKER_RELIEF = 0.00005
_CONTROL_RELIEF = 0.00035


def _circle_profile(diameter: float, segments: int = 64) -> list[tuple[float, float]]:
    radius = 0.5 * diameter
    return [
        (
            radius * math.cos(2.0 * math.pi * index / segments),
            radius * math.sin(2.0 * math.pi * index / segments),
        )
        for index in range(segments)
    ]


def _loft_profile(
    width: float,
    depth: float,
    radius: float,
    z: float,
) -> list[tuple[float, float, float]]:
    return [
        (x, y, z)
        for x, y in rounded_rect_profile(
            width,
            depth,
            radius,
            corner_segments=8,
        )
    ]


def _control_count_values(index: int) -> tuple[int, ...]:
    return tuple(count for count in range(4, 8) if count > index)


def _span_reaches(
    samples: Sequence[Mapping[str, Any]],
    factor: str,
    low: float,
    high: float,
) -> bool:
    values = [float(sample[factor]) for sample in samples]
    return min(values) <= low and max(values) >= high


def build_model(parameters: Mapping[str, Any]) -> ArticulatedObject:
    width = float(parameters["overall_width"])
    depth = float(parameters["overall_depth"])
    overall_height = float(parameters["overall_height"])
    taper = float(parameters["housing_taper_inset"])
    corner_radius = float(parameters["housing_corner_radius"])
    edge_inset = float(parameters["plate_edge_inset"])
    control_depth = float(parameters["control_strip_depth"])
    plate_thickness = float(parameters["plate_thickness"])
    foot_height = float(parameters["foot_height"])
    foot_diameter = float(parameters["foot_diameter"])
    foot_edge_inset = float(parameters["foot_edge_inset"])
    construction = str(parameters["surface_construction"])
    control_layout = str(parameters["control_layout"])
    zone_diameter = float(parameters["zone_diameter"])
    zone_marker_width = float(parameters["zone_marker_width"])
    control_count = int(parameters["control_count"])
    control_pad_diameter = float(parameters["control_pad_diameter"])
    display_width = float(parameters["display_width"])

    chassis_height = overall_height - foot_height - plate_thickness
    chassis_top_z = foot_height + chassis_height
    top_width = width - 2.0 * taper
    top_depth = depth - 2.0 * taper
    top_radius = max(0.003, corner_radius - taper)
    plate_width = top_width - 2.0 * edge_inset
    usable_depth = top_depth - 2.0 * edge_inset
    plate_radius = max(0.0025, top_radius - edge_inset)

    usable_front_y = -0.5 * top_depth + edge_inset
    usable_rear_y = 0.5 * top_depth - edge_inset
    cooking_front_y = usable_front_y + control_depth + 0.5 * _SEAM_GAP
    cooking_rear_y = usable_rear_y
    cooking_depth = cooking_rear_y - cooking_front_y
    zone_center_y = 0.5 * (cooking_front_y + cooking_rear_y)

    model = ArticulatedObject(name="portable_single_zone_induction_cooktop")
    appliance = model.part("appliance")

    housing_geometry = LoftGeometry(
        (
            _loft_profile(width, depth, corner_radius, 0.0),
            _loft_profile(top_width, top_depth, top_radius, chassis_height),
        ),
        cap=True,
        closed=True,
    )
    appliance.visual(
        mesh_from_geometry(housing_geometry, "induction_cooktop_housing"),
        origin=Origin(xyz=(0.0, 0.0, foot_height)),
        material=_NEUTRAL_MATERIAL,
        name="housing",
    )

    if construction == "full_glass_deck":
        cooking_surface_depth = usable_depth
        cooking_surface_center_y = 0.0
        control_surface_top_z = chassis_top_z + plate_thickness
    else:
        cooking_surface_depth = cooking_depth
        cooking_surface_center_y = zone_center_y
        console_depth = control_depth - 0.5 * _SEAM_GAP
        console_center_y = usable_front_y + 0.5 * console_depth
        console_thickness = 0.72 * plate_thickness
        console_geometry = ExtrudeGeometry(
            rounded_rect_profile(
                plate_width,
                console_depth,
                min(plate_radius, 0.45 * console_depth),
                corner_segments=8,
            ),
            console_thickness,
            cap=True,
            center=True,
        )
        appliance.visual(
            mesh_from_geometry(console_geometry, "induction_cooktop_control_console"),
            origin=Origin(
                xyz=(
                    0.0,
                    console_center_y,
                    chassis_top_z + 0.5 * console_thickness,
                )
            ),
            material=_NEUTRAL_MATERIAL,
            name="control_console",
        )
        control_surface_top_z = chassis_top_z + console_thickness

    cooking_surface_geometry = ExtrudeGeometry(
        rounded_rect_profile(
            plate_width,
            cooking_surface_depth,
            min(plate_radius, 0.45 * cooking_surface_depth),
            corner_segments=8,
        ),
        plate_thickness,
        cap=True,
        center=True,
    )
    zone_local_y = zone_center_y - cooking_surface_center_y
    cavity_outer = _circle_profile(zone_diameter)
    cavity_inner = _circle_profile(zone_diameter - 2.0 * zone_marker_width)
    surface_origin = Origin(
        xyz=(
            0.0,
            cooking_surface_center_y,
            chassis_top_z + 0.5 * plate_thickness,
        )
    )
    appliance.visual(
        mesh_from_geometry(cooking_surface_geometry, "induction_cooktop_cooking_surface"),
        origin=surface_origin,
        material=_NEUTRAL_MATERIAL,
        name="cooking_surface",
    )

    zone_inlay_geometry = ExtrudeWithHolesGeometry(
        cavity_outer,
        (cavity_inner,),
        _ZONE_MARKER_RELIEF,
        cap=True,
        center=True,
        closed=True,
    ).translate(
        0.0,
        zone_local_y,
        0.5 * plate_thickness + 0.5 * _ZONE_MARKER_RELIEF,
    )
    appliance.visual(
        mesh_from_geometry(zone_inlay_geometry, "induction_cooktop_zone_inlay"),
        origin=surface_origin,
        material=_NEUTRAL_MATERIAL,
        name="zone_inlay",
    )

    console_depth = control_depth - 0.5 * _SEAM_GAP
    control_center_y = usable_front_y + 0.5 * console_depth
    display_depth = min(0.016, 0.34 * console_depth)
    if control_layout == "wide_split_row":
        display_center_x = -0.28 * plate_width
        control_row_left = 0.0
        control_row_right = 0.5 * plate_width - 0.018
        control_centers = [
            control_row_left + index * (control_row_right - control_row_left) / (control_count - 1)
            for index in range(control_count)
        ]
    else:
        control_gap = 0.006
        group_width = (
            display_width + control_count * control_pad_diameter + control_count * control_gap
        )
        group_left = -0.5 * group_width
        display_center_x = group_left + 0.5 * display_width
        first_control_x = group_left + display_width + control_gap + 0.5 * control_pad_diameter
        control_centers = [
            first_control_x + index * (control_pad_diameter + control_gap)
            for index in range(control_count)
        ]
    appliance.visual(
        mesh_from_geometry(
            ExtrudeGeometry(
                rounded_rect_profile(
                    display_width,
                    display_depth,
                    min(0.002, 0.2 * display_depth),
                    corner_segments=4,
                ),
                _CONTROL_RELIEF,
                cap=True,
                center=True,
            ),
            "induction_cooktop_display_window",
        ),
        origin=Origin(
            xyz=(
                display_center_x,
                control_center_y,
                control_surface_top_z + 0.5 * _CONTROL_RELIEF,
            )
        ),
        material=_NEUTRAL_MATERIAL,
        name="display_window",
    )

    for index, center_x in enumerate(control_centers):
        appliance.visual(
            Cylinder(0.5 * control_pad_diameter, _CONTROL_RELIEF),
            origin=Origin(
                xyz=(
                    center_x,
                    control_center_y,
                    control_surface_top_z + 0.5 * _CONTROL_RELIEF,
                )
            ),
            material=_NEUTRAL_MATERIAL,
            name=f"control_pad_{index}",
        )

    foot_x = 0.5 * width - foot_edge_inset
    foot_y = 0.5 * depth - foot_edge_inset
    for name, x, y in (
        ("front_left_foot", -foot_x, -foot_y),
        ("front_right_foot", foot_x, -foot_y),
        ("rear_left_foot", -foot_x, foot_y),
        ("rear_right_foot", foot_x, foot_y),
    ):
        appliance.visual(
            Cylinder(0.5 * foot_diameter, foot_height),
            origin=Origin(xyz=(x, y, 0.5 * foot_height)),
            material=_NEUTRAL_MATERIAL,
            name=name,
        )

    return model


def run_tests(model: ArticulatedObject, parameters: Mapping[str, Any]):
    ctx = TestContext(model)
    appliance = model.get_part("appliance")
    construction = str(parameters["surface_construction"])
    parent_surface = "cooking_surface" if construction == "full_glass_deck" else "control_console"

    ctx.check(
        "single-zone-marker-fits-cooking-deck",
        float(parameters["zone_diameter"]) <= float(parameters["usable_zone_span"]),
    )
    ctx.check(
        "controls-remain-forward-of-zone",
        float(parameters["control_strip_depth"]) + 0.5 * float(parameters["zone_diameter"])
        <= float(parameters["overall_depth"]),
    )
    ctx.check(
        "zone-marker-is-not-a-raised-burner",
        _ZONE_MARKER_RELIEF <= 0.0001,
        "The annulus is only a mesh-stable proxy for a printed surface indicator.",
    )
    ctx.expect_within(
        appliance,
        appliance,
        axes="xy",
        inner_elem="zone_inlay",
        outer_elem="cooking_surface",
        margin=1e-6,
        name="zone-inlay-contained-by-cooking-surface",
    )
    ctx.expect_contact(
        appliance,
        appliance,
        elem_a="zone_inlay",
        elem_b="cooking_surface",
        contact_tol=1e-6,
        name="flush-zone-inlay-seated",
    )

    foot_diameter = float(parameters["foot_diameter"])
    for foot_name in (
        "front_left_foot",
        "front_right_foot",
        "rear_left_foot",
        "rear_right_foot",
    ):
        ctx.expect_overlap(
            appliance,
            appliance,
            axes="xy",
            min_overlap=0.8 * foot_diameter,
            elem_a="housing",
            elem_b=foot_name,
            name=f"{foot_name}-finite-root-footprint",
        )
        ctx.expect_gap(
            appliance,
            appliance,
            axis="z",
            min_gap=-1e-6,
            max_gap=1e-6,
            positive_elem="housing",
            negative_elem=foot_name,
            name=f"{foot_name}-root-plane-seated",
        )

    control_pad_diameter = float(parameters["control_pad_diameter"])
    for index in range(int(parameters["control_count"])):
        ctx.expect_overlap(
            appliance,
            appliance,
            axes="xy",
            min_overlap=0.8 * control_pad_diameter,
            elem_a=parent_surface,
            elem_b=f"control_pad_{index}",
            name=f"control-pad-{index}-footprint",
        )
        ctx.expect_gap(
            appliance,
            appliance,
            axis="z",
            min_gap=-1e-6,
            max_gap=1e-6,
            positive_elem=f"control_pad_{index}",
            negative_elem=parent_surface,
            name=f"control-pad-{index}-surface-seated",
        )

    ctx.expect_overlap(
        appliance,
        appliance,
        axes="xy",
        min_overlap=0.8 * min(float(parameters["display_width"]), 0.016),
        elem_a=parent_surface,
        elem_b="display_window",
        name="display-window-footprint",
    )
    ctx.expect_gap(
        appliance,
        appliance,
        axis="z",
        min_gap=-1e-6,
        max_gap=1e-6,
        positive_elem="display_window",
        negative_elem=parent_surface,
        name="display-window-surface-seated",
    )
    return ctx.report()


_relationships: list[RigidMount] = [
    RigidMount(
        name="cooking-surface-mounted-to-housing",
        parent_part="appliance",
        parent_element="housing",
        child_part="appliance",
        child_element="cooking_surface",
    ),
    RigidMount(
        name="zone-inlay-mounted-to-cooking-surface",
        parent_part="appliance",
        parent_element="cooking_surface",
        child_part="appliance",
        child_element="zone_inlay",
    ),
    RigidMount(
        name="control-console-mounted-to-housing",
        parent_part="appliance",
        parent_element="housing",
        child_part="appliance",
        child_element="control_console",
        active_when=(
            ActiveWhen(factor="surface_construction", values=("separate_front_console",)),
        ),
    ),
    RigidMount(
        name="display-mounted-to-full-glass-deck",
        parent_part="appliance",
        parent_element="cooking_surface",
        child_part="appliance",
        child_element="display_window",
        active_when=(ActiveWhen(factor="surface_construction", values=("full_glass_deck",)),),
    ),
    RigidMount(
        name="display-mounted-to-front-console",
        parent_part="appliance",
        parent_element="control_console",
        child_part="appliance",
        child_element="display_window",
        active_when=(
            ActiveWhen(factor="surface_construction", values=("separate_front_console",)),
        ),
    ),
]

for _foot_name in (
    "front_left_foot",
    "front_right_foot",
    "rear_left_foot",
    "rear_right_foot",
):
    _relationships.append(
        RigidMount(
            name=f"{_foot_name.replace('_', '-')}-mounted-to-housing",
            parent_part="appliance",
            parent_element="housing",
            child_part="appliance",
            child_element=_foot_name,
        )
    )

for _pad_index in range(7):
    _count_rule = ()
    if _pad_index >= 4:
        _count_rule = (
            ActiveWhen(
                factor="control_count",
                values=_control_count_values(_pad_index),
            ),
        )
    _relationships.extend(
        (
            RigidMount(
                name=f"control-pad-{_pad_index}-mounted-to-full-glass-deck",
                parent_part="appliance",
                parent_element="cooking_surface",
                child_part="appliance",
                child_element=f"control_pad_{_pad_index}",
                active_when=(
                    ActiveWhen(
                        factor="surface_construction",
                        values=("full_glass_deck",),
                    ),
                    *_count_rule,
                ),
            ),
            RigidMount(
                name=f"control-pad-{_pad_index}-mounted-to-front-console",
                parent_part="appliance",
                parent_element="control_console",
                child_part="appliance",
                child_element=f"control_pad_{_pad_index}",
                active_when=(
                    ActiveWhen(
                        factor="surface_construction",
                        values=("separate_front_console",),
                    ),
                    *_count_rule,
                ),
            ),
        )
    )


GENERATOR = GeneratorSpec(
    name="induction_cooktop",
    category="induction_cooktop",
    description="Generate ordinary portable single-zone household induction cooktops. Exclude cookware, raised burners, protective rails, decorations, and obstructive controls.",
    design=GeneratorDesign(
        coverage=(
            "Portable countertop single-zone induction units with either one full glass top or "
            "a distinct flush front control console and either a wide split control row or centered "
            "control group. The population spans compact through larger "
            "ordinary household footprints, low through deeper tapered housings, rounded corners, "
            "one flat cooking zone, and four countertop feet. Built-in multi-zone hobs, commercial "
            "units, cookware, raised burner solids, rails, decorative attachments, and protruding "
            "knobs are excluded. Flexible cords and hidden internal electronics are incidental and "
            "not modeled."
        ),
        factors=(
            "Width, depth, overall height, housing taper, corner radius, glass edge inset, foot "
            "dimensions, control layout, control count and size, display width, marker line width, "
            "and the 0.14–0.22 m zone diameter vary over independent ordinary intervals. Control-strip "
            "depth moves with overall depth because the front interface occupies a comparable "
            "fraction of portable housings. Only a named fit constraint removes zone/deck combinations "
            "without an ordinary edge margin; construction coordinates and chassis height are exact "
            "derived consequences."
        ),
        components=(
            "A rounded tapered housing supports a thin glass cooking surface, a printed-zone "
            "indicator represented by 50 micrometers of mesh relief, a low-relief display and "
            "touch-pad row, and four cylindrical feet. The surface construction changes whether "
            "controls share the full glass deck or use a separate front console; the control-layout "
            "branch changes between a broad split row and one compact centered group. Neutral "
            "material, tiny seam depth, pad relief, and internal construction details stay fixed "
            "because they are incidental rather than appreciable shape axes."
        ),
        physics_and_task=(
            "The glass plate and optional console are permanently seated on finite top footprints; "
            "the near-flush printed-zone proxy is seated on the glass; every display, touch pad, and foot has "
            "a declared rigid interface. All four feet terminate on one support plane. Controls stay "
            "in the front strip outside the single cooking-zone footprint and use only low surface "
            "relief, with no inferred robot, utensil, or cookware clearance threshold."
        ),
    ),
    factors=(
        UniformChoice(
            name="surface_construction",
            choices=("full_glass_deck", "separate_front_console"),
            description="Common top construction: controls share the glass deck or occupy a separate flush front console.",
        ),
        UniformChoice(
            name="control_layout",
            choices=("wide_split_row", "centered_group"),
            description="Front control composition: a broad display-and-pad split or one centered compact group.",
        ),
        UniformFloat(
            name="overall_width",
            low=0.25,
            high=0.33,
            description="Overall left-to-right appliance width.",
            unit="m",
        ),
        UniformFloat(
            name="overall_depth",
            low=0.30,
            high=0.42,
            description="Overall front-to-rear appliance depth.",
            unit="m",
        ),
        UniformFloat(
            name="overall_height",
            low=0.042,
            high=0.072,
            description="Total support-plane-to-cooking-surface height.",
            unit="m",
        ),
        UniformFloat(
            name="housing_taper_inset",
            low=0.0,
            high=0.012,
            description="Per-side inward offset from the housing base outline to its top outline.",
            unit="m",
        ),
        UniformFloat(
            name="housing_corner_radius",
            low=0.006,
            high=0.026,
            description="Plan-view corner radius of the lower housing outline.",
            unit="m",
        ),
        UniformFloat(
            name="plate_edge_inset",
            low=0.003,
            high=0.010,
            description="Inset of the usable top surfaces from the tapered housing top edge.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="control_strip_depth",
            reference="overall_depth",
            ratio_low=0.16,
            ratio_high=0.24,
            hard_min=0.050,
            hard_max=0.092,
            description="Front-to-rear depth reserved for the unobstructive control strip.",
            unit="m",
        ),
        UniformFloat(
            name="plate_thickness",
            low=0.0035,
            high=0.0065,
            description="Thickness of the flat glass cooking plate.",
            unit="m",
        ),
        UniformFloat(
            name="foot_diameter",
            low=0.015,
            high=0.022,
            description="Diameter of each of the four countertop feet.",
            unit="m",
        ),
        UniformFloat(
            name="foot_height",
            low=0.004,
            high=0.008,
            description="Height of each countertop foot below the housing.",
            unit="m",
        ),
        UniformFloat(
            name="foot_edge_inset",
            low=0.018,
            high=0.028,
            description="Distance from each outer housing edge to the corresponding foot center.",
            unit="m",
        ),
        UniformInt(
            name="control_count",
            low=4,
            high=7,
            description="Number of flush touch-control pads in the front row.",
            unit="count",
        ),
        UniformFloat(
            name="control_pad_diameter",
            low=0.008,
            high=0.014,
            description="Plan-view diameter of each low-relief touch-control pad.",
            unit="m",
        ),
        UniformFloat(
            name="display_width",
            low=0.030,
            high=0.055,
            description="Left-to-right width of the flush front display window.",
            unit="m",
        ),
        UniformFloat(
            name="zone_marker_width",
            low=0.0015,
            high=0.0035,
            description="Radial line width of the near-flush printed cooking-zone indicator.",
            unit="m",
        ),
        Derived(
            name="usable_zone_span",
            derive=lambda p: min(
                p["overall_width"] - 2.0 * (p["housing_taper_inset"] + p["plate_edge_inset"]),
                p["overall_depth"]
                - 2.0 * (p["housing_taper_inset"] + p["plate_edge_inset"])
                - p["control_strip_depth"]
                - _SEAM_GAP,
            ),
            depends_on=(
                "overall_width",
                "overall_depth",
                "housing_taper_inset",
                "plate_edge_inset",
                "control_strip_depth",
            ),
            description="Smaller clear plan span of the cooking region after edges and controls.",
            unit="m",
        ),
        UniformFloat(
            name="zone_diameter",
            low=0.14,
            high=0.22,
            description="Independent absolute diameter target of the single near-flush cooking-zone marker.",
            unit="m",
        ),
    ),
    relationships=tuple(_relationships),
    constraints=(
        Constraint(
            name="zone-fits-clear-cooking-region",
            predicate=lambda p: p["zone_diameter"] + 0.008 <= p["usable_zone_span"],
            message="The independent cooking-zone target must retain at least 4 mm of clear deck on each limiting side.",
        ),
    ),
    build=build_model,
    tests=run_tests,
    population_checks=(
        PopulationCheck(
            name="both-surface-constructions",
            predicate=lambda samples: (
                {sample["surface_construction"] for sample in samples}
                == {"full_glass_deck", "separate_front_console"}
            ),
            message="Population must include both common surface constructions.",
        ),
        PopulationCheck(
            name="both-control-layouts",
            predicate=lambda samples: (
                {sample["control_layout"] for sample in samples}
                == {"wide_split_row", "centered_group"}
            ),
            message="Population must include both ordinary front control compositions.",
        ),
        PopulationCheck(
            name="ordinary-footprint-span",
            predicate=lambda samples: (
                _span_reaches(samples, "overall_width", 0.251, 0.329)
                and _span_reaches(samples, "overall_depth", 0.302, 0.418)
            ),
            message="Population must reach compact and larger ordinary countertop footprints.",
        ),
        PopulationCheck(
            name="ordinary-height-span",
            predicate=lambda samples: _span_reaches(samples, "overall_height", 0.043, 0.071),
            message="Population must reach both low-profile and deeper ordinary housings.",
        ),
        PopulationCheck(
            name="control-count-span",
            predicate=lambda samples: (
                min(sample["control_count"] for sample in samples) == 4
                and max(sample["control_count"] for sample in samples) == 7
            ),
            message="Population must exercise the full ordinary touch-control count interval.",
        ),
        PopulationCheck(
            name="zone-diameter-span",
            predicate=lambda samples: (
                min(sample["zone_diameter"] for sample in samples) <= 0.15
                and max(sample["zone_diameter"] for sample in samples) >= 0.215
            ),
            message="Population must include smaller and larger ordinary single cooking zones.",
        ),
    ),
    task_requirements=(
        "Every instance must have exactly one flat, surface-marked cooking zone with clear volume above it.",
        "Controls must remain on the front surface strip and must not form protruding knobs or obstruct the cooking zone.",
        "Cookware, raised burner solids, protective rails, and decorative attachments must be absent.",
        "The housing, cooking surface, controls, display, and all four countertop feet must remain physically integrated.",
    ),
    tags=(
        "induction cooktop",
        "portable appliance",
        "single zone",
        "flush cooking surface",
        "front touch controls",
    ),
)

del _foot_name, _pad_index, _count_rule
