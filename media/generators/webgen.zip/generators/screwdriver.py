from __future__ import annotations

import math
from typing import Any, Mapping, Sequence

from assetengine import (
    ActiveWhen,
    Derived,
    GeneratorDesign,
    GeneratorSpec,
    PopulationCheck,
    RelativeUniformFloat,
    RigidMount,
    UniformChoice,
    UniformFloat,
)
from assetengine.articraft import (
    ArticulatedObject,
    LoftGeometry,
    Origin,
    TestContext,
    mesh_from_geometry,
)

_PROFILE_SEGMENTS = 48


def _active_dimension(parameters: Mapping[str, Any], stem: str) -> float:
    return float(parameters[f"{parameters['size_family']}_{stem}"])


def _resolve_handle_length(parameters: Mapping[str, Any]) -> float:
    return _active_dimension(parameters, "handle_length")


def _resolve_handle_diameter(parameters: Mapping[str, Any]) -> float:
    return _active_dimension(parameters, "handle_diameter")


def _resolve_shaft_length(parameters: Mapping[str, Any]) -> float:
    return _active_dimension(parameters, "shaft_length")


def _resolve_shaft_diameter(parameters: Mapping[str, Any]) -> float:
    return _active_dimension(parameters, "shaft_diameter")


def _resolve_tip_width(parameters: Mapping[str, Any]) -> float:
    return float(parameters[f"{parameters['tip_profile']}_tip_width"])


def _resolve_tip_length(parameters: Mapping[str, Any]) -> float:
    return float(parameters[f"{parameters['tip_profile']}_tip_length"])


def _resolve_tip_thickness_ratio(parameters: Mapping[str, Any]) -> float:
    profile = str(parameters["tip_profile"])
    if profile == "slotted":
        return float(parameters["slotted_tip_thickness_ratio"])
    if profile == "cruciform":
        return float(parameters["cruciform_arm_ratio"])
    return 0.0


def _circle_angles(count: int = _PROFILE_SEGMENTS) -> list[float]:
    return [2.0 * math.pi * index / count for index in range(count)]


def _handle_section(
    z: float,
    radius: float,
    section: str,
    lobing: float,
) -> list[tuple[float, float, float]]:
    points = []
    angle_count = 12 if section == "faceted" else _PROFILE_SEGMENTS
    for theta in _circle_angles(angle_count):
        modulation = 1.0
        if section == "six_lobed":
            modulation += lobing * math.cos(6.0 * theta)
        points.append(
            (
                radius * modulation * math.cos(theta),
                radius * modulation * math.sin(theta),
                z,
            )
        )
    return points


def _handle_geometry(parameters: Mapping[str, Any]) -> LoftGeometry:
    length = float(parameters["handle_length"])
    outer_radius = 0.5 * float(parameters["handle_diameter"])
    neck_ratio = float(parameters["handle_neck_ratio"])
    crown_ratio = float(parameters["handle_crown_ratio"])
    section = str(parameters["handle_cross_section"])
    lobing = float(parameters["handle_lobing"]) if section == "six_lobed" else 0.0

    if parameters["size_family"] == "standard":
        controls = (
            (0.0, neck_ratio),
            (0.08, max(neck_ratio + 0.10, 0.72)),
            (0.28, 1.0),
            (0.62, 0.90),
            (0.78, 0.96),
            (0.95, crown_ratio),
            (1.0, 0.82 * crown_ratio),
        )
    else:
        controls = (
            (0.0, neck_ratio),
            (0.10, max(neck_ratio + 0.12, 0.76)),
            (0.34, 1.0),
            (0.72, 0.98),
            (0.92, max(crown_ratio, 0.78)),
            (1.0, max(0.72, 0.88 * crown_ratio)),
        )
    rails = []
    samples_per_interval = 6
    for interval_index, ((z0, r0), (z1, r1)) in enumerate(zip(controls, controls[1:])):
        for sample_index in range(samples_per_interval):
            if interval_index and sample_index == 0:
                continue
            alpha = sample_index / samples_per_interval
            eased = alpha * alpha * (3.0 - 2.0 * alpha)
            rails.append((z0 + alpha * (z1 - z0), r0 + eased * (r1 - r0)))
    rails.append(controls[-1])
    return LoftGeometry(
        [
            _handle_section(
                length * z_ratio,
                outer_radius * radius_ratio,
                section,
                lobing * math.sin(math.pi * z_ratio) ** 2,
            )
            for z_ratio, radius_ratio in rails
        ],
        cap=True,
        closed=True,
    )


def _radial_profile(
    z: float,
    tip_profile: str,
    width: float,
    thickness_ratio: float,
    scale: float = 1.0,
) -> list[tuple[float, float, float]]:
    half_width = 0.5 * width * scale
    points = []
    for theta in _circle_angles():
        cosine = math.cos(theta)
        sine = math.sin(theta)
        if tip_profile == "slotted":
            half_thickness = half_width * thickness_ratio
            x_limit = half_width / max(abs(cosine), 1e-9)
            y_limit = half_thickness / max(abs(sine), 1e-9)
            radius = min(x_limit, y_limit)
        elif tip_profile == "cruciform":
            arm_half_width = half_width * thickness_ratio
            horizontal = min(
                half_width / max(abs(cosine), 1e-9),
                arm_half_width / max(abs(sine), 1e-9),
            )
            vertical = min(
                arm_half_width / max(abs(cosine), 1e-9),
                half_width / max(abs(sine), 1e-9),
            )
            radius = max(horizontal, vertical)
        else:
            radius = half_width * (1.0 + 0.16 * math.cos(6.0 * theta))
        points.append((radius * cosine, radius * sine, z))
    return points


def _round_profile(z: float, radius: float) -> list[tuple[float, float, float]]:
    return [(radius * math.cos(theta), radius * math.sin(theta), z) for theta in _circle_angles()]


def _shaft_and_tip_geometry(parameters: Mapping[str, Any]) -> LoftGeometry:
    shaft_length = float(parameters["shaft_length"])
    shaft_radius = 0.5 * float(parameters["shaft_diameter"])
    tip_length = float(parameters["tip_length"])
    tip_width = float(parameters["tip_width"])
    tip_profile = str(parameters["tip_profile"])
    thickness_ratio = float(parameters["tip_thickness_ratio"])
    tip_z = -shaft_length
    engagement_fraction = {
        "slotted": 0.45,
        "cruciform": 0.38,
        "hexalobular": 0.55,
    }[tip_profile]
    shoulder_z = tip_z + engagement_fraction * tip_length
    round_z = tip_z + tip_length
    terminal_scale = {"slotted": 1.0, "cruciform": 0.74, "hexalobular": 0.92}[tip_profile]

    return LoftGeometry(
        (
            _radial_profile(
                tip_z,
                tip_profile,
                tip_width,
                thickness_ratio,
                terminal_scale,
            ),
            _radial_profile(
                shoulder_z,
                tip_profile,
                tip_width,
                thickness_ratio,
            ),
            _round_profile(round_z, shaft_radius),
            _round_profile(0.0, shaft_radius),
        ),
        cap=True,
        closed=True,
    )


def build_model(parameters: Mapping[str, Any]) -> ArticulatedObject:
    model = ArticulatedObject(name="screwdriver")
    neutral = model.material("neutral", rgba=(0.48, 0.50, 0.52, 1.0))
    screwdriver = model.part("screwdriver")

    screwdriver.visual(
        mesh_from_geometry(_handle_geometry(parameters), "handle_shell"),
        origin=Origin(),
        material=neutral,
        name="handle_shell",
    )
    screwdriver.visual(
        mesh_from_geometry(_shaft_and_tip_geometry(parameters), "steel_shank_and_tip"),
        origin=Origin(),
        material=neutral,
        name="steel_shank_and_tip",
    )
    return model


def run_tests(model: ArticulatedObject, parameters: Mapping[str, Any]):
    ctx = TestContext(model)
    ctx.check(
        "shaft-smaller-than-handle-neck",
        parameters["shaft_diameter"]
        < parameters["handle_diameter"] * parameters["handle_neck_ratio"],
    )
    ctx.check(
        "tip-transition-within-shaft",
        0.0 < parameters["tip_length"] < parameters["shaft_length"],
    )
    ctx.check(
        "positive-grip-and-shaft-lengths",
        parameters["handle_length"] > 0.0 and parameters["shaft_length"] > 0.0,
    )
    return ctx.report()


def _covers_choices(samples: Sequence[Mapping[str, Any]], factor: str, expected: set[str]) -> bool:
    return expected.issubset({str(sample[factor]) for sample in samples})


GENERATOR = GeneratorSpec(
    name="screwdriver",
    category="screwdriver",
    description=(
        "Category-level ordinary fixed-blade handheld screwdrivers with varied grip, shank, "
        "and working-tip geometry."
    ),
    design=GeneratorDesign(
        coverage=(
            "Common standard and compact stubby fixed-blade screwdrivers are represented. Standard "
            "grips span 27-42 mm maximum diameter and 85-130 mm coupled length with independently "
            "variable 75-200 mm exposed reach; stubby palm grips span 30-43 mm diameter and "
            "45-70 mm coupled length with independent 20-45 mm reach. Slotted, cruciform, and "
            "hexalobular working tips and smooth round, localized six-lobed, or faceted grips cover "
            "recurring visible families. Precision, ratcheting, interchangeable-bit, insulated, "
            "offset, flexible, regional square/Pozidriv, and impact-cap constructions are excluded "
            "as separate market or specialty scopes."
        ),
        factors=(
            "A size-family selector encodes the separated full-size and stubby proportion regimes. "
            "Each family samples grip diameter independently, then couples grip length and shank "
            "diameter to that torque-scale dimension; shaft reach remains independent because short "
            "and long access lengths occur at similar drive scales. Tip width, tip-specific axial "
            "length, and handle neck/crown ratios scale with their relevant parent diameter. Tip "
            "and grip constructions remain independent, and every stochastic factor is uniform."
        ),
        components=(
            "Standard handles use a neck-swell-waist-crown profile, while stubby handles use a "
            "shorter broad palm profile. Both vary among smooth round, mid-body six-lobed, and "
            "twelve-facet constructions; lobe depth varies only where applicable. Dense smooth "
            "axial rails keep each grip one continuous surface. The steel member varies in reach "
            "and coupled round diameter, then forms a profile-specific compact slotted blade, blunt "
            "cruciform point, or six-lobed engagement section and transition. Branding, texture, "
            "color coding, clips, and incidental molding details remain omitted."
        ),
        physics_and_task=(
            "The handle is the root and the single continuous steel shank-and-tip member seats on "
            "its complete circular root face at the handle's local bottom plane. The declared "
            "RigidMount captures this permanent finite-footprint interface. The working tip is "
            "integral to the shank, and grip/tip geometry preserves the ordinary contact surfaces "
            "needed for manual rotation and screw engagement without inventing a hand, robot, "
            "fastener, torque, or clearance threshold."
        ),
    ),
    factors=(
        UniformChoice(
            name="size_family",
            choices=("standard", "stubby"),
            description="Ordinary full-size or compact fixed-blade construction regime.",
        ),
        UniformChoice(
            name="tip_profile",
            choices=("slotted", "cruciform", "hexalobular"),
            description="Working-end cross-section family for common screw-drive geometries.",
        ),
        UniformChoice(
            name="handle_cross_section",
            choices=("round", "six_lobed", "faceted"),
            description="Smooth circular, localized six-lobed, or twelve-facet grip construction.",
        ),
        UniformFloat(
            name="handle_lobing",
            low=0.035,
            high=0.085,
            active_when=(ActiveWhen(factor="handle_cross_section", values=("six_lobed",)),),
            description="Radial depth of the six alternating grip lobes as a radius ratio.",
            unit="ratio",
        ),
        UniformFloat(
            name="standard_handle_diameter",
            low=0.027,
            high=0.042,
            active_when=(ActiveWhen(factor="size_family", values=("standard",)),),
            description="Maximum outside diameter of a standard full-size grip.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="standard_handle_length",
            reference="standard_handle_diameter",
            ratio_low=2.7,
            ratio_high=3.8,
            hard_min=0.085,
            hard_max=0.130,
            active_when=(ActiveWhen(factor="size_family", values=("standard",)),),
            description="Standard grip length coupled to its torque-scale diameter.",
            unit="m",
        ),
        UniformFloat(
            name="standard_shaft_length",
            low=0.075,
            high=0.200,
            active_when=(ActiveWhen(factor="size_family", values=("standard",)),),
            description="Exposed steel length of a standard full-size screwdriver.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="standard_shaft_diameter",
            reference="standard_handle_diameter",
            ratio_low=0.15,
            ratio_high=0.22,
            active_when=(ActiveWhen(factor="size_family", values=("standard",)),),
            description="Round shank diameter coupled to standard grip torque scale.",
            unit="m",
        ),
        UniformFloat(
            name="stubby_handle_diameter",
            low=0.030,
            high=0.043,
            active_when=(ActiveWhen(factor="size_family", values=("stubby",)),),
            description="Maximum outside diameter of a compact stubby palm grip.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="stubby_handle_length",
            reference="stubby_handle_diameter",
            ratio_low=1.35,
            ratio_high=1.85,
            hard_min=0.045,
            hard_max=0.070,
            active_when=(ActiveWhen(factor="size_family", values=("stubby",)),),
            description="Compact palm-grip length coupled to its diameter.",
            unit="m",
        ),
        UniformFloat(
            name="stubby_shaft_length",
            low=0.020,
            high=0.045,
            active_when=(ActiveWhen(factor="size_family", values=("stubby",)),),
            description="Exposed steel length of a fixed-blade stubby screwdriver.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="stubby_shaft_diameter",
            reference="stubby_handle_diameter",
            ratio_low=0.15,
            ratio_high=0.21,
            active_when=(ActiveWhen(factor="size_family", values=("stubby",)),),
            description="Round shank diameter coupled to compact grip torque scale.",
            unit="m",
        ),
        Derived(
            name="handle_length",
            derive=_resolve_handle_length,
            depends_on=(
                "size_family",
                "standard_handle_length",
                "stubby_handle_length",
            ),
            description="Resolved grip length selected from the active size regime.",
            unit="m",
        ),
        Derived(
            name="handle_diameter",
            derive=_resolve_handle_diameter,
            depends_on=(
                "size_family",
                "standard_handle_diameter",
                "stubby_handle_diameter",
            ),
            description="Resolved maximum grip diameter selected from the active size regime.",
            unit="m",
        ),
        Derived(
            name="shaft_length",
            derive=_resolve_shaft_length,
            depends_on=(
                "size_family",
                "standard_shaft_length",
                "stubby_shaft_length",
            ),
            description="Resolved exposed shank-and-tip length selected from the active regime.",
            unit="m",
        ),
        Derived(
            name="shaft_diameter",
            derive=_resolve_shaft_diameter,
            depends_on=(
                "size_family",
                "standard_shaft_diameter",
                "stubby_shaft_diameter",
            ),
            description="Resolved round shank diameter selected from the active size regime.",
            unit="m",
        ),
        UniformFloat(
            name="handle_neck_ratio",
            low=0.50,
            high=0.72,
            description="Handle root radius divided by its maximum radius.",
            unit="ratio",
        ),
        UniformFloat(
            name="handle_crown_ratio",
            low=0.66,
            high=0.92,
            description="Upper grip radius divided by its maximum radius before the end taper.",
            unit="ratio",
        ),
        RelativeUniformFloat(
            name="slotted_tip_width",
            reference="shaft_diameter",
            ratio_low=0.85,
            ratio_high=1.35,
            active_when=(ActiveWhen(factor="tip_profile", values=("slotted",)),),
            description="Blade width relative to its round shank diameter.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="cruciform_tip_width",
            reference="shaft_diameter",
            ratio_low=0.70,
            ratio_high=1.05,
            active_when=(ActiveWhen(factor="tip_profile", values=("cruciform",)),),
            description="Maximum cruciform wing span relative to shank diameter.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="hexalobular_tip_width",
            reference="shaft_diameter",
            ratio_low=0.68,
            ratio_high=1.02,
            active_when=(ActiveWhen(factor="tip_profile", values=("hexalobular",)),),
            description="Maximum six-lobe working width relative to shank diameter.",
            unit="m",
        ),
        Derived(
            name="tip_width",
            derive=_resolve_tip_width,
            depends_on=(
                "tip_profile",
                "slotted_tip_width",
                "cruciform_tip_width",
                "hexalobular_tip_width",
            ),
            description="Resolved maximum working-tip width for the active tip family.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="slotted_tip_length",
            reference="shaft_diameter",
            ratio_low=0.9,
            ratio_high=1.6,
            active_when=(ActiveWhen(factor="tip_profile", values=("slotted",)),),
            description="Blade-and-transition length for the slotted working end.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="cruciform_tip_length",
            reference="shaft_diameter",
            ratio_low=0.65,
            ratio_high=1.15,
            active_when=(ActiveWhen(factor="tip_profile", values=("cruciform",)),),
            description="Compact blunt cross-point and transition length.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="hexalobular_tip_length",
            reference="shaft_diameter",
            ratio_low=0.42,
            ratio_high=0.75,
            active_when=(ActiveWhen(factor="tip_profile", values=("hexalobular",)),),
            description="Compact six-lobe engagement and transition length.",
            unit="m",
        ),
        Derived(
            name="tip_length",
            derive=_resolve_tip_length,
            depends_on=(
                "tip_profile",
                "slotted_tip_length",
                "cruciform_tip_length",
                "hexalobular_tip_length",
            ),
            description="Resolved profile-specific working-end and transition length.",
            unit="m",
        ),
        UniformFloat(
            name="slotted_tip_thickness_ratio",
            low=0.18,
            high=0.28,
            active_when=(ActiveWhen(factor="tip_profile", values=("slotted",)),),
            description="Slotted blade thickness divided by blade half-width.",
            unit="ratio",
        ),
        UniformFloat(
            name="cruciform_arm_ratio",
            low=0.22,
            high=0.32,
            active_when=(ActiveWhen(factor="tip_profile", values=("cruciform",)),),
            description="Cruciform arm half-width divided by maximum tip half-width.",
            unit="ratio",
        ),
        Derived(
            name="tip_thickness_ratio",
            derive=_resolve_tip_thickness_ratio,
            depends_on=(
                "tip_profile",
                "slotted_tip_thickness_ratio",
                "cruciform_arm_ratio",
            ),
            description="Resolved profile-specific planar thickness control; zero for six lobes.",
            unit="ratio",
        ),
    ),
    relationships=(
        RigidMount(
            name="steel-shank-mounted-to-handle",
            parent_part="screwdriver",
            parent_element="handle_shell",
            child_part="screwdriver",
            child_element="steel_shank_and_tip",
        ),
    ),
    population_checks=(
        PopulationCheck(
            name="covers-size-families",
            predicate=lambda samples: _covers_choices(
                samples, "size_family", {"standard", "stubby"}
            ),
            message="Validation must exercise standard and stubby construction regimes.",
        ),
        PopulationCheck(
            name="covers-tip-profiles",
            predicate=lambda samples: _covers_choices(
                samples, "tip_profile", {"slotted", "cruciform", "hexalobular"}
            ),
            message="Validation must exercise all three common working-tip profiles.",
        ),
        PopulationCheck(
            name="covers-handle-cross-sections",
            predicate=lambda samples: _covers_choices(
                samples, "handle_cross_section", {"round", "six_lobed", "faceted"}
            ),
            message="Validation must exercise round, localized six-lobed, and faceted grips.",
        ),
    ),
    build=build_model,
    tests=run_tests,
    task_requirements=(
        "Every sample must have one continuous steel shank terminating in a recognizable working tip.",
        "The complete steel shank root face must remain permanently mounted to the handle bottom.",
        "The handle must retain a continuous ordinary grip surface without unintended seams or kinks.",
    ),
    tags=("screwdriver", "hand_tool", "fixed_blade", "manual"),
)
