from __future__ import annotations

import math
from collections.abc import Mapping, Sequence
from typing import Any

from assetengine import (
    ActiveWhen,
    Derived,
    GeneratorDesign,
    GeneratorSpec,
    PopulationCheck,
    RelativeUniformFloat,
    RigidMount,
    UniformChoice,
    UniformFloat,
    UniformInt,
)
from assetengine.articraft import (
    ArticulatedObject,
    BoxGeometry,
    CylinderGeometry,
    ExtrudeGeometry,
    ExtrudeWithHolesGeometry,
    LoftGeometry,
    MeshGeometry,
    Origin,
    TestContext,
    mesh_from_geometry,
    rounded_rect_profile,
)


def _covers_choice(samples: Sequence[Mapping[str, Any]], factor: str, expected: set[Any]) -> bool:
    return expected.issubset({sample[factor] for sample in samples})


def _box(size: tuple[float, float, float], xyz: tuple[float, float, float]) -> MeshGeometry:
    return BoxGeometry(size).translate(*xyz)


def _vertical_member(
    profile: str, size: float, height: float, xyz: tuple[float, float, float]
) -> MeshGeometry:
    geometry: MeshGeometry
    if profile == "round":
        geometry = CylinderGeometry(0.5 * size, height, radial_segments=28)
    else:
        geometry = BoxGeometry((size, size, height))
    return geometry.translate(*xyz)


def _splayed_member(
    size: float,
    height: float,
    top_x: float,
    top_y: float,
    bottom_dx: float,
    bottom_dy: float,
) -> MeshGeometry:
    source = BoxGeometry((size, size, height)).translate(0.0, 0.0, 0.5 * height)
    vertices = []
    for x, y, z in source.vertices:
        bottom_weight = 1.0 - z / height
        vertices.append(
            (
                x + top_x + bottom_dx * bottom_weight,
                y + top_y + bottom_dy * bottom_weight,
                z,
            )
        )
    return MeshGeometry(vertices=vertices, faces=list(source.faces))


def _sheared_back_solid(
    geometry: MeshGeometry,
    *,
    height: float,
    recline: float,
    bow: float,
    width: float,
    y: float,
    bottom_z: float,
) -> MeshGeometry:
    vertices = []
    for x_value, y_value, z_value in geometry.vertices:
        from_bottom = z_value + 0.5 * height
        height_fraction = min(1.0, max(0.0, from_bottom / height))
        width_fraction = min(1.0, abs(2.0 * x_value / width))
        transverse_bow = -bow * (1.0 - width_fraction**2) * math.sin(math.pi * height_fraction)
        vertices.append(
            (
                x_value,
                y_value + y + math.tan(recline) * from_bottom + transverse_bow,
                z_value + bottom_z + 0.5 * height,
            )
        )
    return MeshGeometry(vertices=vertices, faces=list(geometry.faces))


def _seat_geometry(parameters: Mapping[str, Any]) -> MeshGeometry:
    width = float(parameters["seat_width"])
    if parameters["arms_realized"]:
        width += 2.0 * float(parameters["armrest_width"])
    depth = float(parameters["seat_depth"])
    thickness = float(parameters["seat_thickness"])
    radius = min(float(parameters["seat_corner_radius"]), 0.45 * min(width, depth))
    outline = rounded_rect_profile(width, depth, radius, corner_segments=8)
    if parameters["seat_surface_profile"] == "cushioned":
        profiles = []
        for z_value, scale in (
            (-0.5 * thickness, 0.94),
            (-0.20 * thickness, 1.00),
            (0.25 * thickness, 1.00),
            (0.5 * thickness, 0.96),
        ):
            profiles.append([(scale * x, scale * y, z_value) for x, y in outline])
        return LoftGeometry(profiles, cap=True, closed=True)
    return ExtrudeGeometry(outline, thickness, cap=True, center=True, closed=True)


def _yz_extrusion(profile_yz: Sequence[tuple[float, float]], width: float) -> MeshGeometry:
    profile = [(-z_value, y_value) for y_value, z_value in profile_yz]
    return ExtrudeGeometry(profile, width, cap=True, center=True, closed=True).rotate_y(
        0.5 * math.pi
    )


def _integrated_shell(parameters: Mapping[str, Any]) -> MeshGeometry:
    width = float(parameters["seat_width"])
    if parameters["arms_realized"]:
        width += 2.0 * float(parameters["armrest_width"])
    depth = float(parameters["seat_depth"])
    seat_top = float(parameters["seat_height"])
    seat_bottom = seat_top - float(parameters["seat_thickness"])
    back_height = float(parameters["back_height"])
    thickness = min(0.055, float(parameters["back_thickness"]), 0.8 * back_height)
    recline = float(parameters["back_recline"])
    side_curve = 0.035
    transition_radius = min(0.11, 0.22 * depth, 0.18 * back_height)
    transition_fraction = transition_radius / back_height

    outer_back = []
    inner_back = []
    for index in range(13):
        fraction = index / 12.0
        z_value = seat_top + fraction * back_height
        center_y = (
            0.5 * depth
            - 0.5 * thickness
            + math.tan(recline) * fraction * back_height
            + side_curve * math.sin(math.pi * fraction)
        )
        outer_back.append((center_y + 0.5 * thickness, z_value))
    for index in range(13):
        fraction = transition_fraction + (1.0 - transition_fraction) * index / 12.0
        z_value = seat_top + fraction * back_height
        center_y = (
            0.5 * depth
            - 0.5 * thickness
            + math.tan(recline) * fraction * back_height
            + side_curve * math.sin(math.pi * fraction)
        )
        inner_back.append((center_y - 0.5 * thickness, z_value))

    back_join_y, back_join_z = inner_back[0]
    seat_join = (0.5 * depth - thickness - transition_radius, seat_top)
    back_slope = math.tan(recline) + side_curve * math.pi / back_height * math.cos(
        math.pi * transition_fraction
    )
    control_length = 0.55 * transition_radius
    control_1 = (
        back_join_y - back_slope * control_length,
        back_join_z - control_length,
    )
    control_2 = (seat_join[0] + control_length, seat_join[1])
    transition = []
    for index in range(1, 9):
        fraction = index / 8.0
        complement = 1.0 - fraction
        y_value = (
            complement**3 * back_join_y
            + 3.0 * complement**2 * fraction * control_1[0]
            + 3.0 * complement * fraction**2 * control_2[0]
            + fraction**3 * seat_join[0]
        )
        z_value = (
            complement**3 * back_join_z
            + 3.0 * complement**2 * fraction * control_1[1]
            + 3.0 * complement * fraction**2 * control_2[1]
            + fraction**3 * seat_join[1]
        )
        transition.append((y_value, z_value))
    profile = [
        (-0.5 * depth, seat_bottom),
        (0.5 * depth, seat_bottom),
        *outer_back,
        *reversed(inner_back),
        *transition,
        (-0.5 * depth, seat_top),
    ]
    geometry = _yz_extrusion(profile, width)
    vertices = []
    bow = float(parameters["back_bow"])
    for x_value, y_value, z_value in geometry.vertices:
        if z_value <= seat_top:
            transverse_bow = 0.0
        else:
            height_fraction = min(1.0, (z_value - seat_top) / back_height)
            width_fraction = min(1.0, abs(2.0 * x_value / width))
            transverse_bow = -bow * (1.0 - width_fraction**2) * math.sin(math.pi * height_fraction)
        vertices.append((x_value, y_value + transverse_bow, z_value))
    return MeshGeometry(vertices=vertices, faces=list(geometry.faces))


def _sled_side(parameters: Mapping[str, Any], side: str) -> MeshGeometry:
    depth = float(parameters["seat_depth"])
    seat_bottom = float(parameters["seat_height"]) - float(parameters["seat_thickness"])
    size = float(parameters["frame_member_size"])
    inset = max(
        float(parameters["leg_inset"]),
        0.72 * float(parameters["seat_corner_radius"]),
    )
    half_length = 0.5 * depth - inset
    profile = [
        (-half_length, 0.0),
        (half_length, 0.0),
        (half_length, seat_bottom),
        (half_length - size, seat_bottom),
        (half_length - size, size),
        (-half_length + size, size),
        (-half_length + size, seat_bottom),
        (-half_length, seat_bottom),
    ]
    x_sign = -1.0 if side == "left" else 1.0
    x_value = x_sign * (0.5 * float(parameters["seat_width"]) - inset)
    return _yz_extrusion(profile, size).translate(x_value, 0.0, 0.0)


def _task_star(parameters: Mapping[str, Any]) -> MeshGeometry:
    outer = float(parameters["task_base_radius"])
    inner = 0.085
    profile = []
    for index in range(10):
        angle = 0.5 * math.pi + index * math.pi / 5.0
        radius = outer if index % 2 == 0 else inner
        profile.append((radius * math.cos(angle), radius * math.sin(angle)))
    return ExtrudeGeometry(profile, 0.045, cap=True, center=True, closed=True).translate(
        0.0, 0.0, 0.0225
    )


def _panel_back(parameters: Mapping[str, Any]) -> MeshGeometry:
    width = float(parameters["back_width"])
    height = float(parameters["back_height"])
    thickness = float(parameters["back_thickness"])
    outline = str(parameters["back_outline_realized"])
    radius = 0.012 if outline == "rectangular" else min(0.12, 0.22 * width, 0.22 * height)
    profile = rounded_rect_profile(width, height, radius, corner_segments=8)
    geometry = ExtrudeGeometry(profile, thickness, cap=True, center=True, closed=True).rotate_x(
        0.5 * math.pi
    )
    return _sheared_back_solid(
        geometry,
        height=height,
        recline=float(parameters["back_recline"]),
        bow=float(parameters["back_bow"]),
        width=width,
        y=0.5 * float(parameters["seat_depth"]) - 0.5 * thickness,
        bottom_z=float(parameters["seat_height"]),
    )


def _slatted_back(parameters: Mapping[str, Any]) -> MeshGeometry:
    width = float(parameters["back_width"])
    height = float(parameters["back_height"])
    thickness = float(parameters["back_thickness"])
    member = float(parameters["frame_member_size"])
    rail_count = int(parameters["slat_count"])
    rail_height = float(parameters["slat_height"])
    inner_height = height - 2.0 * member
    gap_height = (inner_height - rail_count * rail_height) / (rail_count + 1)
    holes = []
    cursor = -0.5 * inner_height
    hole_width = width - 2.0 * member
    for _ in range(rail_count + 1):
        center = cursor + 0.5 * gap_height
        holes.append(
            [
                (-0.5 * hole_width, center - 0.5 * gap_height),
                (0.5 * hole_width, center - 0.5 * gap_height),
                (0.5 * hole_width, center + 0.5 * gap_height),
                (-0.5 * hole_width, center + 0.5 * gap_height),
            ]
        )
        cursor += gap_height + rail_height
    outer = rounded_rect_profile(width, height, min(0.025, 0.08 * width), corner_segments=6)
    geometry = ExtrudeWithHolesGeometry(
        outer, holes, thickness, cap=True, center=True, closed=True
    ).rotate_x(0.5 * math.pi)
    return _sheared_back_solid(
        geometry,
        height=height,
        recline=float(parameters["back_recline"]),
        bow=float(parameters["back_bow"]),
        width=width,
        y=0.5 * float(parameters["seat_depth"]) - 0.5 * thickness,
        bottom_z=float(parameters["seat_height"]),
    )


def _arm_side(parameters: Mapping[str, Any], side: str) -> MeshGeometry:
    seat_bottom = float(parameters["seat_height"])
    cap_bottom = float(parameters["seat_height"]) + float(parameters["arm_height"])
    cap_top = cap_bottom + float(parameters["armrest_thickness"])
    depth = float(parameters["seat_depth"])
    half_length = 0.39 * depth
    support_depth = 0.055
    arch = float(parameters["arm_cap_arch"])
    outer_cap = []
    inner_cap = []
    for index in range(9):
        fraction = index / 8.0
        y_value = -half_length + 2.0 * half_length * fraction
        rise = arch * math.sin(math.pi * fraction)
        outer_cap.append((y_value, cap_top + rise))
        inner_cap.append((y_value, cap_bottom + rise))
    profile = [
        (-half_length, seat_bottom),
        *outer_cap,
        (half_length, seat_bottom),
        (half_length - support_depth, seat_bottom),
        (half_length - support_depth, cap_bottom),
        *reversed(inner_cap[1:-1]),
        (-half_length + support_depth, cap_bottom),
        (-half_length + support_depth, seat_bottom),
    ]
    sign = -1.0 if side == "left" else 1.0
    x_value = sign * (
        0.5 * float(parameters["seat_width"]) + 0.5 * float(parameters["armrest_width"])
    )
    return _yz_extrusion(profile, float(parameters["armrest_width"])).translate(x_value, 0.0, 0.0)


def _add_mesh(chair, name: str, geometry: MeshGeometry, material) -> None:
    signed_volume = 0.0
    for a, b, c in geometry.faces:
        ax, ay, az = geometry.vertices[a]
        bx, by, bz = geometry.vertices[b]
        cx, cy, cz = geometry.vertices[c]
        signed_volume += (
            ax * (by * cz - bz * cy) + ay * (bz * cx - bx * cz) + az * (bx * cy - by * cx)
        ) / 6.0
    if signed_volume < 0.0:
        geometry = MeshGeometry(
            vertices=list(geometry.vertices),
            faces=[(a, c, b) for a, b, c in geometry.faces],
        )
    chair.visual(
        mesh_from_geometry(geometry, name),
        origin=Origin(),
        material=material,
        name=name,
    )


def build_model(parameters: Mapping[str, Any]) -> ArticulatedObject:
    model = ArticulatedObject(name="chair")
    neutral = model.material("neutral", rgba=(0.48, 0.50, 0.52, 1.0))
    chair = model.part("chair")
    seat_height = float(parameters["seat_height"])
    seat_thickness = float(parameters["seat_thickness"])
    seat_bottom = seat_height - seat_thickness
    integrated_shell = parameters["shell_topology"] == "integrated"
    seat_local = _integrated_shell(parameters) if integrated_shell else _seat_geometry(parameters)
    chair.visual(
        mesh_from_geometry(seat_local, "seat"),
        origin=(
            Origin()
            if integrated_shell
            else Origin(xyz=(0.0, 0.0, seat_height - 0.5 * seat_thickness))
        ),
        material=neutral,
        name="seat",
    )

    family = str(parameters["chair_family"])
    width = float(parameters["seat_width"])
    depth = float(parameters["seat_depth"])
    size = float(parameters["frame_member_size"])
    inset = max(float(parameters["leg_inset"]), 0.72 * float(parameters["seat_corner_radius"]))
    if family == "task":
        _add_mesh(chair, "task_foot", _task_star(parameters), neutral)
        _add_mesh(
            chair,
            "task_column",
            CylinderGeometry(0.040, seat_bottom - 0.045, radial_segments=32).translate(
                0.0, 0.0, 0.045 + 0.5 * (seat_bottom - 0.045)
            ),
            neutral,
        )
    elif family == "upright" and parameters["upright_base"] == "sled":
        for side in ("left", "right"):
            _add_mesh(chair, f"{side}_sled", _sled_side(parameters, side), neutral)
    else:
        for x_name, x_sign in (("left", -1.0), ("right", 1.0)):
            for y_name, y_sign in (("front", -1.0), ("rear", 1.0)):
                x_value = x_sign * (0.5 * width - inset)
                y_value = y_sign * (0.5 * depth - inset)
                if family == "lounge":
                    leg = _splayed_member(
                        size,
                        seat_bottom,
                        x_value,
                        y_value,
                        x_sign * float(parameters["leg_splay"]),
                        y_sign * float(parameters["leg_splay"]),
                    )
                    name = f"lounge_{y_name}_{x_name}_leg"
                else:
                    leg = _vertical_member(
                        str(parameters["frame_member_profile"]),
                        size,
                        seat_bottom,
                        (x_value, y_value, 0.5 * seat_bottom),
                    )
                    name = f"upright_{y_name}_{x_name}_leg"
                _add_mesh(chair, name, leg, neutral)

    if not integrated_shell:
        if parameters["back_construction_realized"] == "slatted":
            _add_mesh(chair, "slatted_back", _slatted_back(parameters), neutral)
        else:
            _add_mesh(chair, "panel_back", _panel_back(parameters), neutral)
    if parameters["arms_realized"]:
        for side in ("left", "right"):
            _add_mesh(chair, f"{side}_arm", _arm_side(parameters, side), neutral)
    return model


def run_tests(model: ArticulatedObject, parameters: Mapping[str, Any]):
    ctx = TestContext(model)
    ctx.check("adult-clear-seat-width", float(parameters["seat_width"]) >= 0.40)
    ctx.check(
        "family-posture-envelope",
        (
            parameters["chair_family"] == "upright"
            and 0.42 <= float(parameters["seat_height"]) <= 0.49
        )
        or (
            parameters["chair_family"] == "lounge"
            and 0.34 <= float(parameters["seat_height"]) <= 0.43
        )
        or (
            parameters["chair_family"] == "task"
            and 0.40 <= float(parameters["seat_height"]) <= 0.54
        ),
    )
    return ctx.report()


GENERATOR = GeneratorSpec(
    name="chair",
    category="chair",
    description=(
        "Category-level adult chairs spanning upright side/dining, lounge armchair, and pedestal "
        "task-chair regimes with family-specific proportions and contact geometry."
    ),
    design=GeneratorDesign(
        coverage=(
            "Ordinary adult chairs are represented by three visibly separated regimes found across "
            "IKEA, Herman Miller, Steelcase, and Knoll product grids: upright dining/side/guest "
            "chairs with four-leg or sled bases; low, deep, splayed-leg lounge armchairs; and "
            "five-spoke pedestal task chairs. Upright seats span 0.40-0.54 m wide, 0.36-0.48 m "
            "deep, and 0.42-0.49 m high; lounge seats span 0.50-0.70 m, 0.48-0.62 m, and "
            "0.34-0.43 m; task seats span 0.45-0.55 m, 0.40-0.50 m, and 0.40-0.54 m. Backs "
            "cover panel and open-rail upright forms plus rounded panel lounge/task forms. Rare "
            "rockers, folding chairs, recliners, children chairs, stools, and ornate historical "
            "styles remain excluded."
        ),
        factors=(
            "Chair family is a real posture/construction selector. Each family has separate uniform "
            "absolute seat width, depth, height, back height, and recline envelopes, preventing "
            "upright, lounge, and task proportions from cross-combining. Realized dimensions are "
            "exact Derived selections. Back width remains 78-98% of seat width. Upright-only base, "
            "back, seat-outline, and back-outline choices are ActiveWhen; lounge and task realize "
            "their characteristic rounded contact surfaces. Seat width always means clear sitter "
            "span; optional arms are placed outside it. All stochastic factors are uniform."
        ),
        components=(
            "Seats vary between thin flat and lofted cushioned profiles with rounded-rectangle plan "
            "outlines. A separate-frame topology and a continuous molded seat-back shell topology "
            "cover the two common body constructions. Back surfaces have real transverse bow and "
            "variable inclination, rectangular or rounded panels, or genuine openings between rails. Upright "
            "bases vary between four legs and single-piece sled runners; lounge bases use visibly "
            "splayed legs; task bases use one column and a single five-spoke floor foot. Optional "
            "paired arms are single-piece inverted-U members with smoothly arched contact caps."
        ),
        physics_and_task=(
            "Seat, every support member, back, and each arm are separately healthy connected solids. "
            "RigidMount interfaces are complete finite faces: supports meet the seat underside, each "
            "broad back root meets the seat top, and the two-root arm profile meets the seat side "
            "meet the seat side without consuming clear seat width. No tolerance bridges, connector "
            "geometry, robot clearance, strength threshold, or dynamic-load claim is used."
        ),
    ),
    factors=(
        UniformChoice(
            name="chair_family",
            choices=("upright", "lounge", "task"),
            description="Separated upright, low lounge, or pedestal task-chair construction regime.",
        ),
        UniformChoice(
            name="body_topology",
            choices=("separate", "integrated"),
            active_when=(ActiveWhen(factor="chair_family", values=("upright", "lounge")),),
            description="Separate seat and back or one continuous molded seat-back shell for upright and lounge chairs.",
        ),
        UniformChoice(
            name="upright_base",
            choices=("four_leg", "sled"),
            active_when=(ActiveWhen(factor="chair_family", values=("upright",)),),
            description="Four-leg apron frame or continuous sled frame for upright chairs.",
        ),
        UniformChoice(
            name="frame_member_profile",
            choices=("square", "round"),
            active_when=(
                ActiveWhen(factor="chair_family", values=("upright",)),
                ActiveWhen(factor="upright_base", values=("four_leg",)),
            ),
            description="Square or circular upright four-leg members.",
        ),
        UniformChoice(
            name="upright_back_construction",
            choices=("panel", "slatted"),
            active_when=(ActiveWhen(factor="chair_family", values=("upright",)),),
            description="Panel or genuinely open horizontal-rail upright back.",
        ),
        UniformChoice(
            name="upright_seat_outline",
            choices=("soft_rectangle", "rounded_rectangle"),
            active_when=(ActiveWhen(factor="chair_family", values=("upright",)),),
            description="Subtly or strongly rounded upright seat plan.",
        ),
        UniformChoice(
            name="upright_back_outline",
            choices=("rectangular", "rounded"),
            active_when=(
                ActiveWhen(factor="chair_family", values=("upright",)),
                ActiveWhen(factor="upright_back_construction", values=("panel",)),
            ),
            description="Straight or rounded upright panel outline.",
        ),
        UniformChoice(
            name="seat_surface_profile",
            choices=("flat", "cushioned"),
            description="Thin planar seat or coherent lofted cushion profile.",
        ),
        UniformChoice(
            name="optional_arms",
            choices=(False, True),
            active_when=(ActiveWhen(factor="chair_family", values=("upright", "task")),),
            description="Optional paired arms on upright and task chairs; lounge chairs always have arms.",
        ),
        UniformFloat(
            name="upright_seat_width",
            low=0.40,
            high=0.54,
            active_when=(ActiveWhen(factor="chair_family", values=("upright",)),),
            description="Clear upright-chair seat width.",
            unit="m",
        ),
        UniformFloat(
            name="upright_seat_depth",
            low=0.36,
            high=0.48,
            active_when=(ActiveWhen(factor="chair_family", values=("upright",)),),
            description="Upright-chair seat depth.",
            unit="m",
        ),
        UniformFloat(
            name="upright_seat_height",
            low=0.42,
            high=0.49,
            active_when=(ActiveWhen(factor="chair_family", values=("upright",)),),
            description="Upright-chair floor-to-seat height.",
            unit="m",
        ),
        UniformFloat(
            name="upright_back_height",
            low=0.30,
            high=0.53,
            active_when=(ActiveWhen(factor="chair_family", values=("upright",)),),
            description="Upright back height above the seat.",
            unit="m",
        ),
        UniformFloat(
            name="upright_recline",
            low=0.0,
            high=0.18,
            active_when=(ActiveWhen(factor="chair_family", values=("upright",)),),
            description="Upright back rearward inclination.",
            unit="rad",
        ),
        UniformFloat(
            name="lounge_seat_width",
            low=0.50,
            high=0.70,
            active_when=(ActiveWhen(factor="chair_family", values=("lounge",)),),
            description="Clear lounge-chair seat width.",
            unit="m",
        ),
        UniformFloat(
            name="lounge_seat_depth",
            low=0.48,
            high=0.62,
            active_when=(ActiveWhen(factor="chair_family", values=("lounge",)),),
            description="Deep lounge-chair seat depth.",
            unit="m",
        ),
        UniformFloat(
            name="lounge_seat_height",
            low=0.34,
            high=0.43,
            active_when=(ActiveWhen(factor="chair_family", values=("lounge",)),),
            description="Low lounge-chair seat height.",
            unit="m",
        ),
        UniformFloat(
            name="lounge_back_height",
            low=0.45,
            high=0.70,
            active_when=(ActiveWhen(factor="chair_family", values=("lounge",)),),
            description="Lounge back height above the seat.",
            unit="m",
        ),
        UniformFloat(
            name="lounge_recline",
            low=0.20,
            high=0.48,
            active_when=(ActiveWhen(factor="chair_family", values=("lounge",)),),
            description="Pronounced lounge back rearward inclination.",
            unit="rad",
        ),
        UniformFloat(
            name="task_seat_width",
            low=0.45,
            high=0.55,
            active_when=(ActiveWhen(factor="chair_family", values=("task",)),),
            description="Clear task-chair seat width.",
            unit="m",
        ),
        UniformFloat(
            name="task_seat_depth",
            low=0.40,
            high=0.50,
            active_when=(ActiveWhen(factor="chair_family", values=("task",)),),
            description="Task-chair seat depth.",
            unit="m",
        ),
        UniformFloat(
            name="task_seat_height",
            low=0.40,
            high=0.54,
            active_when=(ActiveWhen(factor="chair_family", values=("task",)),),
            description="Task-chair adjusted floor-to-seat height represented at one pose.",
            unit="m",
        ),
        UniformFloat(
            name="task_back_height",
            low=0.45,
            high=0.65,
            active_when=(ActiveWhen(factor="chair_family", values=("task",)),),
            description="Task back height above the seat.",
            unit="m",
        ),
        UniformFloat(
            name="task_recline",
            low=0.08,
            high=0.34,
            active_when=(ActiveWhen(factor="chair_family", values=("task",)),),
            description="Task-chair back inclination at the represented pose.",
            unit="rad",
        ),
        Derived(
            name="shell_topology",
            derive=lambda p: "separate" if p["chair_family"] == "task" else p["body_topology"],
            depends_on=("chair_family", "body_topology"),
            description="Task chairs retain separate backs; upright and lounge chairs use the selected body topology.",
        ),
        Derived(
            name="seat_width",
            derive=lambda p: p[f"{p['chair_family']}_seat_width"],
            depends_on=(
                "chair_family",
                "upright_seat_width",
                "lounge_seat_width",
                "task_seat_width",
            ),
            description="Family-selected clear seat width.",
            unit="m",
        ),
        Derived(
            name="seat_depth",
            derive=lambda p: p[f"{p['chair_family']}_seat_depth"],
            depends_on=(
                "chair_family",
                "upright_seat_depth",
                "lounge_seat_depth",
                "task_seat_depth",
            ),
            description="Family-selected seat depth.",
            unit="m",
        ),
        Derived(
            name="seat_height",
            derive=lambda p: p[f"{p['chair_family']}_seat_height"],
            depends_on=(
                "chair_family",
                "upright_seat_height",
                "lounge_seat_height",
                "task_seat_height",
            ),
            description="Family-selected seat height.",
            unit="m",
        ),
        Derived(
            name="back_height",
            derive=lambda p: p[f"{p['chair_family']}_back_height"],
            depends_on=(
                "chair_family",
                "upright_back_height",
                "lounge_back_height",
                "task_back_height",
            ),
            description="Family-selected back height.",
            unit="m",
        ),
        Derived(
            name="back_recline",
            derive=lambda p: p[f"{p['chair_family']}_recline"],
            depends_on=("chair_family", "upright_recline", "lounge_recline", "task_recline"),
            description="Family-selected rearward back inclination.",
            unit="rad",
        ),
        Derived(
            name="back_construction_realized",
            derive=lambda p: (
                p["upright_back_construction"] if p["chair_family"] == "upright" else "panel"
            ),
            depends_on=("chair_family", "upright_back_construction"),
            description="Upright-selected back construction; lounge and task chairs use panel backs.",
        ),
        Derived(
            name="back_outline_realized",
            derive=lambda p: (
                p["upright_back_outline"]
                if p["chair_family"] == "upright" and p["upright_back_construction"] == "panel"
                else "rounded"
            ),
            depends_on=("chair_family", "upright_back_construction", "upright_back_outline"),
            description="Family-appropriate realized panel outline.",
        ),
        Derived(
            name="arms_realized",
            derive=lambda p: p["chair_family"] == "lounge" or bool(p["optional_arms"]),
            depends_on=("chair_family", "optional_arms"),
            description="Lounge arms are invariant; upright and task arms are optional.",
        ),
        UniformFloat(
            name="seat_thickness",
            low=0.035,
            high=0.090,
            description="Seat pan or cushion thickness.",
            unit="m",
        ),
        UniformFloat(
            name="seat_corner_radius",
            low=0.025,
            high=0.120,
            description="Plan-view seat corner radius, capped only by the realized seat plan.",
            unit="m",
        ),
        UniformFloat(
            name="frame_member_size",
            low=0.028,
            high=0.052,
            description="Leg, runner, apron, or back-post structural section size.",
            unit="m",
        ),
        UniformFloat(
            name="leg_inset",
            low=0.045,
            high=0.080,
            description="Support-root inset from seat edges.",
            unit="m",
        ),
        UniformFloat(
            name="leg_splay",
            low=0.035,
            high=0.095,
            active_when=(ActiveWhen(factor="chair_family", values=("lounge",)),),
            description="Outward floor offset of lounge legs from their full seat roots.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="back_width",
            reference="seat_width",
            ratio_low=0.78,
            ratio_high=0.98,
            description="Back width correlated with clear seat width.",
            unit="m",
        ),
        UniformFloat(
            name="back_thickness",
            low=0.022,
            high=0.060,
            description="Panel or rail depth.",
            unit="m",
        ),
        UniformFloat(
            name="back_bow",
            low=0.015,
            high=0.060,
            description="True transverse bow of the sitter-facing back surface.",
            unit="m",
        ),
        UniformInt(
            name="slat_count",
            low=2,
            high=4,
            active_when=(
                ActiveWhen(factor="chair_family", values=("upright",)),
                ActiveWhen(factor="upright_back_construction", values=("slatted",)),
            ),
            description="Number of separated rails in an open upright back.",
            unit="count",
        ),
        RelativeUniformFloat(
            name="slat_height",
            reference="back_height",
            ratio_low=0.08,
            ratio_high=0.13,
            active_when=(
                ActiveWhen(factor="chair_family", values=("upright",)),
                ActiveWhen(factor="upright_back_construction", values=("slatted",)),
            ),
            description="Rail height relative to upright back height.",
            unit="m",
        ),
        UniformFloat(
            name="arm_height",
            low=0.17,
            high=0.29,
            description="Seat surface to arm-cap underside height.",
            unit="m",
        ),
        UniformFloat(
            name="armrest_width",
            low=0.035,
            high=0.070,
            description="Arm cap and support outside width.",
            unit="m",
        ),
        UniformFloat(
            name="armrest_thickness",
            low=0.025,
            high=0.055,
            description="Rounded arm-cap thickness.",
            unit="m",
        ),
        UniformFloat(
            name="arm_cap_arch",
            low=0.012,
            high=0.045,
            description="Smooth rise of each non-rectilinear arm contact cap.",
            unit="m",
        ),
        UniformFloat(
            name="task_base_radius",
            low=0.29,
            high=0.36,
            active_when=(ActiveWhen(factor="chair_family", values=("task",)),),
            description="Center-to-caster radius of the five-spoke task base.",
            unit="m",
        ),
    ),
    relationships=(
        *(
            RigidMount(
                name=f"upright-{position}-{side}-leg-mounted-to-seat",
                parent_part="chair",
                parent_element="seat",
                child_part="chair",
                child_element=f"upright_{position}_{side}_leg",
                active_when=(
                    ActiveWhen(factor="chair_family", values=("upright",)),
                    ActiveWhen(factor="upright_base", values=("four_leg",)),
                ),
            )
            for position in ("front", "rear")
            for side in ("left", "right")
        ),
        *(
            RigidMount(
                name=f"lounge-{position}-{side}-leg-mounted-to-seat",
                parent_part="chair",
                parent_element="seat",
                child_part="chair",
                child_element=f"lounge_{position}_{side}_leg",
                active_when=(ActiveWhen(factor="chair_family", values=("lounge",)),),
            )
            for position in ("front", "rear")
            for side in ("left", "right")
        ),
        *(
            RigidMount(
                name=f"{side}-sled-mounted-to-seat",
                parent_part="chair",
                parent_element="seat",
                child_part="chair",
                child_element=f"{side}_sled",
                active_when=(
                    ActiveWhen(factor="chair_family", values=("upright",)),
                    ActiveWhen(factor="upright_base", values=("sled",)),
                ),
            )
            for side in ("left", "right")
        ),
        RigidMount(
            name="task-column-mounted-to-foot",
            parent_part="chair",
            parent_element="task_foot",
            child_part="chair",
            child_element="task_column",
            active_when=(ActiveWhen(factor="chair_family", values=("task",)),),
        ),
        RigidMount(
            name="task-column-mounted-to-seat",
            parent_part="chair",
            parent_element="seat",
            child_part="chair",
            child_element="task_column",
            active_when=(ActiveWhen(factor="chair_family", values=("task",)),),
        ),
        RigidMount(
            name="upright-panel-back-mounted-to-seat",
            parent_part="chair",
            parent_element="seat",
            child_part="chair",
            child_element="panel_back",
            active_when=(
                ActiveWhen(factor="chair_family", values=("upright",)),
                ActiveWhen(factor="upright_back_construction", values=("panel",)),
                ActiveWhen(factor="body_topology", values=("separate",)),
            ),
        ),
        RigidMount(
            name="upright-slatted-back-mounted-to-seat",
            parent_part="chair",
            parent_element="seat",
            child_part="chair",
            child_element="slatted_back",
            active_when=(
                ActiveWhen(factor="chair_family", values=("upright",)),
                ActiveWhen(factor="upright_back_construction", values=("slatted",)),
                ActiveWhen(factor="body_topology", values=("separate",)),
            ),
        ),
        RigidMount(
            name="lounge-panel-back-mounted-to-seat",
            parent_part="chair",
            parent_element="seat",
            child_part="chair",
            child_element="panel_back",
            active_when=(
                ActiveWhen(factor="chair_family", values=("lounge",)),
                ActiveWhen(factor="body_topology", values=("separate",)),
            ),
        ),
        RigidMount(
            name="task-panel-back-mounted-to-seat",
            parent_part="chair",
            parent_element="seat",
            child_part="chair",
            child_element="panel_back",
            active_when=(ActiveWhen(factor="chair_family", values=("task",)),),
        ),
        RigidMount(
            name="lounge-left-arm-mounted-to-seat",
            parent_part="chair",
            parent_element="seat",
            child_part="chair",
            child_element="left_arm",
            active_when=(ActiveWhen(factor="chair_family", values=("lounge",)),),
        ),
        RigidMount(
            name="lounge-right-arm-mounted-to-seat",
            parent_part="chair",
            parent_element="seat",
            child_part="chair",
            child_element="right_arm",
            active_when=(ActiveWhen(factor="chair_family", values=("lounge",)),),
        ),
        RigidMount(
            name="optional-left-arm-mounted-to-seat",
            parent_part="chair",
            parent_element="seat",
            child_part="chair",
            child_element="left_arm",
            active_when=(
                ActiveWhen(factor="chair_family", values=("upright", "task")),
                ActiveWhen(factor="optional_arms", values=(True,)),
            ),
        ),
        RigidMount(
            name="optional-right-arm-mounted-to-seat",
            parent_part="chair",
            parent_element="seat",
            child_part="chair",
            child_element="right_arm",
            active_when=(
                ActiveWhen(factor="chair_family", values=("upright", "task")),
                ActiveWhen(factor="optional_arms", values=(True,)),
            ),
        ),
    ),
    population_checks=(
        PopulationCheck(
            name="covers-chair-families",
            predicate=lambda samples: _covers_choice(
                samples, "chair_family", {"upright", "lounge", "task"}
            ),
            message="Validation must exercise upright, lounge, and task-chair regimes.",
        ),
        PopulationCheck(
            name="covers-upright-bases",
            predicate=lambda samples: _covers_choice(
                [s for s in samples if s["chair_family"] == "upright"],
                "upright_base",
                {"four_leg", "sled"},
            ),
            message="Validation must exercise four-leg and sled upright bases.",
        ),
        PopulationCheck(
            name="covers-seat-profiles",
            predicate=lambda samples: _covers_choice(
                samples, "seat_surface_profile", {"flat", "cushioned"}
            ),
            message="Validation must exercise flat and lofted cushioned seats.",
        ),
        PopulationCheck(
            name="covers-shell-topologies",
            predicate=lambda samples: _covers_choice(
                samples, "shell_topology", {"separate", "integrated"}
            ),
            message="Validation must exercise separate and continuous molded seat-back shells.",
        ),
    ),
    build=build_model,
    tests=run_tests,
    task_requirements=(
        "Every sample must have a finite seat/base interface and either a continuous shell or finite back roots.",
        "Upright, low lounge, and five-spoke task-chair regimes must retain their distinct geometry.",
        "Clear seat width must remain at least 0.40 m and exclude the outside arm assemblies.",
        "Every active arm assembly must mount directly to the seat with a finite side footprint.",
    ),
    tags=("chair", "upright", "lounge", "task", "sled", "pedestal"),
)
