from __future__ import annotations

from typing import Any, Mapping, Sequence

from assetengine import (
    ActiveWhen,
    Constraint,
    Derived,
    GeneratorDesign,
    GeneratorSpec,
    JointMount,
    PopulationCheck,
    RelativeUniformFloat,
    RigidMount,
    UniformChoice,
    UniformFloat,
    UniformInt,
)
from assetengine.articraft import (
    ArticulatedObject,
    ArticulationType,
    Box,
    MotionLimits,
    Origin,
    TestContext,
)


def _box(
    part, name: str, size: tuple[float, float, float], center: tuple[float, float, float]
) -> None:
    part.visual(Box(size), origin=Origin(xyz=center), name=name)


def _bay_bounds(width: float, wall: float, count: int) -> list[tuple[float, float]]:
    bay_width = (width - (count + 1) * wall) / count
    left = -0.5 * width + wall
    return [
        (left + i * (bay_width + wall), left + i * (bay_width + wall) + bay_width)
        for i in range(count)
    ]


def _open_bays(layout: str, count: int) -> set[int]:
    if layout == "open_shelves":
        return set(range(count))
    if layout == "side_doors":
        return {1} if count in {2, 3} else {1, 2}
    if layout == "side_drawers":
        return {1} if count == 3 else (set() if count == 2 else {1, 2})
    return set()


def _add_support_base(
    model, root, p: Mapping[str, Any], width: float, depth: float, wall: float
) -> None:
    height = float(p["base_height"])
    if p["base_style"] == "plinth":
        _box(
            root,
            "plinth_base",
            (float(p["plinth_width"]), float(p["plinth_depth"]), height),
            (0.0, 0.5 * wall, 0.5 * height),
        )
        return
    leg = float(p["leg_size"])
    dx, dy = 0.5 * width - wall - 0.5 * leg, 0.5 * depth - wall - 0.5 * leg
    for name, x, y in (
        ("front_left_leg", -dx, -dy),
        ("front_right_leg", dx, -dy),
        ("rear_left_leg", -dx, dy),
        ("rear_right_leg", dx, dy),
    ):
        _box(root, name, (leg, leg, height), (x, y, 0.5 * height))


def _add_door(
    model,
    root,
    index: int | str,
    x0: float,
    x1: float,
    front_y: float,
    z: float,
    height: float,
    thickness: float,
) -> None:
    gap = 0.004
    leaf_width = x1 - x0 - gap
    door = model.part(f"door_{index}")
    _box(door, "leaf", (leaf_width, thickness, height - 2.0 * gap), (0.5 * leaf_width, 0.0, 0.0))
    model.articulation(
        f"case_to_door_{index}",
        ArticulationType.REVOLUTE,
        parent=root,
        child=door,
        origin=Origin(xyz=(x0, front_y, z)),
        axis=(0.0, 0.0, 1.0),
        motion_limits=MotionLimits(lower=-1.55, upper=0.0, effort=20.0, velocity=1.0),
    )


def _add_drawer(
    model,
    root,
    name: str,
    x: float,
    front_y: float,
    z: float,
    bay_width: float,
    row_height: float,
    depth: float,
    wall: float,
    front_t: float,
) -> None:
    drawer = model.part(name)
    gap = 0.005
    box_width = bay_width
    box_height = row_height - 2.0 * gap
    box_depth = depth - 3.0 * wall
    rail = min(0.012, 0.45 * wall)
    _box(drawer, "front", (box_width, front_t, box_height), (0.0, 0.0, 0.0))
    _box(
        drawer,
        "bottom",
        (box_width - 2.0 * rail, box_depth, rail),
        (0.0, 0.5 * (front_t + box_depth), -0.5 * box_height + 0.5 * rail),
    )
    side_z = -0.25 * box_height + 0.25 * rail
    side_height = 0.5 * box_height + 0.5 * rail
    for side, sx in (
        ("left_side", -0.5 * box_width + 0.5 * rail),
        ("right_side", 0.5 * box_width - 0.5 * rail),
    ):
        _box(
            drawer, side, (rail, box_depth, side_height), (sx, 0.5 * (front_t + box_depth), side_z)
        )
    model.articulation(
        f"case_to_{name}",
        ArticulationType.PRISMATIC,
        parent=root,
        child=drawer,
        origin=Origin(xyz=(x, front_y, z)),
        axis=(0.0, -1.0, 0.0),
        motion_limits=MotionLimits(lower=0.0, upper=0.65 * box_depth, effort=80.0, velocity=0.4),
    )


def build_model(parameters: Mapping[str, Any]) -> ArticulatedObject:
    width, depth = float(parameters["overall_width"]), float(parameters["overall_depth"])
    case_height, wall = float(parameters["case_height"]), float(parameters["panel_thickness"])
    base_height = float(parameters["base_height"])
    bay_count, construction = int(parameters["bay_count"]), str(parameters["construction"])
    layout = str(parameters["front_layout"])
    inner_bottom, inner_top = base_height + wall, base_height + case_height - wall
    inner_height = inner_top - inner_bottom
    model = ArticulatedObject(name="tv_stand_media_console")
    root = model.part("console")
    _box(root, "case_top", (width, depth, wall), (0.0, 0.0, base_height + case_height - 0.5 * wall))
    _box(root, "case_bottom", (width, depth, wall), (0.0, 0.0, base_height + 0.5 * wall))
    _add_support_base(model, root, parameters, width, depth, wall)

    if construction == "open_frame":
        post = float(parameters["frame_post_size"])
        dx, dy = 0.5 * width - 0.5 * post, 0.5 * depth - 0.5 * post
        for name, x, y in (
            ("frame_front_left", -dx, -dy),
            ("frame_front_right", dx, -dy),
            ("frame_rear_left", -dx, dy),
            ("frame_rear_right", dx, dy),
        ):
            _box(root, name, (post, post, inner_height), (x, y, inner_bottom + 0.5 * inner_height))
        if int(parameters["open_shelf_count"]) == 1:
            _box(
                root,
                "frame_middle_shelf",
                (width, depth, wall),
                (0.0, 0.0, inner_bottom + float(parameters["shelf_height_ratio"]) * inner_height),
            )
        return model

    _box(
        root,
        "case_left_side",
        (wall, depth, inner_height),
        (-0.5 * width + 0.5 * wall, 0.0, inner_bottom + 0.5 * inner_height),
    )
    _box(
        root,
        "case_right_side",
        (wall, depth, inner_height),
        (0.5 * width - 0.5 * wall, 0.0, inner_bottom + 0.5 * inner_height),
    )
    bays = _bay_bounds(width, wall, bay_count)
    for index in range(bay_count - 1):
        _box(
            root,
            f"divider_{index}",
            (wall, depth - wall, inner_height),
            (bays[index][1] + 0.5 * wall, -0.5 * wall, inner_bottom + 0.5 * inner_height),
        )

    open_bays = _open_bays(layout, bay_count)
    if int(parameters["open_shelf_count"]) == 1:
        shelf_z = inner_bottom + float(parameters["shelf_height_ratio"]) * inner_height
        for index in sorted(open_bays):
            x0, x1 = bays[index]
            _box(
                root,
                f"open_shelf_{index}",
                (x1 - x0, depth - wall, wall),
                (0.5 * (x0 + x1), -0.5 * wall, shelf_z),
            )

    front_t = float(parameters["front_thickness"])
    drawer_front_y = -0.5 * depth + 0.5 * front_t
    door_front_y = -0.5 * depth - 0.5 * front_t
    if layout == "all_doors":
        for index, (x0, x1) in enumerate(bays):
            _add_door(
                model,
                root,
                index,
                x0,
                x1,
                door_front_y,
                inner_bottom + 0.5 * inner_height,
                inner_height,
                front_t,
            )
    elif layout == "side_doors":
        x0, x1 = bays[0]
        _add_door(
            model,
            root,
            "side_left",
            x0,
            x1,
            door_front_y,
            inner_bottom + 0.5 * inner_height,
            inner_height,
            front_t,
        )
        if bay_count >= 3:
            x0, x1 = bays[-1]
            _add_door(
                model,
                root,
                "side_right",
                x0,
                x1,
                door_front_y,
                inner_bottom + 0.5 * inner_height,
                inner_height,
                front_t,
            )
    elif layout == "side_drawers":
        rows = int(parameters["drawer_rows"])
        row_height = inner_height / rows
        for side, index in (("left", 0), ("right", bay_count - 1)):
            x0, x1 = bays[index]
            for row in range(rows):
                _add_drawer(
                    model,
                    root,
                    f"{side}_drawer_{row}",
                    0.5 * (x0 + x1),
                    drawer_front_y,
                    inner_bottom + (row + 0.5) * row_height,
                    x1 - x0,
                    row_height,
                    depth,
                    wall,
                    front_t,
                )

    cable_index = min(range(bay_count), key=lambda i: abs(sum(bays[i])))
    cable_x = 0.5 * sum(bays[cable_index])
    cable_w, cable_h = (
        float(parameters["cable_opening_width"]),
        float(parameters["cable_opening_height"]),
    )
    cable_z = inner_bottom + 0.85 * inner_height
    left, right = cable_x - 0.5 * cable_w, cable_x + 0.5 * cable_w
    bottom, top = cable_z - 0.5 * cable_h, cable_z + 0.5 * cable_h
    inner_left, inner_right, back_y = (
        -0.5 * width + wall,
        0.5 * width - wall,
        0.5 * depth - 0.5 * wall,
    )
    _box(
        root,
        "back_left",
        (left - inner_left, wall, inner_height),
        (0.5 * (inner_left + left), back_y, inner_bottom + 0.5 * inner_height),
    )
    _box(
        root,
        "back_right",
        (inner_right - right, wall, inner_height),
        (0.5 * (right + inner_right), back_y, inner_bottom + 0.5 * inner_height),
    )
    _box(
        root,
        "back_below_cable",
        (cable_w, wall, bottom - inner_bottom),
        (cable_x, back_y, 0.5 * (inner_bottom + bottom)),
    )
    _box(
        root,
        "back_above_cable",
        (cable_w, wall, inner_top - top),
        (cable_x, back_y, 0.5 * (top + inner_top)),
    )
    return model


def run_tests(model: ArticulatedObject, p: Mapping[str, Any]):
    v = lambda name: float(p[name])
    clear_height = v("case_height") - 2.0 * v("panel_thickness")
    bay_width = v("bay_clear_width")
    ctx = TestContext(model)
    ctx.check_model_valid()
    ctx.check("case-retains-positive-storage-height", clear_height > 0.22)
    ctx.check("bay-width-is-ordinary", 0.32 <= bay_width <= 0.62)
    ctx.check("base-reaches-ground", v("base_height") > 0.0)
    ctx.check(
        "cable-opening-fits-one-bay",
        v("cable_opening_width") < 0.65 * bay_width
        and v("cable_opening_height") < 0.25 * clear_height,
    )
    if p["base_style"] == "plinth":
        ctx.check("plinth-height-stays-in-low-socle-regime", 0.04 <= v("base_height") <= 0.10)
    else:
        ctx.check(
            "legs-fit-under-case", v("leg_size") < v("overall_depth") - 2.0 * v("panel_thickness")
        )
    return ctx.report()


def _choices(samples: Sequence[Mapping[str, Any]], factor: str, values: set[str]) -> bool:
    return {str(sample[factor]) for sample in samples} >= values


def _bounds(samples: Sequence[Mapping[str, Any]], factor: str, low: float, high: float) -> bool:
    values = [float(sample[factor]) for sample in samples]
    return min(values) <= low and max(values) >= high


GENERATOR = GeneratorSpec(
    name="tv_stand_media_console",
    category="tv_stand_media_console",
    description="Procedural tiered TV stands and cabinet media consoles with genuine doors, drawers, cable routing, and grounded bases.",
    design=GeneratorDesign(
        coverage=(
            "Ordinary straight floor-standing TV furniture includes distinct open-frame/tiered stands and enclosed cabinet consoles. Cabinet fronts cover open media bays, fully enclosed hinged doors, center-open consoles with hinged side doors, and center-open consoles with side drawers. Two-, three-, and four-bay widths are coupled to 0.38-0.58 m ordinary bay modules, producing 1.10-2.20 m totals; depth is 0.30-0.50 m, case height 0.28-0.48 m. Legs use 0.08-0.22 m clearance while plinths use a separate 0.04-0.10 m socle regime. Floating, corner/fireplace, tall-wall, glass-display, and decorative variants are excluded."
        ),
        factors=(
            "Bay count precedes a RelativeUniformFloat width so each construction retains ordinary 0.38-0.58 m modules instead of extreme independent cross-products. Depth, case height, panel gauge, shelf elevation, leg height, and component section sizes remain independent ordinary targets. Plinth dimensions and height are construction-specific, front thickness derives from panel gauge, and cable targets use transparent bay/interior caps. All stochastic factors are uniform."
        ),
        components=(
            "Open frames use top/bottom tiers, four corner posts, and an optional middle shelf. Cabinet cases add full sides, dividers, a split rear panel, zero/one shelves per open bay, and either open fronts, separately articulated full-front or side door leaves, or prismatic side drawers with fronts, bottoms, and side walls. Bases are four square posts or a low inset plinth. Leg taper/profile and cable-hole outline remain fixed; handles, fasteners, finish, and small edge radii are incidental."
        ),
        physics_and_task=(
            "Every support has a declared finite case-bottom mount and reaches z=0. Cabinet doors are separate revolute children; drawers are separate prismatic tray children retained in their bays. Open frames have genuinely open sides/backs, cabinets retain bounded cable routing, and all constructions have an uninterrupted top. The initial critic's topology, bay-width, plinth-regime, and operable-interface criteria are implemented; no load, wall, robot, or material-strength threshold is inferred."
        ),
    ),
    factors=(
        UniformChoice(
            name="construction",
            choices=("open_frame", "cabinet"),
            description="Tiered open-post frame or enclosed cabinet carcass.",
        ),
        UniformChoice(
            name="front_layout",
            choices=("open_shelves", "all_doors", "side_doors", "side_drawers"),
            active_when=(ActiveWhen(factor="construction", values=("cabinet",)),),
            description="Cabinet front topology: open, fully hinged-door closed, or open center with drawers at both sides.",
        ),
        UniformChoice(
            name="base_style",
            choices=("four_legs", "plinth"),
            description="Four legs or a low inset plinth; open frames constrain this to legs.",
        ),
        UniformInt(
            name="bay_count",
            low=2,
            high=4,
            description="Count of ordinary-width media/storage modules.",
            unit="count",
        ),
        RelativeUniformFloat(
            name="overall_width",
            reference="bay_count",
            ratio_low=0.38,
            ratio_high=0.58,
            hard_min=1.10,
            hard_max=2.20,
            description="Overall width coupled to 0.38-0.58 m modules.",
            unit="m",
        ),
        UniformFloat(
            name="overall_depth",
            low=0.30,
            high=0.50,
            description="Independent cabinet depth.",
            unit="m",
        ),
        UniformFloat(
            name="case_height",
            low=0.28,
            high=0.48,
            description="Independent case or open-frame upper height.",
            unit="m",
        ),
        UniformFloat(
            name="leg_height",
            low=0.08,
            high=0.22,
            active_when=(ActiveWhen(factor="base_style", values=("four_legs",)),),
            description="Leg-supported floor clearance.",
            unit="m",
        ),
        UniformFloat(
            name="plinth_height",
            low=0.04,
            high=0.10,
            active_when=(ActiveWhen(factor="base_style", values=("plinth",)),),
            description="Construction-specific low plinth height.",
            unit="m",
        ),
        Derived(
            name="base_height",
            derive=lambda p: (
                p["leg_height"] if p["base_style"] == "four_legs" else p["plinth_height"]
            ),
            depends_on=("base_style", "leg_height", "plinth_height"),
            description="Active support height.",
            unit="m",
        ),
        UniformFloat(
            name="panel_thickness",
            low=0.016,
            high=0.028,
            description="Structural panel gauge.",
            unit="m",
        ),
        UniformFloat(
            name="shelf_height_ratio",
            low=0.34,
            high=0.66,
            description="Optional middle shelf elevation in clear height.",
            unit="ratio",
        ),
        UniformInt(
            name="open_shelf_count",
            low=0,
            high=1,
            description="Unsplit or once-divided open equipment spaces.",
            unit="count",
        ),
        UniformInt(
            name="drawer_rows",
            low=1,
            high=2,
            active_when=(ActiveWhen(factor="front_layout", values=("side_drawers",)),),
            description="Drawer rows in each closed side bay.",
            unit="count",
        ),
        Derived(
            name="front_thickness",
            derive=lambda p: p["panel_thickness"],
            depends_on=("panel_thickness",),
            description="Door/drawer front gauge.",
            unit="m",
        ),
        UniformFloat(
            name="cable_opening_width_target",
            low=0.06,
            high=0.12,
            active_when=(ActiveWhen(factor="construction", values=("cabinet",)),),
            description="Preferred rear cable opening width.",
            unit="m",
        ),
        UniformFloat(
            name="cable_opening_height_target",
            low=0.04,
            high=0.08,
            active_when=(ActiveWhen(factor="construction", values=("cabinet",)),),
            description="Preferred rear cable opening height.",
            unit="m",
        ),
        Derived(
            name="bay_clear_width",
            derive=lambda p: (
                (p["overall_width"] - (p["bay_count"] + 1) * p["panel_thickness"]) / p["bay_count"]
            ),
            depends_on=("overall_width", "bay_count", "panel_thickness"),
            description="Exact clear bay width.",
            unit="m",
        ),
        Derived(
            name="clear_case_height",
            derive=lambda p: p["case_height"] - 2.0 * p["panel_thickness"],
            depends_on=("case_height", "panel_thickness"),
            description="Exact clear case height.",
            unit="m",
        ),
        Derived(
            name="cable_opening_width",
            derive=lambda p: min(p["cable_opening_width_target"], 0.60 * p["bay_clear_width"]),
            depends_on=("cable_opening_width_target", "bay_clear_width"),
            description="Capped cable width.",
            unit="m",
        ),
        Derived(
            name="cable_opening_height",
            derive=lambda p: min(p["cable_opening_height_target"], 0.20 * p["clear_case_height"]),
            depends_on=("cable_opening_height_target", "clear_case_height"),
            description="Capped cable height.",
            unit="m",
        ),
        UniformFloat(
            name="leg_size",
            low=0.025,
            high=0.055,
            active_when=(ActiveWhen(factor="base_style", values=("four_legs",)),),
            description="Square leg section.",
            unit="m",
        ),
        UniformFloat(
            name="frame_post_size",
            low=0.025,
            high=0.050,
            active_when=(ActiveWhen(factor="construction", values=("open_frame",)),),
            description="Square open-frame post section.",
            unit="m",
        ),
        Derived(
            name="plinth_width",
            derive=lambda p: 0.86 * p["overall_width"],
            depends_on=("overall_width",),
            description="Inset plinth width.",
            unit="m",
            active_when=(ActiveWhen(factor="base_style", values=("plinth",)),),
        ),
        Derived(
            name="plinth_depth",
            derive=lambda p: 0.78 * p["overall_depth"],
            depends_on=("overall_depth",),
            description="Inset plinth depth.",
            unit="m",
            active_when=(ActiveWhen(factor="base_style", values=("plinth",)),),
        ),
    ),
    constraints=(
        Constraint(
            name="open-frame-uses-legs",
            predicate=lambda p: p["construction"] != "open_frame" or p["base_style"] == "four_legs",
            message="Open tiered frames use discrete legs rather than cabinet plinths.",
        ),
    ),
    relationships=(
        RigidMount(
            name="plinth-mounted-to-case-bottom",
            parent_part="console",
            parent_element="case_bottom",
            child_part="console",
            child_element="plinth_base",
            active_when=(
                ActiveWhen(factor="construction", values=("cabinet",)),
                ActiveWhen(factor="base_style", values=("plinth",)),
            ),
        ),
        *tuple(
            RigidMount(
                name=f"{leg.replace('_', '-')}-mounted-to-case-bottom",
                parent_part="console",
                parent_element="case_bottom",
                child_part="console",
                child_element=leg,
                active_when=(ActiveWhen(factor="base_style", values=("four_legs",)),),
            )
            for leg in ("front_left_leg", "front_right_leg", "rear_left_leg", "rear_right_leg")
        ),
        *tuple(
            JointMount(
                name=f"door-{i}-hinged-to-case",
                joint=f"case_to_door_{i}",
                parent_part="console",
                child_part=f"door_{i}",
                allowed_joint_types=("revolute",),
                active_when=(
                    ActiveWhen(factor="construction", values=("cabinet",)),
                    ActiveWhen(factor="front_layout", values=("all_doors",)),
                    ActiveWhen(factor="bay_count", values=tuple(range(max(2, i + 1), 5))),
                ),
            )
            for i in range(4)
        ),
        JointMount(
            name="side-left-door-hinged-to-case",
            joint="case_to_door_side_left",
            parent_part="console",
            child_part="door_side_left",
            allowed_joint_types=("revolute",),
            active_when=(
                ActiveWhen(factor="construction", values=("cabinet",)),
                ActiveWhen(factor="front_layout", values=("side_doors",)),
            ),
        ),
        JointMount(
            name="side-right-door-hinged-to-case",
            joint="case_to_door_side_right",
            parent_part="console",
            child_part="door_side_right",
            allowed_joint_types=("revolute",),
            active_when=(
                ActiveWhen(factor="construction", values=("cabinet",)),
                ActiveWhen(factor="front_layout", values=("side_doors",)),
                ActiveWhen(factor="bay_count", values=(3, 4)),
            ),
        ),
        *tuple(
            JointMount(
                name=f"{side}-drawer-{row}-guided-by-case",
                joint=f"case_to_{side}_drawer_{row}",
                parent_part="console",
                child_part=f"{side}_drawer_{row}",
                allowed_joint_types=("prismatic",),
                active_when=(
                    ActiveWhen(factor="construction", values=("cabinet",)),
                    ActiveWhen(factor="front_layout", values=("side_drawers",)),
                    ActiveWhen(factor="drawer_rows", values=tuple(range(row + 1, 3))),
                ),
            )
            for side in ("left", "right")
            for row in range(2)
        ),
    ),
    build=build_model,
    tests=run_tests,
    population_checks=(
        PopulationCheck(
            name="covers-constructions",
            predicate=lambda s: _choices(s, "construction", {"open_frame", "cabinet"}),
            message="Exercise open-frame and cabinet families.",
        ),
        PopulationCheck(
            name="covers-bases",
            predicate=lambda s: _choices(s, "base_style", {"four_legs", "plinth"}),
            message="Exercise legs and plinths.",
        ),
        PopulationCheck(
            name="covers-bay-counts",
            predicate=lambda s: {int(x["bay_count"]) for x in s} >= {2, 3, 4},
            message="Exercise every bay count.",
        ),
        PopulationCheck(
            name="covers-width-envelope",
            predicate=lambda s: _bounds(s, "overall_width", 1.12, 2.18),
            message="Reach compact and wide widths under the bay-count dependency.",
        ),
        PopulationCheck(
            name="covers-depth-envelope",
            predicate=lambda s: _bounds(s, "overall_depth", 0.305, 0.495),
            message="Reach shallow and deep cases.",
        ),
        PopulationCheck(
            name="covers-shelf-counts",
            predicate=lambda s: {int(x["open_shelf_count"]) for x in s} >= {0, 1},
            message="Exercise unsplit and divided openings.",
        ),
    ),
    task_requirements=(
        "Provide an uninterrupted horizontal top surface.",
        "Open constructions retain equipment space; cabinet constructions provide rear cable routing.",
        "Every support seats to the case bottom and reaches the floor.",
        "Door leaves and drawer trays retain their genuine revolute or prismatic parent interfaces.",
    ),
    tags=(
        "tv stand",
        "media console",
        "open frame",
        "cabinet",
        "doors",
        "drawers",
        "cable management",
    ),
)
