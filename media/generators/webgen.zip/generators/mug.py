from __future__ import annotations

import math
from typing import Any, Mapping, Sequence

import manifold3d
import numpy as np

from assetengine import (
    Constraint,
    Derived,
    GeneratorDesign,
    GeneratorSpec,
    PopulationCheck,
    RelativeUniformFloat,
    RigidMount,
    UniformChoice,
    UniformFloat,
)
from assetengine.articraft import (
    ArticulatedObject,
    LatheGeometry,
    MeshGeometry,
    Origin,
    TestContext,
    mesh_from_geometry,
)

_RADIAL_SEGMENTS = 192
_WALL_SAMPLES = 14
_HANDLE_CURVE_SAMPLES = 36
_HANDLE_SECTION_SEGMENTS = 32
_HANDLE_ROOT_STOCK = 0.018
_HANDLE_MOUNT_MARGIN = 0.003


def _as_manifold(geometry: MeshGeometry, *, context: str) -> manifold3d.Manifold:
    mesh = manifold3d.Mesh(
        np.asarray(geometry.vertices, dtype=np.float32),
        np.asarray(geometry.faces, dtype=np.uint32),
    )
    solid = manifold3d.Manifold(mesh)
    if solid.status() != manifold3d.Error.NoError:
        raise ValueError(f"{context} is not a valid manifold solid")
    return solid


def _mesh_from_manifold(solid: manifold3d.Manifold) -> MeshGeometry:
    output = solid.to_mesh()
    serialized_vertices = np.round(
        np.asarray(output.vert_properties[:, :3], dtype=float), decimals=6
    )
    source_faces = np.asarray(output.tri_verts, dtype=np.uint32)
    coordinate_indices: dict[tuple[float, float, float], int] = {}
    welded_vertices: list[tuple[float, float, float]] = []
    vertex_remap = np.empty(len(serialized_vertices), dtype=np.uint32)
    for source_index, vertex in enumerate(serialized_vertices):
        coordinate = tuple(float(value) for value in vertex)
        welded_index = coordinate_indices.get(coordinate)
        if welded_index is None:
            welded_index = len(welded_vertices)
            coordinate_indices[coordinate] = welded_index
            welded_vertices.append(coordinate)
        vertex_remap[source_index] = welded_index
    raw_vertices = np.asarray(welded_vertices, dtype=float)
    welded_faces = vertex_remap[source_faces]
    distinct_faces = np.asarray(
        [face for face in welded_faces if len({int(value) for value in face}) == 3],
        dtype=np.uint32,
    )
    triangle_points = raw_vertices[distinct_faces]
    serialized_double_areas = np.linalg.norm(
        np.cross(
            triangle_points[:, 1] - triangle_points[:, 0],
            triangle_points[:, 2] - triangle_points[:, 0],
        ),
        axis=1,
    )
    raw_faces = distinct_faces[serialized_double_areas > 2e-12]
    # Manifold booleans can retain isolated, numerically collapsed cut triangles. They carry
    # zero area and volume but become separate components after six-decimal mesh serialization.
    # Weld and measure at that actual serialized precision, then retain the complete
    # edge-connected exterior shell rather than deleting small faces from that shell.
    triangle_points = raw_vertices[raw_faces]
    double_areas = np.linalg.norm(
        np.cross(
            triangle_points[:, 1] - triangle_points[:, 0],
            triangle_points[:, 2] - triangle_points[:, 0],
        ),
        axis=1,
    )
    parents = list(range(len(raw_faces)))

    def find(index: int) -> int:
        while parents[index] != index:
            parents[index] = parents[parents[index]]
            index = parents[index]
        return index

    def union(first: int, second: int) -> None:
        first_root, second_root = find(first), find(second)
        if first_root != second_root:
            parents[second_root] = first_root

    edge_owner: dict[tuple[int, int], int] = {}
    for face_index, face in enumerate(raw_faces):
        for first, second in ((face[0], face[1]), (face[1], face[2]), (face[2], face[0])):
            edge = tuple(sorted((int(first), int(second))))
            prior = edge_owner.setdefault(edge, face_index)
            union(face_index, prior)

    face_groups: dict[int, list[int]] = {}
    for face_index in range(len(raw_faces)):
        face_groups.setdefault(find(face_index), []).append(face_index)
    kept_indices = max(
        face_groups.values(),
        key=lambda indices: float(np.sum(double_areas[np.asarray(indices, dtype=int)])),
    )
    kept_faces = raw_faces[np.asarray(kept_indices, dtype=int)]
    if not len(kept_faces):
        raise ValueError("boolean result contains no finite-area faces")
    used_vertices = np.unique(kept_faces)
    remap = np.full(len(raw_vertices), -1, dtype=int)
    remap[used_vertices] = np.arange(len(used_vertices))
    return MeshGeometry(
        vertices=[tuple(float(value) for value in raw_vertices[index]) for index in used_vertices],
        faces=[tuple(int(value) for value in remap[face]) for face in kept_faces],
    )


def _outer_radius(parameters: Mapping[str, Any], height: float) -> float:
    body_height = float(parameters["body_height"])
    rim_radius = 0.5 * float(parameters["rim_diameter"])
    base_radius = 0.5 * float(parameters["base_diameter"])
    fraction = min(1.0, max(0.0, height / body_height))
    if parameters["wall_path"] == "rounded" and "wall_round_power" in parameters:
        # Optional, never sampled: a power curve that rounds the heel more strongly, for illustration.
        progression = 1.0 - (1.0 - fraction) ** float(parameters["wall_round_power"])
    elif parameters["wall_path"] == "rounded":
        progression = math.sin(0.5 * math.pi * fraction)
    else:
        progression = fraction
    return base_radius + (rim_radius - base_radius) * progression


def _cup_body_geometry(parameters: Mapping[str, Any]) -> LatheGeometry:
    body_height = float(parameters["body_height"])
    base_thickness = float(parameters["base_thickness"])
    wall_thickness = float(parameters["wall_thickness"])

    profile: list[tuple[float, float]] = [(0.0, 0.0), (_outer_radius(parameters, 0.0), 0.0)]
    for index in range(1, _WALL_SAMPLES + 1):
        fraction = index / _WALL_SAMPLES
        profile.append((_outer_radius(parameters, body_height * fraction), body_height * fraction))

    # Close only the annular rim, then return down the inside wall to the raised inner floor.
    profile.append((_outer_radius(parameters, body_height) - wall_thickness, body_height))
    for index in range(_WALL_SAMPLES - 1, -1, -1):
        fraction = index / _WALL_SAMPLES
        z = base_thickness + (body_height - base_thickness) * fraction
        profile.append((_outer_radius(parameters, z) - wall_thickness, z))
    profile.append((0.0, base_thickness))
    return LatheGeometry(profile, segments=_RADIAL_SEGMENTS, closed=True)


def _cup_mount_cutter_geometry(parameters: Mapping[str, Any]) -> LatheGeometry:
    """Filled outer silhouette used only to remove inward handle-root stock."""
    body_height = float(parameters["body_height"])
    profile: list[tuple[float, float]] = [(0.0, 0.0), (_outer_radius(parameters, 0.0), 0.0)]
    for index in range(1, _WALL_SAMPLES + 1):
        fraction = index / _WALL_SAMPLES
        z = body_height * fraction
        profile.append((_outer_radius(parameters, z), z))
    profile.append((0.0, body_height))
    return LatheGeometry(profile, segments=_RADIAL_SEGMENTS, closed=True)


def _handle_half_centerline(
    parameters: Mapping[str, Any], *, upper: bool
) -> list[tuple[float, float, float, float]]:
    center_z = float(parameters["handle_center_height"])
    opening_height = float(parameters["handle_opening_height"])
    member_thickness = float(parameters["handle_member_thickness"])
    opening_depth = float(parameters["handle_opening_depth"])
    root_center_half_span = 0.5 * (opening_height + member_thickness)
    root_z = center_z + (root_center_half_span if upper else -root_center_half_span)
    root_x = _outer_radius(parameters, root_z)

    other_root_z = center_z - (root_center_half_span if upper else -root_center_half_span)
    other_root_x = _outer_radius(parameters, other_root_z)
    outer_x = max(root_x, other_root_x) + opening_depth + 0.5 * member_thickness
    radial_axis = outer_x - root_x

    centerline: list[tuple[float, float, float, float]] = []
    if upper:
        centerline.append((root_x - _HANDLE_ROOT_STOCK, root_z, 0.0, 1.0))
        indices = range(_HANDLE_CURVE_SAMPLES + 1)
    else:
        indices = range(_HANDLE_CURVE_SAMPLES, 2 * _HANDLE_CURVE_SAMPLES + 1)

    outline_power = 1.0 if parameters["handle_outline"] == "oval" else 0.58
    for index in indices:
        theta = math.pi * index / (2.0 * _HANDLE_CURVE_SAMPLES)
        sine = math.sin(theta)
        cosine = math.cos(theta)
        x = root_x + radial_axis * sine**outline_power
        z = center_z + root_center_half_span * math.copysign(abs(cosine) ** outline_power, cosine)
        if index == 0:
            normal_x, normal_z = 0.0, 1.0
        elif index == _HANDLE_CURVE_SAMPLES:
            normal_x, normal_z = 1.0, 0.0
        elif index == 2 * _HANDLE_CURVE_SAMPLES:
            normal_x, normal_z = 0.0, -1.0
        else:
            tangent_x = radial_axis * outline_power * sine ** (outline_power - 1.0) * cosine
            tangent_z = (
                -root_center_half_span * outline_power * abs(cosine) ** (outline_power - 1.0) * sine
            )
            tangent_length = math.hypot(tangent_x, tangent_z)
            normal_x, normal_z = -tangent_z / tangent_length, tangent_x / tangent_length
        centerline.append((x, z, normal_x, normal_z))

    if not upper:
        centerline.append((root_x - _HANDLE_ROOT_STOCK, root_z, 0.0, -1.0))
    return centerline


def _extended_handle_geometry(parameters: Mapping[str, Any]) -> MeshGeometry:
    """Sweep a smooth oval section along the complete planar handle loop, root to root.

    The upper and lower half centerlines meet at the outer midpoint with the same position and
    normal, so one sweep gives a seamless loop with end caps only at the two roots.
    """
    upper = _handle_half_centerline(parameters, upper=True)
    lower = _handle_half_centerline(parameters, upper=False)
    centerline = upper + lower[1:]
    half_in_plane = 0.5 * float(parameters["handle_member_thickness"])
    half_axial = 0.5 * float(parameters["handle_axial_width"])
    vertices: list[tuple[float, float, float]] = []
    for x, z, normal_x, normal_z in centerline:
        for section_index in range(_HANDLE_SECTION_SEGMENTS):
            angle = 2.0 * math.pi * section_index / _HANDLE_SECTION_SEGMENTS
            radial_offset = half_in_plane * math.cos(angle)
            axial_offset = half_axial * math.sin(angle)
            vertices.append(
                (
                    x + radial_offset * normal_x,
                    axial_offset,
                    z + radial_offset * normal_z,
                )
            )

    faces: list[tuple[int, int, int]] = []
    for ring_index in range(len(centerline) - 1):
        current = ring_index * _HANDLE_SECTION_SEGMENTS
        following = (ring_index + 1) * _HANDLE_SECTION_SEGMENTS
        for section_index in range(_HANDLE_SECTION_SEGMENTS):
            next_section = (section_index + 1) % _HANDLE_SECTION_SEGMENTS
            faces.append(
                (
                    current + section_index,
                    following + section_index,
                    following + next_section,
                )
            )
            faces.append(
                (
                    current + section_index,
                    following + next_section,
                    current + next_section,
                )
            )

    start_center = len(vertices)
    vertices.append((centerline[0][0], 0.0, centerline[0][1]))
    end_center = len(vertices)
    vertices.append((centerline[-1][0], 0.0, centerline[-1][1]))
    end_ring = (len(centerline) - 1) * _HANDLE_SECTION_SEGMENTS
    for section_index in range(_HANDLE_SECTION_SEGMENTS):
        next_section = (section_index + 1) % _HANDLE_SECTION_SEGMENTS
        faces.append((start_center, section_index, next_section))
        faces.append((end_center, end_ring + next_section, end_ring + section_index))
    return MeshGeometry(vertices=vertices, faces=faces)


def _trim_handle_root(
    *,
    body_geometry: MeshGeometry,
    cutter_geometry: MeshGeometry,
    extended_geometry: MeshGeometry,
    parameters: Mapping[str, Any],
    component_name: str,
) -> MeshGeometry:
    extended_solid = _as_manifold(extended_geometry, context=f"extended {component_name}")
    body_solid = _as_manifold(body_geometry, context="cup body")
    intersection_volume = float((extended_solid ^ body_solid).volume())
    minimum_intersection = (
        0.04
        * float(parameters["handle_member_thickness"])
        * float(parameters["handle_axial_width"])
        * float(parameters["wall_thickness"])
    )
    if intersection_volume < minimum_intersection:
        raise ValueError(f"{component_name} stock did not positively intersect the cup wall")

    cutter_solid = _as_manifold(cutter_geometry, context="filled cup mount cutter")
    cutter_intersection = float((extended_solid ^ cutter_solid).volume())
    if cutter_intersection < minimum_intersection:
        raise ValueError(f"cup envelope did not trim the {component_name} root stock")

    components = list((extended_solid - cutter_solid).decompose())
    if not components:
        raise ValueError(f"cup envelope trimming removed the complete {component_name}")
    exterior = max(
        components,
        key=lambda component: max(
            float(vertex[0]) for vertex in component.to_mesh().vert_properties
        ),
    )
    trimmed = _mesh_from_manifold(exterior)
    if not trimmed.faces:
        raise ValueError(f"trimmed {component_name} has no faces")
    _as_manifold(trimmed, context=f"cleaned trimmed {component_name}")
    return trimmed


def build_model(parameters: Mapping[str, Any]) -> ArticulatedObject:
    model = ArticulatedObject(name="ordinary_household_mug_or_teacup")
    neutral = model.material("neutral", rgba=(0.72, 0.72, 0.70, 1.0))
    cup = model.part("cup")

    body_geometry = _cup_body_geometry(parameters)
    cutter_geometry = _cup_mount_cutter_geometry(parameters)
    cup.visual(
        mesh_from_geometry(body_geometry, "cup_body"),
        origin=Origin(),
        material=neutral,
        name="cup_body",
    )

    handle_geometry = _trim_handle_root(
        body_geometry=body_geometry,
        cutter_geometry=cutter_geometry,
        extended_geometry=_extended_handle_geometry(parameters),
        parameters=parameters,
        component_name="handle",
    )
    cup.visual(
        mesh_from_geometry(handle_geometry, "handle"),
        origin=Origin(),
        material=neutral,
        name="handle",
    )
    return model


def run_tests(model: ArticulatedObject, parameters: Mapping[str, Any]):
    value = lambda name: float(parameters[name])
    ctx = TestContext(model)
    ctx.check_model_valid()
    checks = (
        ("body-cavity-has-positive-depth", value("body_height") > value("base_thickness")),
        (
            "body-cavity-has-positive-rim-radius",
            0.5 * value("rim_diameter") > value("wall_thickness"),
        ),
        (
            "base-diameter-matches-authored-ratio",
            abs(value("base_diameter") - value("rim_diameter") * value("base_diameter_ratio"))
            <= 1e-9,
        ),
        (
            "body-aspect-ratio-remains-ordinary",
            0.48 <= value("body_height") / value("rim_diameter") <= 1.50,
        ),
        ("handle-opening-has-positive-height", value("handle_opening_height") > 0.0),
        ("handle-opening-has-positive-depth", value("handle_opening_depth") > 0.0),
        (
            "handle-opening-height-obeys-fit-cap",
            value("handle_opening_height") <= value("handle_opening_height_cap") + 1e-9,
        ),
        (
            "handle-opening-depth-obeys-small-body-cap",
            value("handle_opening_depth") <= 0.48 * value("rim_diameter") + 1e-9,
        ),
        (
            "complete-handle-footprint-stays-between-floor-and-rim",
            value("handle_center_minimum") - 1e-9
            <= value("handle_center_height")
            <= value("handle_center_maximum") + 1e-9,
        ),
    )
    for name, passed in checks:
        ctx.check(name, passed)
    return ctx.report()


def _covers_choice(samples: Sequence[Mapping[str, Any]], factor: str, choices: set[str]) -> bool:
    return {str(sample[factor]) for sample in samples} >= choices


def _covers_bounds(
    samples: Sequence[Mapping[str, Any]],
    factor: str,
    *,
    minimum_at_most: float,
    maximum_at_least: float,
) -> bool:
    values = [float(sample[factor]) for sample in samples]
    return min(values) <= minimum_at_most and max(values) >= maximum_at_least


def _bounds_check(
    name: str,
    factor: str,
    minimum_at_most: float,
    maximum_at_least: float,
    message: str,
) -> PopulationCheck:
    return PopulationCheck(
        name=name,
        predicate=lambda samples: _covers_bounds(
            samples,
            factor,
            minimum_at_most=minimum_at_most,
            maximum_at_least=maximum_at_least,
        ),
        message=message,
    )


GENERATOR = GeneratorSpec(
    name="mug",
    category="mug",
    description=(
        "Ordinary household mugs and teacups with one open side handle and without lids, "
        "saucers, or decoration."
    ),
    design=GeneratorDesign(
        coverage=(
            "Covers plain cylindrical-to-tapered mugs, low teacups, and smoothly rounded cup "
            "walls across ordinary household rim, height, base, wall, and handle envelopes. The "
            "single handle spans oval C-loops and flatter-sided plain D-like outlines with smooth "
            "oval member sections. Lids, saucers, ornamental relief, novelty silhouettes, stems, "
            "and travel-cup closures are excluded."
        ),
        factors=(
            "Rim diameter and body height are independent overlapping household dimensions, "
            "with only the uncommon extreme aspect corners rejected. Base-to-rim ratio and "
            "linear versus rounded wall path independently control body silhouette. Wall and "
            "base thickness and both observable handle-section spans are independent construction "
            "dimensions, preserving fine or substantial handles across body sizes. Handle opening "
            "height and vertical placement track body height. Opening depth keeps an independent "
            "human-scale target whose large end is transparently capped only on small bodies."
        ),
        components=(
            "The visible hollow body varies in diameter, height, taper, curvature, and material "
            "thickness. The sole handle varies in clear height, clear outward depth, section "
            "dimensions, smooth oval section, body-relative height, and oval versus flatter-sided "
            "plain outline. One continuous undecorated loop is swept from root to root, so it has "
            "no seam. Radial tessellation and root stock are incidental."
        ),
        physics_and_task=(
            "The cup body is the root. The one handle is a single continuous loop with upper and "
            "lower permanent roots. Each "
            "root begins with fixed inward sacrificial stock, positively intersects the real "
            "wall, and is trimmed against a filled cup envelope so the cavity stays empty while "
            "zero-gap finite contact remains. The open body cavity and bounded handle opening "
            "are structural; no unrequested hand, hook, or robot clearance is imposed."
        ),
    ),
    factors=(
        UniformFloat(
            name="rim_diameter",
            low=0.065,
            high=0.105,
            description="Outer diameter across the open drinking rim.",
            unit="m",
        ),
        UniformFloat(
            name="body_height",
            low=0.050,
            high=0.125,
            description="Vertical height from the resting base to the open rim.",
            unit="m",
        ),
        UniformChoice(
            name="wall_path",
            choices=("linear", "rounded"),
            description=(
                "Radial side-wall path: straight linear taper/cylinder or a common smooth "
                "rounded rise from base to rim."
            ),
        ),
        UniformChoice(
            name="handle_outline",
            choices=("oval", "flat_sided"),
            description=(
                "Centerline family for the one plain side loop: continuously oval or a common "
                "flatter-sided D-like superellipse."
            ),
        ),
        UniformFloat(
            name="base_diameter_ratio",
            low=0.72,
            high=1.00,
            description="Outer base diameter divided by outer rim diameter.",
            unit="ratio",
        ),
        Derived(
            name="base_diameter",
            derive=lambda p: p["rim_diameter"] * p["base_diameter_ratio"],
            depends_on=("rim_diameter", "base_diameter_ratio"),
            description="Outer base diameter implied by rim diameter and taper ratio.",
            unit="m",
        ),
        UniformFloat(
            name="wall_thickness",
            low=0.0025,
            high=0.0050,
            description="Radial thickness of the vessel side wall.",
            unit="m",
        ),
        UniformFloat(
            name="base_thickness",
            low=0.004,
            high=0.009,
            description="Vertical solid thickness beneath the open cavity.",
            unit="m",
        ),
        UniformFloat(
            name="handle_member_thickness",
            low=0.0045,
            high=0.0100,
            description=(
                "In-plane thickness of the handle loop, measured normal to its curved centerline."
            ),
            unit="m",
        ),
        RelativeUniformFloat(
            name="handle_opening_height_target",
            reference="body_height",
            ratio_low=0.34,
            ratio_high=0.62,
            hard_min=0.018,
            hard_max=0.065,
            description="Preferred clear vertical height within the sole side-handle loop.",
            unit="m",
        ),
        Derived(
            name="handle_opening_height_cap",
            derive=lambda p: (
                p["body_height"]
                - p["base_thickness"]
                - 2.0 * _HANDLE_MOUNT_MARGIN
                - 2.0 * p["handle_member_thickness"]
            ),
            depends_on=("body_height", "base_thickness", "handle_member_thickness"),
            description=(
                "Largest clear handle height that retains complete root footprints above the "
                "inner floor and below the rim."
            ),
            unit="m",
        ),
        Derived(
            name="handle_opening_height",
            derive=lambda p: min(p["handle_opening_height_target"], p["handle_opening_height_cap"]),
            depends_on=("handle_opening_height_target", "handle_opening_height_cap"),
            description="Realized clear handle height after the transparent body-fit cap.",
            unit="m",
        ),
        UniformFloat(
            name="handle_opening_depth_target",
            low=0.020,
            high=0.050,
            description="Preferred clear radial depth of the handle opening outside the cup wall.",
            unit="m",
        ),
        Derived(
            name="handle_opening_depth",
            derive=lambda p: min(p["handle_opening_depth_target"], 0.48 * p["rim_diameter"]),
            depends_on=("handle_opening_depth_target", "rim_diameter"),
            description=(
                "Realized clear outward opening depth, capped only to prevent a handle from "
                "overwhelming the smallest ordinary body."
            ),
            unit="m",
        ),
        UniformFloat(
            name="handle_axial_width",
            low=0.006,
            high=0.016,
            description="Handle solid span perpendicular to its vertical side plane.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="handle_center_target_height",
            reference="body_height",
            ratio_low=0.45,
            ratio_high=0.64,
            description="Preferred body-relative vertical center of the sole handle opening.",
            unit="m",
        ),
        Derived(
            name="handle_center_minimum",
            derive=lambda p: (
                p["base_thickness"]
                + _HANDLE_MOUNT_MARGIN
                + 0.5 * p["handle_opening_height"]
                + p["handle_member_thickness"]
            ),
            depends_on=("base_thickness", "handle_opening_height", "handle_member_thickness"),
            description="Lowest handle center that keeps its complete lower root above the floor.",
            unit="m",
        ),
        Derived(
            name="handle_center_maximum",
            derive=lambda p: (
                p["body_height"]
                - _HANDLE_MOUNT_MARGIN
                - 0.5 * p["handle_opening_height"]
                - p["handle_member_thickness"]
            ),
            depends_on=("body_height", "handle_opening_height", "handle_member_thickness"),
            description="Highest handle center that keeps its complete upper root below the rim.",
            unit="m",
        ),
        Derived(
            name="handle_center_height",
            derive=lambda p: min(
                max(p["handle_center_target_height"], p["handle_center_minimum"]),
                p["handle_center_maximum"],
            ),
            depends_on=(
                "handle_center_target_height",
                "handle_center_minimum",
                "handle_center_maximum",
            ),
            description="Realized body-relative handle center after complete-root fit limits.",
            unit="m",
        ),
    ),
    constraints=(
        Constraint(
            name="ordinary-body-aspect-envelope",
            predicate=lambda p: 0.48 <= p["body_height"] / p["rim_diameter"] <= 1.50,
            message=(
                "Independent rim diameter and body height must stay within ordinary teacup-to-mug "
                "aspect limits."
            ),
        ),
        Constraint(
            name="handle-fit-cap-remains-positive",
            predicate=lambda p: p["handle_opening_height_cap"] >= 0.012,
            message="The body must leave positive space for the handle opening and both roots.",
        ),
        Constraint(
            name="handle-center-fit-interval-is-ordered",
            predicate=lambda p: p["handle_center_minimum"] <= p["handle_center_maximum"] + 1e-12,
            message="The complete handle footprint must fit between inner floor and rim.",
        ),
    ),
    population_checks=(
        PopulationCheck(
            name="covers-common-wall-paths",
            predicate=lambda samples: _covers_choice(samples, "wall_path", {"linear", "rounded"}),
            message="Validation must exercise both common straight-taper and rounded wall paths.",
        ),
        PopulationCheck(
            name="covers-common-handle-outlines",
            predicate=lambda samples: _covers_choice(
                samples, "handle_outline", {"oval", "flat_sided"}
            ),
            message="Validation must exercise oval C-loops and flatter-sided plain D-like loops.",
        ),
        _bounds_check(
            "covers-rim-diameter-envelope",
            "rim_diameter",
            0.065001,
            0.104999,
            "Validation must reach ordinary small and large household cup rim diameters.",
        ),
        _bounds_check(
            "covers-body-height-envelope",
            "body_height",
            0.050001,
            0.124999,
            "Validation must reach low teacup and tall mug body heights.",
        ),
        _bounds_check(
            "covers-base-diameter-ratio-envelope",
            "base_diameter_ratio",
            0.7201,
            0.9999,
            "Validation must reach strongly tapered and nearly cylindrical bodies.",
        ),
        _bounds_check(
            "covers-wall-thickness-envelope",
            "wall_thickness",
            0.002501,
            0.004999,
            "Validation must reach thin and thick ordinary vessel walls.",
        ),
        _bounds_check(
            "covers-handle-height-target-envelope",
            "handle_opening_height_target",
            0.018001,
            0.064999,
            "Validation must reach small teacup and large mug handle-height targets.",
        ),
        _bounds_check(
            "covers-independent-handle-depth-target-envelope",
            "handle_opening_depth_target",
            0.020001,
            0.049999,
            "Validation must reach the independent small and large handle-depth targets.",
        ),
        _bounds_check(
            "covers-handle-member-thickness-envelope",
            "handle_member_thickness",
            0.004501,
            0.009999,
            "Validation must reach fine and substantial handle member thicknesses.",
        ),
        _bounds_check(
            "covers-handle-axial-width-envelope",
            "handle_axial_width",
            0.006001,
            0.015999,
            "Validation must reach narrow and broad ordinary handle sections.",
        ),
    ),
    relationships=(
        RigidMount(
            name="handle-roots-mounted-to-cup-body",
            parent_part="cup",
            parent_element="cup_body",
            child_part="cup",
            child_element="handle",
        ),
    ),
    build=build_model,
    tests=run_tests,
    task_requirements=(
        "Every sample must have exactly one bounded open side-handle loop with no additional grip.",
        "Both separated roots of the sole handle must be permanently mounted to the cup body.",
        "The vessel cavity must remain genuinely open at the rim and empty above its inner floor.",
        "No sample may include a lid, saucer, decorative relief, or decorative add-on geometry.",
    ),
    tags=("mug", "teacup", "household cup", "single side handle", "open vessel"),
)
