from __future__ import annotations

import math
from typing import Any, Mapping, Sequence

from assetengine import (
    ActiveWhen,
    Constraint,
    Derived,
    GeneratorDesign,
    GeneratorSpec,
    PopulationCheck,
    RelativeUniformFloat,
    RigidMount,
    UniformChoice,
    UniformFloat,
    UniformInt,
)
from assetengine.articraft import (
    ArticulatedObject,
    Box,
    MeshGeometry,
    Origin,
    TestContext,
    mesh_from_geometry,
)


_BACK_FRAME_THICKNESS = 0.12
_BACK_CUSHION_THICKNESS = 0.14
_CUSHION_SEAM = 0.012
_LEG_SIZE = 0.065
_CONTACT_TOLERANCE = 1e-5
_PROFILE_SEGMENTS = 4


def _prism_between_rings(
    first: list[tuple[float, float, float]], second: list[tuple[float, float, float]]
) -> MeshGeometry:
    count = len(first)
    vertices = [*first, *second]
    first_center = tuple(sum(point[axis] for point in first) / count for axis in range(3))
    second_center = tuple(sum(point[axis] for point in second) / count for axis in range(3))
    first_center_index = len(vertices)
    vertices.append(first_center)
    second_center_index = len(vertices)
    vertices.append(second_center)
    faces: list[tuple[int, int, int]] = []
    for index in range(count):
        following = (index + 1) % count
        faces.append((index, following, count + following))
        faces.append((index, count + following, count + index))
        faces.append((first_center_index, following, index))
        faces.append((second_center_index, count + index, count + following))
    return MeshGeometry(vertices=vertices, faces=faces)


def _covers_choice(samples: Sequence[Mapping[str, Any]], factor: str, expected: set[Any]) -> bool:
    return expected.issubset({sample[factor] for sample in samples})


def _covers_bounds(
    samples: Sequence[Mapping[str, Any]],
    factor: str,
    *,
    minimum_at_most: float,
    maximum_at_least: float,
) -> bool:
    values = [float(sample[factor]) for sample in samples]
    return min(values) <= minimum_at_most and max(values) >= maximum_at_least


def _choice_check(name: str, factor: str, expected: set[Any], message: str) -> PopulationCheck:
    return PopulationCheck(
        name=name,
        predicate=lambda samples: _covers_choice(samples, factor, expected),
        message=message,
    )


def _bounds_check(
    name: str,
    factor: str,
    minimum_at_most: float,
    maximum_at_least: float,
    message: str,
) -> PopulationCheck:
    return PopulationCheck(
        name=name,
        predicate=lambda samples: _covers_bounds(
            samples,
            factor,
            minimum_at_most=minimum_at_most,
            maximum_at_least=maximum_at_least,
        ),
        message=message,
    )


def _add_box(part, name: str, size: tuple[float, float, float], xyz: tuple[float, float, float]):
    part.visual(Box(size), origin=Origin(xyz=xyz), name=name)


def _rounded_profile(
    span: float,
    height: float,
    radius: float,
    *,
    center_span: float,
    bottom: float,
    shear: float = 0.0,
) -> list[tuple[float, float]]:
    radius = min(radius, 0.45 * span, 0.45 * height)
    points: list[tuple[float, float]] = []
    centers = (
        (0.5 * span - radius, bottom + height - radius, 0.0, 0.5 * math.pi),
        (-0.5 * span + radius, bottom + height - radius, 0.5 * math.pi, math.pi),
        (-0.5 * span + radius, bottom + radius, math.pi, 1.5 * math.pi),
        (0.5 * span - radius, bottom + radius, 1.5 * math.pi, 2.0 * math.pi),
    )
    for center_u, center_z, start, end in centers:
        for step in range(_PROFILE_SEGMENTS + 1):
            angle = start + (end - start) * step / _PROFILE_SEGMENTS
            z = center_z + radius * math.sin(angle)
            u = center_u + radius * math.cos(angle)
            points.append((center_span + u + shear * (z - bottom), z))
    return points


def _add_rounded_x_cushion(
    part,
    name: str,
    *,
    width: float,
    depth: float,
    height: float,
    center_x: float,
    center_y: float,
    bottom: float,
    shear: float = 0.0,
):
    profile = _rounded_profile(
        depth,
        height,
        min(0.035, 0.22 * height),
        center_span=center_y,
        bottom=bottom,
        shear=shear,
    )
    rings = [
        [(-0.5 * width + center_x, y, z) for y, z in profile],
        [(0.5 * width + center_x, y, z) for y, z in profile],
    ]
    part.visual(mesh_from_geometry(_prism_between_rings(rings[0], rings[1]), name), name=name)


def _add_profiled_arm(
    part,
    name: str,
    *,
    profile: str,
    center_x: float,
    width: float,
    front_y: float,
    rear_y: float,
    bottom: float,
    top: float,
):
    if profile == "track":
        _add_box(
            part,
            name,
            (width, rear_y - front_y, top - bottom),
            (center_x, 0.5 * (front_y + rear_y), 0.5 * (top + bottom)),
        )
        return
    front_top = top - (0.10 if profile == "slope" else 0.0)
    front_profile = _rounded_profile(
        width,
        front_top - bottom,
        min(0.045, 0.22 * width),
        center_span=center_x,
        bottom=bottom,
    )
    rear_profile = _rounded_profile(
        width,
        top - bottom,
        min(0.045, 0.22 * width),
        center_span=center_x,
        bottom=bottom,
    )
    rings = [
        [(x, front_y, z) for x, z in front_profile],
        [(x, rear_y, z) for x, z in rear_profile],
    ]
    part.visual(mesh_from_geometry(_prism_between_rings(rings[1], rings[0]), name), name=name)


def _add_rounded_y_member(
    part,
    name: str,
    *,
    depth: float,
    width: float,
    height: float,
    center_x: float,
    center_y: float,
    bottom: float,
):
    profile = _rounded_profile(
        width,
        height,
        min(0.035, 0.22 * width),
        center_span=center_x,
        bottom=bottom,
    )
    rings = [
        [(x, center_y - 0.5 * depth, z) for x, z in profile],
        [(x, center_y + 0.5 * depth, z) for x, z in profile],
    ]
    part.visual(mesh_from_geometry(_prism_between_rings(rings[1], rings[0]), name), name=name)


def build_model(parameters: Mapping[str, Any]):
    p = parameters
    model = ArticulatedObject(name="sofa")
    sofa = model.part("sofa")

    width = float(p["overall_width"])
    depth = float(p["overall_depth"])
    seat_height = float(p["seat_height"])
    cushion_thickness = float(p["seat_cushion_thickness"])
    leg_height = float(p["leg_height"])
    base_height = float(p["base_frame_height"])
    base_top = leg_height + base_height
    arm_width = float(p["arm_width"])
    arm_height = float(p["arm_height"])
    module_width = float(p["seat_module_width"])
    seat_depth = float(p["usable_seat_depth"])
    seat_count = int(p["seat_count"])
    overall_height = float(p["overall_height"])

    _add_box(
        sofa,
        "base_frame",
        (width, depth, base_height),
        (0.0, 0.0, leg_height + 0.5 * base_height),
    )
    leg_x = 0.5 * width - 0.5 * arm_width
    leg_y = 0.5 * depth - _BACK_FRAME_THICKNESS - 0.5 * _LEG_SIZE
    for name, x, y in (
        ("front_left_leg", -leg_x, -leg_y),
        ("front_right_leg", leg_x, -leg_y),
        ("rear_left_leg", -leg_x, leg_y),
        ("rear_right_leg", leg_x, leg_y),
    ):
        _add_box(sofa, name, (_LEG_SIZE, _LEG_SIZE, leg_height), (x, y, 0.5 * leg_height))

    back_frame_height = overall_height - base_top
    back_shear = math.tan(math.radians(float(p["back_rake_degrees"])))
    back_root_center_y = 0.5 * depth - 0.5 * _BACK_FRAME_THICKNESS - back_shear * back_frame_height
    _add_rounded_x_cushion(
        sofa,
        "back_frame",
        width=width,
        depth=_BACK_FRAME_THICKNESS,
        height=back_frame_height,
        center_x=0.0,
        center_y=back_root_center_y,
        bottom=base_top,
        shear=back_shear,
    )

    arm_depth = depth - _BACK_FRAME_THICKNESS
    arm_body_height = arm_height - base_top
    for name, x in (
        ("left_arm", -0.5 * width + 0.5 * arm_width),
        ("right_arm", 0.5 * width - 0.5 * arm_width),
    ):
        if p["layout"] == "corner" and (
            (name == "left_arm" and p["chaise_side"] == "left")
            or (name == "right_arm" and p["chaise_side"] == "right")
        ):
            continue
        _add_profiled_arm(
            sofa,
            name,
            profile=str(p["arm_profile"]),
            center_x=x,
            width=arm_width,
            front_y=-0.5 * depth,
            rear_y=0.5 * depth - _BACK_FRAME_THICKNESS,
            bottom=base_top,
            top=base_top + arm_body_height,
        )

    seat_rear = 0.5 * depth - _BACK_FRAME_THICKNESS - _BACK_CUSHION_THICKNESS
    seat_center_y = seat_rear - 0.5 * seat_depth
    inner_width = width - 2.0 * arm_width

    if p["layout"] == "straight":
        if p["seat_cushion_style"] == "bench":
            _add_rounded_x_cushion(
                sofa,
                "bench_seat_cushion",
                width=inner_width - _CUSHION_SEAM,
                depth=seat_depth,
                height=cushion_thickness,
                center_x=0.0,
                center_y=seat_center_y,
                bottom=base_top,
            )
        else:
            for index in range(seat_count):
                x = -0.5 * inner_width + (index + 0.5) * module_width
                _add_rounded_x_cushion(
                    sofa,
                    f"seat_cushion_{index}",
                    width=module_width - _CUSHION_SEAM,
                    depth=seat_depth,
                    height=cushion_thickness,
                    center_x=x,
                    center_y=seat_center_y,
                    bottom=base_top,
                )
    else:
        chaise_depth = float(p["chaise_overall_depth"])
        side_sign = -1.0 if p["chaise_side"] == "left" else 1.0
        chaise_index = 0 if side_sign < 0.0 else seat_count - 1
        chaise_x = -0.5 * inner_width + (chaise_index + 0.5) * module_width
        standard_centers = [
            -0.5 * inner_width + (index + 0.5) * module_width
            for index in range(seat_count)
            if index != chaise_index
        ]
        if p["seat_cushion_style"] == "bench":
            standard_width = inner_width - module_width
            standard_center_x = -0.5 * side_sign * module_width
            _add_rounded_x_cushion(
                sofa,
                "bench_seat_cushion",
                width=standard_width - _CUSHION_SEAM,
                depth=seat_depth,
                height=cushion_thickness,
                center_x=standard_center_x,
                center_y=seat_center_y,
                bottom=base_top,
            )
        else:
            for index, x in enumerate(standard_centers):
                _add_rounded_x_cushion(
                    sofa,
                    f"standard_seat_cushion_{index}",
                    width=module_width - _CUSHION_SEAM,
                    depth=seat_depth,
                    height=cushion_thickness,
                    center_x=x,
                    center_y=seat_center_y,
                    bottom=base_top,
                )
        chaise_cushion_depth = chaise_depth - (_BACK_FRAME_THICKNESS + _BACK_CUSHION_THICKNESS)
        chaise_cushion_width = module_width - _CUSHION_SEAM
        chaise_cushion_x = chaise_x
        if p["layout"] == "corner":
            chaise_cushion_width -= _BACK_FRAME_THICKNESS
            chaise_cushion_x -= 0.5 * side_sign * _BACK_FRAME_THICKNESS
        _add_rounded_x_cushion(
            sofa,
            "chaise_seat_cushion",
            width=chaise_cushion_width,
            depth=chaise_cushion_depth,
            height=cushion_thickness,
            center_x=chaise_cushion_x,
            center_y=seat_rear - 0.5 * chaise_cushion_depth,
            bottom=base_top,
        )

    back_cushion_height = overall_height - seat_height
    back_cushion_y = (
        back_root_center_y
        - 0.5 * _BACK_FRAME_THICKNESS
        - 0.5 * _BACK_CUSHION_THICKNESS
        + back_shear * (seat_height - base_top)
    )
    if p["back_cushion_style"] == "continuous":
        _add_rounded_x_cushion(
            sofa,
            "continuous_back_cushion",
            width=inner_width - _CUSHION_SEAM,
            depth=_BACK_CUSHION_THICKNESS,
            height=back_cushion_height,
            center_x=0.0,
            center_y=back_cushion_y,
            bottom=seat_height,
            shear=back_shear,
        )
    else:
        for index in range(seat_count):
            x = -0.5 * inner_width + (index + 0.5) * module_width
            _add_rounded_x_cushion(
                sofa,
                f"back_cushion_{index}",
                width=module_width - _CUSHION_SEAM,
                depth=_BACK_CUSHION_THICKNESS,
                height=back_cushion_height,
                center_x=x,
                center_y=back_cushion_y,
                bottom=seat_height,
                shear=back_shear,
            )

    if p["layout"] in ("chaise", "corner"):
        chaise_depth = float(p["chaise_overall_depth"])
        extension_depth = chaise_depth - depth
        side_sign = -1.0 if p["chaise_side"] == "left" else 1.0
        chaise_x = side_sign * (0.5 * inner_width - 0.5 * module_width)
        main_base_front = -0.5 * depth
        extension_center_y = main_base_front - 0.5 * extension_depth
        _add_box(
            sofa,
            "chaise_base_extension",
            (module_width, extension_depth, base_height),
            (chaise_x, extension_center_y, leg_height + 0.5 * base_height),
        )
        chaise_front_y = -chaise_depth + 0.5 * depth + 0.5 * _LEG_SIZE
        for name, x_offset in (
            ("chaise_front_inner_leg", -0.28 * module_width),
            ("chaise_front_outer_leg", 0.28 * module_width),
        ):
            _add_box(
                sofa,
                name,
                (_LEG_SIZE, _LEG_SIZE, leg_height),
                (chaise_x + x_offset, chaise_front_y, 0.5 * leg_height),
            )
        if p["layout"] == "corner":
            outer_x = side_sign * (0.5 * inner_width - 0.5 * _BACK_FRAME_THICKNESS)
            return_back_depth = chaise_depth - _BACK_FRAME_THICKNESS
            _add_rounded_y_member(
                sofa,
                "corner_return_back",
                depth=return_back_depth,
                width=_BACK_FRAME_THICKNESS,
                height=overall_height - base_top,
                center_x=outer_x,
                center_y=0.5 * depth - 0.5 * (chaise_depth + _BACK_FRAME_THICKNESS),
                bottom=base_top,
            )

    return model


def run_tests(model: ArticulatedObject, parameters: Mapping[str, Any]):
    p = parameters
    ctx = TestContext(model)
    ctx.check_model_valid()
    ctx.check(
        "derived-width-matches-active-seat-count-envelope",
        abs(float(p["overall_width"]) - float(p[f"width_{p['seat_count']}_seat"])) <= 1e-9,
    )
    ctx.check(
        "seat-modules-fill-space-between-arms",
        abs(
            float(p["seat_module_width"]) * int(p["seat_count"])
            - (float(p["overall_width"]) - 2.0 * float(p["arm_width"]))
        )
        <= 1e-9,
    )
    ctx.check(
        "base-retains-positive-structural-height",
        float(p["base_frame_height"]) >= 0.06,
    )
    ctx.check(
        "seat-cushion-fits-in-front-of-back-cushion",
        float(p["usable_seat_depth"])
        <= float(p["overall_depth"]) - _BACK_FRAME_THICKNESS - _BACK_CUSHION_THICKNESS,
    )
    ctx.check(
        "back-and-arms-rise-above-seat-frame",
        float(p["overall_height"]) > float(p["seat_height"])
        and float(p["arm_height"]) > float(p["base_frame_top"]),
    )
    if p["layout"] == "chaise":
        ctx.check(
            "chaise-projects-beyond-standard-front",
            float(p["chaise_overall_depth"]) >= float(p["overall_depth"]) + 0.35,
        )
    return ctx.report()


def _active(values: tuple[Any, ...], *, factor: str) -> tuple[ActiveWhen, ...]:
    return (ActiveWhen(factor=factor, values=values),)


_RELATIONSHIPS = [
    RigidMount(
        name="back-frame-mounted-to-base-frame",
        parent_part="sofa",
        parent_element="base_frame",
        child_part="sofa",
        child_element="back_frame",
        contact_tolerance=_CONTACT_TOLERANCE,
    ),
    RigidMount(
        name="left-arm-mounted-to-base-frame",
        parent_part="sofa",
        parent_element="base_frame",
        child_part="sofa",
        child_element="left_arm",
        contact_tolerance=_CONTACT_TOLERANCE,
        active_when=_active(("straight", "chaise"), factor="layout"),
    ),
    RigidMount(
        name="right-arm-mounted-to-base-frame",
        parent_part="sofa",
        parent_element="base_frame",
        child_part="sofa",
        child_element="right_arm",
        contact_tolerance=_CONTACT_TOLERANCE,
        active_when=_active(("straight", "chaise"), factor="layout"),
    ),
]

for _arm_name, _opposite_side in (("left_arm", "right"), ("right_arm", "left")):
    _RELATIONSHIPS.append(
        RigidMount(
            name=f"corner-{_arm_name.replace('_', '-')}-mounted-to-base-frame",
            parent_part="sofa",
            parent_element="base_frame",
            child_part="sofa",
            child_element=_arm_name,
            contact_tolerance=_CONTACT_TOLERANCE,
            active_when=(
                ActiveWhen(factor="layout", values=("corner",)),
                ActiveWhen(factor="chaise_side", values=(_opposite_side,)),
            ),
        )
    )

for _leg_name in ("front_left_leg", "front_right_leg"):
    _RELATIONSHIPS.append(
        RigidMount(
            name=f"{_leg_name.replace('_', '-')}-mounted-to-base-frame",
            parent_part="sofa",
            parent_element="base_frame",
            child_part="sofa",
            child_element=_leg_name,
            contact_tolerance=_CONTACT_TOLERANCE,
        )
    )

_RELATIONSHIPS.append(
    RigidMount(
        name="bench-seat-cushion-mounted-to-base-frame",
        parent_part="sofa",
        parent_element="base_frame",
        child_part="sofa",
        child_element="bench_seat_cushion",
        contact_tolerance=_CONTACT_TOLERANCE,
        active_when=_active(("bench",), factor="seat_cushion_style"),
    )
)

for _index in range(4):
    _seat_counts = tuple(range(max(2, _index + 1), 5))
    _RELATIONSHIPS.append(
        RigidMount(
            name=f"seat-cushion-{_index}-mounted-to-base-frame",
            parent_part="sofa",
            parent_element="base_frame",
            child_part="sofa",
            child_element=f"seat_cushion_{_index}",
            contact_tolerance=_CONTACT_TOLERANCE,
            active_when=(
                ActiveWhen(factor="layout", values=("straight",)),
                ActiveWhen(factor="seat_cushion_style", values=("divided",)),
                ActiveWhen(factor="seat_count", values=_seat_counts),
            ),
        )
    )

for _index in range(3):
    _seat_counts = tuple(range(max(2, _index + 2), 5))
    _RELATIONSHIPS.append(
        RigidMount(
            name=f"standard-seat-cushion-{_index}-mounted-to-base-frame",
            parent_part="sofa",
            parent_element="base_frame",
            child_part="sofa",
            child_element=f"standard_seat_cushion_{_index}",
            contact_tolerance=_CONTACT_TOLERANCE,
            active_when=(
                ActiveWhen(factor="layout", values=("chaise", "corner")),
                ActiveWhen(factor="seat_cushion_style", values=("divided",)),
                ActiveWhen(factor="seat_count", values=_seat_counts),
            ),
        )
    )

_RELATIONSHIPS.append(
    RigidMount(
        name="continuous-back-cushion-mounted-to-back-frame",
        parent_part="sofa",
        parent_element="back_frame",
        child_part="sofa",
        child_element="continuous_back_cushion",
        contact_tolerance=_CONTACT_TOLERANCE,
        active_when=_active(("continuous",), factor="back_cushion_style"),
    )
)

for _index in range(4):
    _seat_counts = tuple(range(max(2, _index + 1), 5))
    _RELATIONSHIPS.append(
        RigidMount(
            name=f"back-cushion-{_index}-mounted-to-back-frame",
            parent_part="sofa",
            parent_element="back_frame",
            child_part="sofa",
            child_element=f"back_cushion_{_index}",
            contact_tolerance=_CONTACT_TOLERANCE,
            active_when=(
                ActiveWhen(factor="back_cushion_style", values=("divided",)),
                ActiveWhen(factor="seat_count", values=_seat_counts),
            ),
        )
    )

for _name, _parent, _child in (
    ("chaise-base-extension-mounted-to-base-frame", "base_frame", "chaise_base_extension"),
    (
        "chaise-seat-cushion-mounted-to-base-frame",
        "base_frame",
        "chaise_seat_cushion",
    ),
    (
        "chaise-seat-cushion-mounted-to-chaise-base",
        "chaise_base_extension",
        "chaise_seat_cushion",
    ),
    (
        "chaise-front-inner-leg-mounted-to-chaise-base",
        "chaise_base_extension",
        "chaise_front_inner_leg",
    ),
    (
        "chaise-front-outer-leg-mounted-to-chaise-base",
        "chaise_base_extension",
        "chaise_front_outer_leg",
    ),
):
    _RELATIONSHIPS.append(
        RigidMount(
            name=_name,
            parent_part="sofa",
            parent_element=_parent,
            child_part="sofa",
            child_element=_child,
            contact_tolerance=_CONTACT_TOLERANCE,
            active_when=_active(("chaise", "corner"), factor="layout"),
        )
    )

_RELATIONSHIPS.append(
    RigidMount(
        name="corner-return-back-mounted-to-return-base",
        parent_part="sofa",
        parent_element="chaise_base_extension",
        child_part="sofa",
        child_element="corner_return_back",
        contact_tolerance=_CONTACT_TOLERANCE,
        active_when=_active(("corner",), factor="layout"),
    )
)


GENERATOR = GeneratorSpec(
    name="sofa",
    category="sofa",
    description="Procedural upholstered sofas spanning straight, chaise, and full-return corner layouts, two through four seats, softened cushion and arm profiles, and ordinary residential proportions.",
    design=GeneratorDesign(
        coverage="Ordinary residential upholstered sofas include straight 2-seat loveseats through 4-seat sofas, common left/right one-sided chaise layouts, and left/right full-return L/corner sectionals with a back along the return. Conditional outside-width envelopes are 1.35-1.85 m for 2 seats, 1.80-2.55 m for 3 seats, and 2.40-3.10 m for 4 seats; ordinary standard depth is 0.86-1.08 m and chaise/return depth is 1.45-2.15 m. Divided and bench seats, divided and continuous backs, and track, rounded, and sloped arms are included. Sleeper/recliner mechanisms, U sectionals, armless modular runs, exposed wood frames, curved statement sofas, sofa beds, and decorative tufting are excluded.",
        factors="Seat count selects its observed outside-width envelope; arm width remains an independent 0.07-0.22 m construction choice subject to a 0.50 m minimum per-seat fit constraint, and seat-module width is derived exactly. Overall depth, seat height (0.40-0.53 m), cushion thickness (0.10-0.18 m), leg height (0.03-0.18 m), back rise (0.30-0.48 m), 0-12 degree back rake, arm profile, and return depth are ordinary controls. Usable seat depth moves with overall depth at 56-66% with 0.48-0.70 m bounds; arm height moves with seat height and is bounded to 0.54-0.72 m. A named residual constraint prevents the longest return on the narrowest layouts. All stochastic factors are uniform.",
        components="The base/frame varies in width, depth, height, clearance, and seat count. Arms vary in width, height, and genuinely distinct flat-track, rounded, and front-low sloped profiles. Seat and back cushions vary independently between continuous and divided topology and use coherent softened cross-sections; the back varies from upright to modest rear rake. A chaise adds a supported lounge cushion; a corner branch adds a full-depth return with an upholstered back along it. Four corner legs and two return-front legs preserve support; seam allowance and neutral upholstery remain fixed incidental details.",
        physics_and_task="The full-depth base frame is the root and gives the raked back frame a finite bottom mounting footprint. Both active arms, every active cushion, and four corner legs have declared local contact; chaise/corner extensions mount at the main base front, their full-length cushion is supported over both frames, and two front legs meet the extension underside. A corner return also seats its back over the return base. Exact derived coordinates preserve contact while profile rounding retains planar mounting bands. No moving mechanism or robot-specific clearance is inferred.",
    ),
    factors=(
        UniformChoice(
            name="layout",
            choices=("straight", "chaise", "corner"),
            description="Straight sofa, one-sided chaise, or full-return corner sectional.",
        ),
        UniformChoice(
            name="chaise_side",
            choices=("left", "right"),
            active_when=_active(("chaise", "corner"), factor="layout"),
            description="Viewer-facing side carrying the chaise or sectional return.",
        ),
        UniformInt(
            name="seat_count",
            low=2,
            high=4,
            description="Number of equal upholstered seating modules across the sofa width.",
            unit="count",
        ),
        UniformFloat(
            name="width_2_seat",
            low=1.35,
            high=1.85,
            active_when=_active((2,), factor="seat_count"),
            description="Overall outside width of an ordinary 2-seat sofa or chaise sofa.",
            unit="m",
        ),
        UniformFloat(
            name="width_3_seat",
            low=1.80,
            high=2.55,
            active_when=_active((3,), factor="seat_count"),
            description="Overall outside width of an ordinary 3-seat sofa or chaise sofa.",
            unit="m",
        ),
        UniformFloat(
            name="width_4_seat",
            low=2.40,
            high=3.10,
            active_when=_active((4,), factor="seat_count"),
            description="Overall outside width of an ordinary 4-seat sofa or chaise sofa.",
            unit="m",
        ),
        Derived(
            name="overall_width",
            derive=lambda p: p[f"width_{p['seat_count']}_seat"],
            depends_on=("seat_count", "width_2_seat", "width_3_seat", "width_4_seat"),
            description="Active seat-count-specific outside width from arm to arm.",
            unit="m",
        ),
        UniformFloat(
            name="overall_depth",
            low=0.86,
            high=1.08,
            description="Independent standard front-to-back depth, excluding a chaise extension.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="usable_seat_depth",
            reference="overall_depth",
            ratio_low=0.56,
            ratio_high=0.66,
            hard_min=0.48,
            hard_max=0.70,
            description="Usable cushion depth correlated with the sofa's standard overall depth.",
            unit="m",
        ),
        UniformFloat(
            name="seat_height",
            low=0.40,
            high=0.53,
            description="Independent floor-to-top-of-seat-cushion height.",
            unit="m",
        ),
        UniformFloat(
            name="seat_cushion_thickness",
            low=0.10,
            high=0.18,
            description="Visible vertical thickness of the upholstered seat cushion.",
            unit="m",
        ),
        UniformFloat(
            name="leg_height",
            low=0.03,
            high=0.18,
            description="Independent visible floor clearance carried by the legs.",
            unit="m",
        ),
        Derived(
            name="base_frame_height",
            derive=lambda p: p["seat_height"] - p["seat_cushion_thickness"] - p["leg_height"],
            depends_on=("seat_height", "seat_cushion_thickness", "leg_height"),
            description="Structural base height below the seat cushion and above the legs.",
            unit="m",
        ),
        Derived(
            name="base_frame_top",
            derive=lambda p: p["leg_height"] + p["base_frame_height"],
            depends_on=("leg_height", "base_frame_height"),
            description="Exact top elevation of the structural base frame.",
            unit="m",
        ),
        UniformFloat(
            name="arm_width",
            low=0.07,
            high=0.22,
            description="Independent transverse width of each upholstered track arm.",
            unit="m",
        ),
        UniformChoice(
            name="arm_profile",
            choices=("track", "rounded", "slope"),
            description="Flat track, softly rounded, or front-low sloped upholstered arm profile.",
        ),
        Derived(
            name="seat_module_width",
            derive=lambda p: (p["overall_width"] - 2.0 * p["arm_width"]) / p["seat_count"],
            depends_on=("overall_width", "arm_width", "seat_count"),
            description="Exact equal module width remaining between both arms.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="arm_height",
            reference="seat_height",
            ratio_low=1.08,
            ratio_high=1.36,
            offset=0.08,
            hard_min=0.54,
            hard_max=0.72,
            description="Floor-to-arm-top height whose ordinary band shifts with seat height.",
            unit="m",
        ),
        UniformFloat(
            name="back_rise_above_seat",
            low=0.30,
            high=0.48,
            description="Independent vertical backrest rise above the seat cushion surface.",
            unit="m",
        ),
        UniformFloat(
            name="back_rake_degrees",
            low=0.0,
            high=12.0,
            description="Rearward shear of the back frame and cushions from near-upright to modest rake.",
            unit="deg",
        ),
        Derived(
            name="overall_height",
            derive=lambda p: p["seat_height"] + p["back_rise_above_seat"],
            depends_on=("seat_height", "back_rise_above_seat"),
            description="Floor-to-back-top height derived from seat height and back rise.",
            unit="m",
        ),
        UniformChoice(
            name="seat_cushion_style",
            choices=("bench", "divided"),
            description="One continuous bench cushion or one cushion per seat module.",
        ),
        UniformChoice(
            name="back_cushion_style",
            choices=("continuous", "divided"),
            description="One continuous upholstered back cushion or one cushion per seat module.",
        ),
        UniformFloat(
            name="chaise_overall_depth",
            low=1.45,
            high=2.15,
            active_when=_active(("chaise", "corner"), factor="layout"),
            description="Overall rear-to-front depth of the active chaise or sectional return.",
            unit="m",
        ),
    ),
    constraints=(
        Constraint(
            name="seat-module-retains-ordinary-width",
            predicate=lambda p: p["seat_module_width"] >= 0.50,
            message="Arm widths must leave at least 0.50 m for every seating module.",
        ),
        Constraint(
            name="base-frame-retains-structure",
            predicate=lambda p: p["base_frame_height"] >= 0.06,
            message="Seat height, cushion thickness, and leg clearance must leave 0.06 m of base.",
        ),
        Constraint(
            name="seat-depth-fits-standard-body",
            predicate=lambda p: (
                p["usable_seat_depth"]
                <= p["overall_depth"] - _BACK_FRAME_THICKNESS - _BACK_CUSHION_THICKNESS
            ),
            message="Usable seat depth must remain in front of the back cushion and frame.",
        ),
        Constraint(
            name="arm-rises-above-base-frame",
            predicate=lambda p: p["arm_height"] > p["base_frame_top"] + 0.04,
            message="Track arms must visibly rise above the structural base frame.",
        ),
        Constraint(
            name="chaise-projects-beyond-standard-body",
            predicate=lambda p: (
                p["layout"] == "straight" or p["chaise_overall_depth"] >= p["overall_depth"] + 0.35
            ),
            message="A chaise or return must project at least 0.35 m beyond the standard front.",
        ),
        Constraint(
            name="compact-layout-avoids-extra-long-return",
            predicate=lambda p: (
                p["layout"] == "straight" or p["chaise_overall_depth"] <= p["overall_width"] + 0.65
            ),
            message="Compact chaise and corner widths must not pair with the longest return depth.",
        ),
    ),
    relationships=tuple(_RELATIONSHIPS),
    build=build_model,
    tests=run_tests,
    population_checks=(
        _choice_check(
            "covers-common-layouts",
            "layout",
            {"straight", "chaise", "corner"},
            "Validation must exercise straight, chaise, and full-return corner topologies.",
        ),
        _choice_check(
            "covers-chaise-sides",
            "chaise_side",
            {"left", "right"},
            "Validation must exercise left and right chaise placement.",
        ),
        _choice_check(
            "covers-seat-counts",
            "seat_count",
            {2, 3, 4},
            "Validation must exercise 2-, 3-, and 4-seat widths.",
        ),
        _choice_check(
            "covers-seat-cushion-constructions",
            "seat_cushion_style",
            {"bench", "divided"},
            "Validation must exercise bench and divided seat cushions.",
        ),
        _choice_check(
            "covers-back-cushion-constructions",
            "back_cushion_style",
            {"continuous", "divided"},
            "Validation must exercise continuous and divided back cushions.",
        ),
        _bounds_check(
            "covers-overall-depth-envelope",
            "overall_depth",
            0.861,
            1.079,
            "Validation must reach the ordinary 0.86-1.08 m overall-depth envelope.",
        ),
        _bounds_check(
            "covers-seat-height-envelope",
            "seat_height",
            0.401,
            0.529,
            "Validation must reach low and high ordinary sofa seat heights.",
        ),
        _bounds_check(
            "covers-chaise-depth-envelope",
            "chaise_overall_depth",
            1.451,
            2.149,
            "Validation must reach compact and long ordinary chaise depths.",
        ),
    ),
    task_requirements=(),
    tags=("sofa", "upholstered seating", "chaise", "living room furniture"),
)
