from __future__ import annotations

import math
from typing import Any, Mapping, Sequence

from assetengine import (
    ActiveWhen,
    Derived,
    GeneratorDesign,
    GeneratorSpec,
    PopulationCheck,
    RelativeUniformFloat,
    RigidMount,
    UniformChoice,
    UniformFloat,
)
from assetengine.articraft import (
    ArticulatedObject,
    ArticulationType,
    CylinderGeometry,
    LatheGeometry,
    Origin,
    TestContext,
    mesh_from_geometry,
)


def _smoothstep(value: float) -> float:
    value = max(0.0, min(1.0, value))
    return value * value * (3.0 - 2.0 * value)


def _transition_fraction(family: str, value: float) -> float:
    """Smooth shoulder families with horizontal tangents at both ends."""
    shaped = value**0.78 if family == "rounded_short" else value**1.45
    return _smoothstep(shaped)


def _shoulder_profile(
    *,
    family: str,
    body_radius: float,
    neck_radius: float,
    shoulder_start: float,
    shoulder_height: float,
    radial_inset: float,
    samples: int = 13,
) -> list[tuple[float, float]]:
    points: list[tuple[float, float]] = []
    start_radius = body_radius - radial_inset
    end_radius = neck_radius - radial_inset
    for index in range(samples):
        fraction = index / (samples - 1)
        blend = _transition_fraction(family, fraction)
        radius = start_radius + (end_radius - start_radius) * blend
        points.append((radius, shoulder_start + shoulder_height * fraction))
    return points


def _body_fraction_radius(
    outline: str, fraction: float, body_radius: float, outline_amount: float
) -> float:
    blend = _smoothstep(fraction)
    if outline == "gentle_taper":
        return body_radius * (1.0 - outline_amount * blend)
    if outline == "waisted":
        return body_radius * (1.0 - outline_amount * math.sin(math.pi * fraction) ** 2)
    return body_radius


def _bottle_shell(parameters: Mapping[str, Any]) -> LatheGeometry:
    family = str(parameters["profile_family"])
    outline = str(parameters["body_outline"])
    outline_amount = float(parameters["outline_amount"])
    body_radius = float(parameters["body_diameter"]) / 2.0
    body_height = float(parameters["body_height"])
    neck_radius = float(parameters["neck_outer_diameter"]) / 2.0
    neck_height = float(parameters["neck_height"])
    shoulder_height = float(parameters["shoulder_height"])
    opening_radius = float(parameters["opening_diameter"]) / 2.0
    wall = float(parameters["body_wall_thickness"])
    finish_height = float(parameters["finish_height"])
    finish_bulge = float(parameters["finish_bulge"])

    base_curve_height = 0.085 * 2.0 * body_radius
    shoulder_start = body_height - shoulder_height
    total_height = body_height + neck_height
    finish_start = total_height - finish_height

    shoulder_radius = _body_fraction_radius(outline, 1.0, body_radius, outline_amount)
    outer: list[tuple[float, float]] = [
        (0.0, min(0.45 * max(1.35 * wall, 0.55 * base_curve_height), 0.35 * base_curve_height))
    ]
    for index in range(5):
        fraction = index / 4.0
        radius = body_radius * (0.92 + 0.08 * _smoothstep(fraction))
        outer.append((radius, base_curve_height * fraction))
    for index in range(1, 7):
        fraction = index / 6.0
        radius = _body_fraction_radius(outline, fraction, body_radius, outline_amount)
        outer.append((radius, base_curve_height + (shoulder_start - base_curve_height) * fraction))
    outer.extend(
        _shoulder_profile(
            family=family,
            body_radius=shoulder_radius,
            neck_radius=neck_radius,
            shoulder_start=shoulder_start,
            shoulder_height=shoulder_height,
            radial_inset=0.0,
        )[1:]
    )
    outer.append((neck_radius, finish_start))
    for index in range(1, 6):
        fraction = index / 5.0
        bulge = finish_bulge * math.sin(math.pi * fraction) ** 2
        outer.append((neck_radius + bulge, finish_start + finish_height * fraction))

    inner_bottom_z = max(1.35 * wall, 0.55 * base_curve_height)
    inner_body_radius = body_radius - wall
    inner: list[tuple[float, float]] = [
        (0.0, inner_bottom_z),
        (inner_body_radius, base_curve_height + 0.55 * wall),
    ]
    for index in range(1, 7):
        fraction = index / 6.0
        radius = _body_fraction_radius(outline, fraction, body_radius, outline_amount) - wall
        inner.append((radius, base_curve_height + (shoulder_start - base_curve_height) * fraction))
    inner.extend(
        _shoulder_profile(
            family=family,
            body_radius=shoulder_radius,
            neck_radius=opening_radius,
            shoulder_start=shoulder_start,
            shoulder_height=shoulder_height,
            radial_inset=wall,
        )[1:]
    )
    inner.append((opening_radius, total_height))

    return LatheGeometry.from_shell_profiles(
        outer,
        inner,
        segments=72,
        start_cap="flat",
        end_cap="flat",
        lip_samples=9,
    )


def build_model(parameters: Mapping[str, Any]) -> ArticulatedObject:
    model = ArticulatedObject(name="bottle")
    bottle = model.part("bottle")
    bottle.visual(
        mesh_from_geometry(_bottle_shell(parameters), "bottle_shell"),
        origin=Origin(),
        name="shell",
    )
    if parameters["closure_state"] == "capped":
        neck_radius = float(parameters["neck_outer_diameter"]) / 2.0
        cap_height = float(parameters["cap_height"])
        cap_radius = neck_radius * (1.0 + float(parameters["cap_overhang_ratio"]))
        closure = model.part("closure")
        closure.visual(
            mesh_from_geometry(
                CylinderGeometry(
                    radius=cap_radius, height=cap_height, radial_segments=72
                ).translate(0.0, 0.0, cap_height / 2.0),
                "bottle_cap",
            ),
            origin=Origin(),
            name="cap",
        )
        model.articulation(
            "bottle_to_cap",
            ArticulationType.FIXED,
            parent=bottle,
            child=closure,
            origin=Origin(
                xyz=(
                    0.0,
                    0.0,
                    float(parameters["body_height"]) + float(parameters["neck_height"]),
                )
            ),
        )
    return model


def run_tests(model: ArticulatedObject, parameters: Mapping[str, Any]):
    ctx = TestContext(model)
    ctx.check(
        "shoulder-below-neck",
        float(parameters["shoulder_height"]) < float(parameters["body_height"]),
    )
    ctx.check(
        "opening-inside-neck",
        float(parameters["opening_diameter"]) < float(parameters["neck_outer_diameter"]),
    )
    ctx.check(
        "cavity-clears-bottom",
        1.35 * float(parameters["body_wall_thickness"]) < float(parameters["body_height"]),
    )
    return ctx.report()


def _choice_coverage(samples: Sequence[Mapping[str, Any]], factor: str, choices: set[str]) -> bool:
    return choices.issubset({str(sample[factor]) for sample in samples})


def _conditional_bounds(
    samples: Sequence[Mapping[str, Any]],
    *,
    family: str,
    factor: str,
    low_ratio: float,
    high_ratio: float,
    reference: str = "body_diameter",
) -> bool:
    selected = [sample for sample in samples if sample["profile_family"] == family]
    if not selected:
        return False
    ratios = [float(sample[factor]) / float(sample[reference]) for sample in selected]
    span = high_ratio - low_ratio
    return min(ratios) <= low_ratio + 0.52 * span and max(ratios) >= high_ratio - 0.52 * span


GENERATOR = GeneratorSpec(
    name="bottle",
    category="bottle",
    description=(
        "An ordinary freestanding, round, narrow-neck bottle with a real hollow cavity "
        "and open mouth."
    ),
    design=GeneratorDesign(
        coverage=(
            "Covers compact rounded-shoulder and taller gradually tapered ordinary bottles, "
            "each with straight cylindrical, gently tapered, or waisted round body outlines. "
            "Body diameter spans 55-100 mm; conditional body height spans 2.0-3.0 diameters "
            "for compact forms and 2.6-3.4 diameters for tall forms. Every vessel has a narrow "
            "neck, hollow interior, stable annular base, shoulder, finish bead, and real mouth; "
            "half the uniform population carries a seated cap while plausible uncapped bottles "
            "retain an exposed opening. Excludes "
            "handled jugs, squeeze-spout packages, laboratory bottles, miniature vials, "
            "oversized carboys, decorative asymmetry, and uncommon sculptural or flat-sided "
            "packages."
        ),
        factors=(
            "Body diameter is an independent 55-100 mm size target. Body outline is an "
            "independent common construction choice; taper or waist depth varies 6-14 percent. "
            "Body height, shoulder "
            "height, neck diameter, and neck height have family-specific diameter-relative "
            "envelopes because their ordinary bands shift materially with bottle scale and "
            "silhouette: compact 2.0-3.0D bodies, 0.30-0.62D shoulders, 0.36-0.56D necks, "
            "and 0.28-0.50D neck heights; tall 2.6-3.4D bodies, 0.48-0.82D shoulders, "
            "0.30-0.40D necks, and 0.42-0.70D neck heights. Opening/neck ratio is conditional "
            "(0.62-0.84 compact, 0.60-0.72 tall). Wall thickness scales weakly with body "
            "diameter within 1.2-4.5 mm construction bounds. Finish height scales with neck "
            "diameter; its small radial prominence is independently variable."
        ),
        components=(
            "One coherent lathed shell varies the base roll, straight, tapered, or waisted "
            "body, continuously "
            "tangent shoulder, neck, finish bead, annular rim, internal shoulder, and bottom "
            "cavity. A closure branch adds a recognizable cylindrical cap seated across the "
            "annular neck rim. Dense profile sampling makes the outer and inner surfaces read "
            "as one continuous vessel rather than stacked primitives. Thread helices, mold seams, "
            "punt details, labels, and texture are incidental and omitted."
        ),
        physics_and_task=(
            "The vessel is a single watertight rigid shell with a closed material bottom but "
            "genuine cavity reached through the shell mouth. Its lowest annular base is level "
            "for ordinary upright support. The optional cap is a fixed child seated at the "
            "complete rim footprint; uncapped cases remain open. There is no user-specified "
            "manipulation, strength, or clearance requirement."
        ),
    ),
    factors=(
        UniformChoice(
            name="profile_family",
            choices=("rounded_short", "tapered_tall"),
            description="Distinct ordinary shoulder and height regimes.",
        ),
        UniformChoice(
            name="body_outline",
            choices=("straight", "gentle_taper", "waisted"),
            description="Common round-body longitudinal outline construction.",
        ),
        UniformFloat(
            name="outline_amount",
            low=0.06,
            high=0.14,
            active_when=(ActiveWhen(factor="body_outline", values=("gentle_taper", "waisted")),),
            description="Fractional radius change for tapered or waisted outlines.",
            unit="ratio",
        ),
        UniformChoice(
            name="closure_state",
            choices=("open", "capped"),
            description="Whether the ordinary bottle is shown open or with its closure seated.",
        ),
        UniformFloat(
            name="body_diameter",
            low=0.055,
            high=0.100,
            description="Maximum circular body diameter.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="compact_body_height",
            reference="body_diameter",
            ratio_low=2.0,
            ratio_high=3.0,
            active_when=(ActiveWhen(factor="profile_family", values=("rounded_short",)),),
            description="Base-to-neck body height for the compact family.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="tall_body_height",
            reference="body_diameter",
            ratio_low=2.6,
            ratio_high=3.4,
            active_when=(ActiveWhen(factor="profile_family", values=("tapered_tall",)),),
            description="Base-to-neck body height for the tall family.",
            unit="m",
        ),
        Derived(
            name="body_height",
            derive=lambda p: p[
                "compact_body_height"
                if p["profile_family"] == "rounded_short"
                else "tall_body_height"
            ],
            depends_on=("profile_family", "compact_body_height", "tall_body_height"),
            description="Active family's base-to-neck body height.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="compact_shoulder_height",
            reference="body_diameter",
            ratio_low=0.30,
            ratio_high=0.62,
            active_when=(ActiveWhen(factor="profile_family", values=("rounded_short",)),),
            description="Rounded-family shoulder transition height.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="tall_shoulder_height",
            reference="body_diameter",
            ratio_low=0.48,
            ratio_high=0.82,
            active_when=(ActiveWhen(factor="profile_family", values=("tapered_tall",)),),
            description="Tall-family shoulder transition height.",
            unit="m",
        ),
        Derived(
            name="shoulder_height",
            derive=lambda p: p[
                "compact_shoulder_height"
                if p["profile_family"] == "rounded_short"
                else "tall_shoulder_height"
            ],
            depends_on=(
                "profile_family",
                "compact_shoulder_height",
                "tall_shoulder_height",
            ),
            description="Active family's shoulder transition height.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="compact_neck_outer_diameter",
            reference="body_diameter",
            ratio_low=0.36,
            ratio_high=0.56,
            active_when=(ActiveWhen(factor="profile_family", values=("rounded_short",)),),
            description="Compact-family neck outside diameter.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="tall_neck_outer_diameter",
            reference="body_diameter",
            ratio_low=0.30,
            ratio_high=0.40,
            active_when=(ActiveWhen(factor="profile_family", values=("tapered_tall",)),),
            description="Tall-family neck outside diameter.",
            unit="m",
        ),
        Derived(
            name="neck_outer_diameter",
            derive=lambda p: p[
                "compact_neck_outer_diameter"
                if p["profile_family"] == "rounded_short"
                else "tall_neck_outer_diameter"
            ],
            depends_on=(
                "profile_family",
                "compact_neck_outer_diameter",
                "tall_neck_outer_diameter",
            ),
            description="Active family's neck outside diameter.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="compact_neck_height",
            reference="body_diameter",
            ratio_low=0.28,
            ratio_high=0.50,
            active_when=(ActiveWhen(factor="profile_family", values=("rounded_short",)),),
            description="Compact-family exposed neck height.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="tall_neck_height",
            reference="body_diameter",
            ratio_low=0.42,
            ratio_high=0.70,
            active_when=(ActiveWhen(factor="profile_family", values=("tapered_tall",)),),
            description="Tall-family exposed neck height.",
            unit="m",
        ),
        Derived(
            name="neck_height",
            derive=lambda p: p[
                "compact_neck_height"
                if p["profile_family"] == "rounded_short"
                else "tall_neck_height"
            ],
            depends_on=(
                "profile_family",
                "compact_neck_height",
                "tall_neck_height",
            ),
            description="Active family's exposed neck height.",
            unit="m",
        ),
        UniformFloat(
            name="compact_opening_ratio",
            low=0.62,
            high=0.84,
            active_when=(ActiveWhen(factor="profile_family", values=("rounded_short",)),),
            description="Compact-family mouth opening to outside-neck diameter ratio.",
            unit="ratio",
        ),
        UniformFloat(
            name="tall_opening_ratio",
            low=0.60,
            high=0.72,
            active_when=(ActiveWhen(factor="profile_family", values=("tapered_tall",)),),
            description="Tall-family mouth opening to outside-neck diameter ratio.",
            unit="ratio",
        ),
        Derived(
            name="opening_diameter",
            derive=lambda p: (
                p["neck_outer_diameter"]
                * p[
                    "compact_opening_ratio"
                    if p["profile_family"] == "rounded_short"
                    else "tall_opening_ratio"
                ]
            ),
            depends_on=(
                "profile_family",
                "neck_outer_diameter",
                "compact_opening_ratio",
                "tall_opening_ratio",
            ),
            description="Clear circular mouth diameter.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="body_wall_thickness",
            reference="body_diameter",
            ratio_low=0.018,
            ratio_high=0.055,
            hard_min=0.0012,
            hard_max=0.0045,
            description="Radial wall thickness of the body shell.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="finish_height",
            reference="neck_outer_diameter",
            ratio_low=0.16,
            ratio_high=0.34,
            description="Height of the closure-finish bead at the mouth.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="finish_bulge",
            reference="neck_outer_diameter",
            ratio_low=0.025,
            ratio_high=0.075,
            description="Radial prominence of the closure-finish bead.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="cap_height",
            reference="neck_outer_diameter",
            ratio_low=0.35,
            ratio_high=0.62,
            active_when=(ActiveWhen(factor="closure_state", values=("capped",)),),
            description="Height of the seated cylindrical closure.",
            unit="m",
        ),
        UniformFloat(
            name="cap_overhang_ratio",
            low=0.05,
            high=0.13,
            active_when=(ActiveWhen(factor="closure_state", values=("capped",)),),
            description="Cap radial overhang relative to the outside neck radius.",
            unit="ratio",
        ),
    ),
    build=build_model,
    tests=run_tests,
    population_checks=(
        PopulationCheck(
            name="profile-family-coverage",
            predicate=lambda samples: _choice_coverage(
                samples, "profile_family", {"rounded_short", "tapered_tall"}
            ),
            message="Both common profile families must appear in the population.",
        ),
        PopulationCheck(
            name="compact-height-envelope",
            predicate=lambda samples: _conditional_bounds(
                samples,
                family="rounded_short",
                factor="compact_body_height",
                low_ratio=2.0,
                high_ratio=3.0,
            ),
            message="Compact bottles must exercise their ordinary body-height envelope.",
        ),
        PopulationCheck(
            name="tall-height-envelope",
            predicate=lambda samples: _conditional_bounds(
                samples,
                family="tapered_tall",
                factor="tall_body_height",
                low_ratio=2.6,
                high_ratio=3.4,
            ),
            message="Tall bottles must exercise their ordinary body-height envelope.",
        ),
        PopulationCheck(
            name="compact-neck-envelope",
            predicate=lambda samples: _conditional_bounds(
                samples,
                family="rounded_short",
                factor="compact_neck_outer_diameter",
                low_ratio=0.36,
                high_ratio=0.56,
            ),
            message="Compact bottles must exercise their ordinary neck-width envelope.",
        ),
        PopulationCheck(
            name="tall-neck-envelope",
            predicate=lambda samples: _conditional_bounds(
                samples,
                family="tapered_tall",
                factor="tall_neck_outer_diameter",
                low_ratio=0.30,
                high_ratio=0.40,
            ),
            message="Tall bottles must exercise their ordinary neck-width envelope.",
        ),
    ),
    relationships=(
        RigidMount(
            name="cap-seated-on-neck-rim",
            parent_part="bottle",
            parent_element="shell",
            child_part="closure",
            child_element="cap",
            fixed_joint="bottle_to_cap",
            contact_tolerance=1e-6,
            active_when=(ActiveWhen(factor="closure_state", values=("capped",)),),
        ),
    ),
    task_requirements=(
        "Must remain a hollow, narrow-neck vessel; open cases expose the mouth and capped "
        "cases carry a closure genuinely seated on the neck rim.",
    ),
    tags=("bottle", "container", "hollow vessel", "narrow neck"),
)
