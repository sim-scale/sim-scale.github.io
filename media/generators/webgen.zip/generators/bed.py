from __future__ import annotations

from typing import Any, Mapping, Sequence

from assetengine import (
    ActiveWhen,
    Constraint,
    Derived,
    GeneratorDesign,
    GeneratorSpec,
    PopulationCheck,
    RigidMount,
    RelativeUniformFloat,
    SupportContact,
    UniformChoice,
    UniformFloat,
)
from assetengine.articraft import (
    ArticulatedObject,
    Box,
    ExtrudeGeometry,
    Material,
    Origin,
    TestContext,
    mesh_from_geometry,
    rounded_rect_profile,
)


_MATTRESS_FOOTPRINTS = {
    "narrow_short": (0.965, 1.905),
    "narrow_long": (0.965, 2.030),
    "double_short": (1.370, 1.905),
    "queen_long": (1.525, 2.030),
    "wide_long": (1.930, 2.030),
    "wide_extra_long": (1.830, 2.135),
}


def _mattress_width(parameters: Mapping[str, Any]) -> float:
    return _MATTRESS_FOOTPRINTS[str(parameters["sleep_surface_format"])][0]


def _mattress_length(parameters: Mapping[str, Any]) -> float:
    return _MATTRESS_FOOTPRINTS[str(parameters["sleep_surface_format"])][1]


def _rail_width(parameters: Mapping[str, Any]) -> float:
    key = (
        "slim_rail_width" if parameters["rail_construction"] == "slim_rail" else "thick_rail_width"
    )
    return float(parameters[key])


def _rail_height(parameters: Mapping[str, Any]) -> float:
    key = (
        "slim_rail_height"
        if parameters["rail_construction"] == "slim_rail"
        else "thick_rail_height"
    )
    return float(parameters[key])


def _lower_support_height(parameters: Mapping[str, Any]) -> float:
    if parameters["base_construction"] == "open_legged":
        return float(parameters["leg_height"])
    return float(parameters["plinth_height"])


def _outer_width(parameters: Mapping[str, Any]) -> float:
    return float(parameters["mattress_width"]) + 2.0 * (
        float(parameters["mattress_frame_clearance"]) + float(parameters["rail_width"])
    )


def _outer_length(parameters: Mapping[str, Any]) -> float:
    return float(parameters["mattress_length"]) + 2.0 * (
        float(parameters["mattress_frame_clearance"]) + float(parameters["rail_width"])
    )


def _support_surface_height(parameters: Mapping[str, Any]) -> float:
    rail_top = float(parameters["lower_support_height"]) + float(parameters["rail_height"])
    if parameters["rail_construction"] == "slim_rail":
        return rail_top - float(parameters["mattress_inset_depth"])
    return rail_top + float(parameters["deck_thickness"])


def _mattress_top_height(parameters: Mapping[str, Any]) -> float:
    return float(parameters["support_surface_height"]) + float(parameters["mattress_thickness"])


def _covers_choices(samples: Sequence[Mapping[str, Any]], factor: str, expected: set[str]) -> bool:
    return {str(sample[factor]) for sample in samples} >= expected


def _covers_bounds(
    samples: Sequence[Mapping[str, Any]],
    factor: str,
    *,
    minimum_at_most: float,
    maximum_at_least: float,
) -> bool:
    values = [float(sample[factor]) for sample in samples]
    return min(values) <= minimum_at_most and max(values) >= maximum_at_least


def build_model(parameters: Mapping[str, Any]) -> ArticulatedObject:
    def value(name: str) -> float:
        return float(parameters[name])

    outer_width = value("outer_width")
    outer_length = value("outer_length")
    rail_width = value("rail_width")
    rail_height = value("rail_height")
    lower_support_height = value("lower_support_height")
    deck_thickness = value("deck_thickness")
    support_surface_height = value("support_surface_height")
    deck_bottom = support_surface_height - deck_thickness
    mattress_width = value("mattress_width")
    mattress_length = value("mattress_length")
    mattress_thickness = value("mattress_thickness")

    neutral = Material(name="neutral", color=(0.58, 0.61, 0.64, 1.0))
    soft_neutral = Material(name="mattress_neutral", color=(0.82, 0.82, 0.79, 1.0))
    model = ArticulatedObject(name="bed")
    bed = model.part("bed")

    if parameters["rail_construction"] == "slim_rail":
        deck_width = mattress_width + 2.0 * value("mattress_frame_clearance")
        deck_length = mattress_length + 2.0 * value("mattress_frame_clearance")
    else:
        deck_width = outer_width
        deck_length = outer_length
    bed.visual(
        Box((deck_width, deck_length, deck_thickness)),
        origin=Origin(xyz=(0.0, 0.0, deck_bottom + 0.5 * deck_thickness)),
        material=neutral,
        name="platform_deck",
    )
    rail_center_z = lower_support_height + 0.5 * rail_height
    side_x = 0.5 * (outer_width - rail_width)
    bed.visual(
        Box((rail_width, outer_length, rail_height)),
        origin=Origin(xyz=(-side_x, 0.0, rail_center_z)),
        material=neutral,
        name="left_side_rail",
    )
    bed.visual(
        Box((rail_width, outer_length, rail_height)),
        origin=Origin(xyz=(side_x, 0.0, rail_center_z)),
        material=neutral,
        name="right_side_rail",
    )
    transverse_width = outer_width - 2.0 * rail_width
    end_y = 0.5 * (outer_length - rail_width)
    bed.visual(
        Box((transverse_width, rail_width, rail_height)),
        origin=Origin(xyz=(0.0, end_y, rail_center_z)),
        material=neutral,
        name="head_end_rail",
    )
    bed.visual(
        Box((transverse_width, rail_width, rail_height)),
        origin=Origin(xyz=(0.0, -end_y, rail_center_z)),
        material=neutral,
        name="foot_end_rail",
    )
    bed.visual(
        Box((0.075, outer_length - 2.0 * rail_width, rail_height)),
        origin=Origin(xyz=(0.0, 0.0, rail_center_z)),
        material=neutral,
        name="center_support_beam",
    )

    if parameters["base_construction"] == "open_legged":
        leg_width = value("leg_width")
        leg_x = side_x
        leg_y = 0.5 * outer_length - max(rail_width, 0.75 * leg_width)
        for x_name, x in (("left", -leg_x), ("right", leg_x)):
            for y_name, y in (("head", leg_y), ("foot", -leg_y)):
                bed.visual(
                    Box((leg_width, leg_width, lower_support_height)),
                    origin=Origin(xyz=(x, y, 0.5 * lower_support_height)),
                    material=neutral,
                    name=f"{x_name}_{y_name}_leg",
                )
    else:
        bed.visual(
            Box((0.58 * outer_width, 0.64 * outer_length, lower_support_height)),
            origin=Origin(xyz=(0.0, 0.0, 0.5 * lower_support_height)),
            material=neutral,
            name="recessed_plinth",
        )

    mattress_geometry = ExtrudeGeometry(
        rounded_rect_profile(
            mattress_width,
            mattress_length,
            value("mattress_corner_radius"),
            corner_segments=8,
        ),
        mattress_thickness,
    )
    bed.visual(
        mesh_from_geometry(mattress_geometry, "bed_mattress"),
        origin=Origin(xyz=(0.0, 0.0, support_surface_height + 0.5 * mattress_thickness)),
        material=soft_neutral,
        name="mattress",
    )

    mattress_top = support_surface_height + mattress_thickness
    if parameters["headboard_style"] == "solid_panel":
        thickness = value("panel_headboard_thickness")
        panel_top = mattress_top + value("headboard_height_above_mattress")
        panel_bottom = lower_support_height
        panel_height = panel_top - panel_bottom
        bed.visual(
            Box((outer_width, thickness, panel_height)),
            origin=Origin(
                xyz=(
                    0.0,
                    0.5 * outer_length + 0.5 * thickness,
                    panel_bottom + 0.5 * panel_height,
                )
            ),
            material=neutral,
            name="panel_headboard",
        )
    elif parameters["headboard_style"] == "open_bar":
        member = value("open_headboard_member_width")
        thickness = value("open_headboard_thickness")
        top = mattress_top + value("headboard_height_above_mattress")
        post_height = top
        post_x = 0.5 * (outer_width - member)
        post_y = 0.5 * outer_length + 0.5 * thickness
        for name, x in (("left_headboard_post", -post_x), ("right_headboard_post", post_x)):
            bed.visual(
                Box((member, thickness, post_height)),
                origin=Origin(xyz=(x, post_y, 0.5 * post_height)),
                material=neutral,
                name=name,
            )
        bar_width = outer_width - 2.0 * member
        rise = value("headboard_height_above_mattress")
        for name, z in (
            ("lower_headboard_bar", mattress_top + 0.18 * rise),
            ("upper_headboard_bar", mattress_top + 0.78 * rise),
        ):
            bed.visual(
                Box((bar_width, thickness, member)),
                origin=Origin(xyz=(0.0, post_y, z)),
                material=neutral,
                name=name,
            )

    if parameters["headboard_style"] != "none" and parameters["footboard_style"] == "low_panel":
        thickness = value("footboard_thickness")
        top = support_surface_height + value("footboard_height_above_support")
        bottom = lower_support_height
        height = top - bottom
        bed.visual(
            Box((outer_width, thickness, height)),
            origin=Origin(
                xyz=(
                    0.0,
                    -0.5 * outer_length - 0.5 * thickness,
                    bottom + 0.5 * height,
                )
            ),
            material=neutral,
            name="footboard_panel",
        )
    return model


def run_tests(model: ArticulatedObject, parameters: Mapping[str, Any]):
    def value(name: str) -> float:
        return float(parameters[name])

    ctx = TestContext(model)
    ctx.check_model_valid()
    ctx.check(
        "frame-clears-mattress-on-both-sides",
        value("outer_width") > value("mattress_width")
        and value("outer_length") > value("mattress_length"),
    )
    ctx.check(
        "deck-top-is-above-supports",
        value("lower_support_height") + value("rail_height") + value("deck_thickness") > 0.0,
    )
    ctx.check(
        "rounded-mattress-corners-fit-its-footprint",
        0.0 < value("mattress_corner_radius") < 0.5 * value("mattress_width"),
    )
    ctx.check("ordinary-mattress-top-height", value("mattress_top_height") <= 0.83)
    if parameters["headboard_style"] != "none":
        ctx.check(
            "headboard-rises-above-mattress-with-ordinary-total-height",
            value("headboard_height_above_mattress") > 0.0
            and value("mattress_top_height") + value("headboard_height_above_mattress") <= 1.50,
        )
    if parameters["headboard_style"] != "none" and parameters["footboard_style"] == "low_panel":
        ctx.check(
            "footboard-stays-below-mattress-top",
            value("footboard_height_above_support") < value("mattress_thickness"),
        )
    return ctx.report()


GENERATOR = GeneratorSpec(
    name="bed",
    category="bed",
    description=(
        "Ordinary adult beds with a mattress, load-bearing frame, open-leg or recessed-plinth "
        "base, and common optional headboard and footboard constructions."
    ),
    design=GeneratorDesign(
        coverage=(
            "Ordinary adult residential beds span six separated standard sleep-surface footprints: "
            "0.965 x 1.905 m narrow-short, 0.965 x 2.030 m narrow-long, 1.370 x 1.905 m "
            "double-short, 1.525 x 2.030 m queen-long, 1.930 x 2.030 m wide-long, and "
            "1.830 x 2.135 m wide-extra-long. Common conventional inset slim-rail and exposed "
            "thick-platform frames combine "
            "with open four-leg or recessed-plinth bases, no headboard, a full panel, or an open "
            "two-post headboard, plus an optional low footboard. Bunk, loft, canopy, sleigh, "
            "folding, hospital, water, crib, novelty, storage-drawer mechanisms, and full-depth "
            "divan foundations are excluded as specialty, adjacent, or less common topology for "
            "this frame-centered scope."
        ),
        factors=(
            "The separated standard mattress footprints are one geometric choice rather than a "
            "continuous alias-based size control. Mattress thickness (0.18-0.36 m), corner radius "
            "(0.025-0.080 m), and frame clearance (0.006-0.025 m) remain independent because they "
            "vary across every footprint. Rail widths and heights are conditional: slim rails use "
            "0.025-0.060 m widths and 0.10-0.18 m heights, while thick rails use 0.08-0.16 m widths "
            "and 0.14-0.24 m heights. Independent leg and plinth heights retain their complete "
            "0.12-0.32 m and 0.05-0.16 m envelopes. Conventional mattresses independently inset "
            "0.025-0.075 m below rail tops. Explicit valid-region constraints reject only stacks "
            "above 0.83 m, headboards above 1.50 m, or inset deck combinations deeper than their "
            "rails; no realized factor is clamped. Platform mattresses sit above the deck. Outer "
            "dimensions and support planes are exact derived fit consequences. All stochastic "
            "factors are uniform."
        ),
        components=(
            "The sleep surface varies discretely in footprint and continuously in thickness and "
            "corner radius. The frame varies in rail cross-section, border clearance, deck "
            "thickness, mattress seating topology, base construction and elevation. Headboards "
            "vary in absence, solid-panel or open-bar topology, height and construction-appropriate "
            "thickness; low footboards vary in presence and thickness only with an active "
            "headboard, and their rise scales below the mattress top. The center beam, four-leg "
            "count, two open-headboard "
            "bars, rectilinear structural members, and neutral finish are fixed incidental details."
        ),
        physics_and_task=(
            "A continuous deck supports the complete mattress at a zero-gap horizontal interface. "
            "Conventional frames place that deck within the rails and visibly retain the mattress; "
            "platform frames place a full deck above them. Open legs meet side-rail bottoms, "
            "while the recessed plinth meets the center-beam bottom. Panel headboards and optional "
            "footboards seat across full-width end-rail faces; each open headboard post has its own "
            "finite end-rail root. Named relationships cover the mattress support and every "
            "headboard or footboard root without connector geometry or invented task clearances."
        ),
    ),
    factors=(
        UniformChoice(
            name="sleep_surface_format",
            choices=tuple(_MATTRESS_FOOTPRINTS),
            description="Separated ordinary standard mattress footprint expressed by geometry.",
        ),
        Derived(
            name="mattress_width",
            derive=_mattress_width,
            depends_on=("sleep_surface_format",),
            description="Exact width of the selected standard mattress footprint.",
            unit="m",
        ),
        Derived(
            name="mattress_length",
            derive=_mattress_length,
            depends_on=("sleep_surface_format",),
            description="Exact length of the selected standard mattress footprint.",
            unit="m",
        ),
        UniformFloat(
            name="mattress_thickness",
            low=0.18,
            high=0.36,
            description="Independent mattress vertical thickness across ordinary constructions.",
            unit="m",
        ),
        UniformFloat(
            name="mattress_corner_radius",
            low=0.025,
            high=0.080,
            description="Plan-view radius of the mattress's four continuous rounded corners.",
            unit="m",
        ),
        UniformChoice(
            name="rail_construction",
            choices=("slim_rail", "thick_rail"),
            description="Slim structural rail or visibly thick platform-frame cross-section.",
        ),
        UniformFloat(
            name="slim_rail_width",
            low=0.025,
            high=0.060,
            active_when=(ActiveWhen(factor="rail_construction", values=("slim_rail",)),),
            description="Horizontal border width of an active slim side or end rail.",
            unit="m",
        ),
        UniformFloat(
            name="slim_rail_height",
            low=0.10,
            high=0.18,
            active_when=(ActiveWhen(factor="rail_construction", values=("slim_rail",)),),
            description="Vertical depth of an active slim side or end rail.",
            unit="m",
        ),
        UniformFloat(
            name="thick_rail_width",
            low=0.08,
            high=0.16,
            active_when=(ActiveWhen(factor="rail_construction", values=("thick_rail",)),),
            description="Horizontal border width of an active thick platform rail.",
            unit="m",
        ),
        UniformFloat(
            name="thick_rail_height",
            low=0.14,
            high=0.24,
            active_when=(ActiveWhen(factor="rail_construction", values=("thick_rail",)),),
            description="Vertical depth of an active thick platform rail.",
            unit="m",
        ),
        Derived(
            name="rail_width",
            derive=_rail_width,
            depends_on=("rail_construction", "slim_rail_width", "thick_rail_width"),
            description="Construction-conditioned realized side and end rail border width.",
            unit="m",
        ),
        Derived(
            name="rail_height",
            derive=_rail_height,
            depends_on=("rail_construction", "slim_rail_height", "thick_rail_height"),
            description="Construction-conditioned realized rail vertical depth.",
            unit="m",
        ),
        UniformFloat(
            name="mattress_frame_clearance",
            low=0.006,
            high=0.025,
            description="Independent horizontal fit gap between mattress and surrounding rails.",
            unit="m",
        ),
        UniformFloat(
            name="deck_thickness",
            low=0.025,
            high=0.055,
            description="Thickness of the continuous mattress-support platform.",
            unit="m",
        ),
        UniformFloat(
            name="mattress_inset_depth",
            low=0.025,
            high=0.075,
            active_when=(ActiveWhen(factor="rail_construction", values=("slim_rail",)),),
            description=(
                "Depth that a conventional-frame mattress support sits below the surrounding "
                "rail tops; inactive for exposed platform frames."
            ),
            unit="m",
        ),
        UniformChoice(
            name="base_construction",
            choices=("open_legged", "recessed_plinth"),
            description="Open under-bed four-leg base or inward-recessed continuous plinth.",
        ),
        UniformFloat(
            name="leg_height",
            low=0.12,
            high=0.32,
            active_when=(ActiveWhen(factor="base_construction", values=("open_legged",)),),
            description="Floor-to-rail vertical clearance for the open-leg base.",
            unit="m",
        ),
        UniformFloat(
            name="leg_width",
            low=0.035,
            high=0.075,
            active_when=(ActiveWhen(factor="base_construction", values=("open_legged",)),),
            description="Square cross-section width of each of four open-base legs.",
            unit="m",
        ),
        UniformFloat(
            name="plinth_height",
            low=0.05,
            high=0.16,
            active_when=(ActiveWhen(factor="base_construction", values=("recessed_plinth",)),),
            description="Floor-to-center-beam height of the inward-recessed plinth.",
            unit="m",
        ),
        Derived(
            name="lower_support_height",
            derive=_lower_support_height,
            depends_on=(
                "base_construction",
                "rail_construction",
                "leg_height",
                "plinth_height",
            ),
            description="Construction-conditioned realized height below the rail frame.",
            unit="m",
        ),
        Derived(
            name="outer_width",
            derive=_outer_width,
            depends_on=("mattress_width", "mattress_frame_clearance", "rail_width"),
            description="Exact overall deck width including two rails and mattress fit gaps.",
            unit="m",
        ),
        Derived(
            name="outer_length",
            derive=_outer_length,
            depends_on=("mattress_length", "mattress_frame_clearance", "rail_width"),
            description="Exact overall deck length including two end rails and fit gaps.",
            unit="m",
        ),
        Derived(
            name="support_surface_height",
            derive=_support_surface_height,
            depends_on=(
                "lower_support_height",
                "rail_height",
                "rail_construction",
                "mattress_inset_depth",
                "deck_thickness",
            ),
            description=(
                "Mattress support plane: inset below conventional rail tops or exposed above "
                "the thick-platform rails."
            ),
            unit="m",
        ),
        Derived(
            name="mattress_top_height",
            derive=_mattress_top_height,
            depends_on=("support_surface_height", "mattress_thickness"),
            description="Exact realized floor-to-mattress-top height.",
            unit="m",
        ),
        UniformChoice(
            name="headboard_style",
            choices=("none", "solid_panel", "open_bar"),
            description="No headboard, a full solid panel, or a two-post open-bar headboard.",
        ),
        UniformFloat(
            name="headboard_height_above_mattress",
            low=0.32,
            high=0.68,
            active_when=(ActiveWhen(factor="headboard_style", values=("solid_panel", "open_bar")),),
            description="Visible headboard rise above the mattress top.",
            unit="m",
        ),
        UniformFloat(
            name="panel_headboard_thickness",
            low=0.045,
            high=0.14,
            active_when=(ActiveWhen(factor="headboard_style", values=("solid_panel",)),),
            description="Front-to-back thickness of a solid panel headboard.",
            unit="m",
        ),
        UniformFloat(
            name="open_headboard_member_width",
            low=0.025,
            high=0.065,
            active_when=(ActiveWhen(factor="headboard_style", values=("open_bar",)),),
            description="Shared square-looking width of open headboard posts and bars.",
            unit="m",
        ),
        UniformFloat(
            name="open_headboard_thickness",
            low=0.025,
            high=0.065,
            active_when=(ActiveWhen(factor="headboard_style", values=("open_bar",)),),
            description="Front-to-back depth of open headboard posts and bars.",
            unit="m",
        ),
        UniformChoice(
            name="footboard_style",
            choices=("open_end", "low_panel"),
            active_when=(ActiveWhen(factor="headboard_style", values=("solid_panel", "open_bar")),),
            description="Open mattress end or a low full-width footboard panel.",
        ),
        RelativeUniformFloat(
            name="footboard_height_above_support",
            reference="mattress_thickness",
            ratio_low=0.30,
            ratio_high=0.85,
            active_when=(
                ActiveWhen(factor="headboard_style", values=("solid_panel", "open_bar")),
                ActiveWhen(factor="footboard_style", values=("low_panel",)),
            ),
            description=(
                "Low footboard rise above the mattress support plane, kept below the realized "
                "mattress top across ordinary mattress thicknesses."
            ),
            unit="m",
        ),
        UniformFloat(
            name="footboard_thickness",
            low=0.035,
            high=0.11,
            active_when=(
                ActiveWhen(factor="headboard_style", values=("solid_panel", "open_bar")),
                ActiveWhen(factor="footboard_style", values=("low_panel",)),
            ),
            description="Front-to-back thickness of the optional low footboard.",
            unit="m",
        ),
    ),
    constraints=(
        Constraint(
            name="conventional-deck-contained-within-rails",
            predicate=lambda p: (
                p["rail_construction"] != "slim_rail"
                or p["mattress_inset_depth"] + p["deck_thickness"] <= p["rail_height"]
            ),
            message=(
                "A conventional inset deck must remain vertically contained within and seated "
                "against its surrounding rails."
            ),
        ),
        Constraint(
            name="ordinary-floor-to-mattress-top",
            predicate=lambda p: p["mattress_top_height"] <= 0.83,
            message="The complete floor-to-mattress-top stack must not exceed 0.83 m.",
        ),
        Constraint(
            name="ordinary-total-headboard-height",
            predicate=lambda p: (
                p["headboard_style"] == "none"
                or p["mattress_top_height"] + p["headboard_height_above_mattress"] <= 1.50
            ),
            message="An active headboard top must remain at or below 1.50 m.",
        ),
    ),
    relationships=(
        SupportContact(
            name="mattress-rests-on-platform",
            supporting_part="bed",
            supporting_element="platform_deck",
            supported_part="bed",
            supported_element="mattress",
        ),
        RigidMount(
            name="panel-headboard-seated-on-frame",
            parent_part="bed",
            parent_element="head_end_rail",
            child_part="bed",
            child_element="panel_headboard",
            active_when=(ActiveWhen(factor="headboard_style", values=("solid_panel",)),),
        ),
        RigidMount(
            name="left-open-headboard-post-seated-on-frame",
            parent_part="bed",
            parent_element="left_side_rail",
            child_part="bed",
            child_element="left_headboard_post",
            active_when=(ActiveWhen(factor="headboard_style", values=("open_bar",)),),
        ),
        RigidMount(
            name="right-open-headboard-post-seated-on-frame",
            parent_part="bed",
            parent_element="right_side_rail",
            child_part="bed",
            child_element="right_headboard_post",
            active_when=(ActiveWhen(factor="headboard_style", values=("open_bar",)),),
        ),
        RigidMount(
            name="footboard-seated-on-frame",
            parent_part="bed",
            parent_element="foot_end_rail",
            child_part="bed",
            child_element="footboard_panel",
            active_when=(
                ActiveWhen(factor="headboard_style", values=("solid_panel", "open_bar")),
                ActiveWhen(factor="footboard_style", values=("low_panel",)),
            ),
        ),
    ),
    build=build_model,
    tests=run_tests,
    population_checks=(
        PopulationCheck(
            name="key-standard-sleep-surface-formats",
            predicate=lambda samples: _covers_choices(
                samples,
                "sleep_surface_format",
                {"narrow_short", "double_short", "queen_long", "wide_extra_long"},
            ),
            message=(
                "Population must exercise narrow, double, queen, and extra-long standard "
                "mattress regimes; the larger geometry profile samples remaining formats."
            ),
        ),
        PopulationCheck(
            name="both-rail-constructions",
            predicate=lambda samples: _covers_choices(
                samples, "rail_construction", {"slim_rail", "thick_rail"}
            ),
            message="Population must exercise slim and thick rail constructions.",
        ),
        PopulationCheck(
            name="both-base-constructions",
            predicate=lambda samples: _covers_choices(
                samples, "base_construction", {"open_legged", "recessed_plinth"}
            ),
            message="Population must exercise open-leg and recessed-plinth bases.",
        ),
        PopulationCheck(
            name="all-headboard-topologies",
            predicate=lambda samples: _covers_choices(
                samples, "headboard_style", {"none", "solid_panel", "open_bar"}
            ),
            message="Population must exercise absent, panel, and open-bar headboards.",
        ),
        PopulationCheck(
            name="both-footboard-topologies",
            predicate=lambda samples: _covers_choices(
                samples, "footboard_style", {"open_end", "low_panel"}
            ),
            message="Population must exercise open and low-panel foot ends.",
        ),
        PopulationCheck(
            name="mattress-thickness-envelope",
            predicate=lambda samples: _covers_bounds(
                samples, "mattress_thickness", minimum_at_most=0.20, maximum_at_least=0.34
            ),
            message="Population must span ordinary thin and thick mattresses.",
        ),
        PopulationCheck(
            name="bed-elevation-envelope",
            predicate=lambda samples: _covers_bounds(
                samples, "lower_support_height", minimum_at_most=0.10, maximum_at_least=0.21
            ),
            message="Population must span low-plinth and high-clearance bed bases.",
        ),
    ),
    task_requirements=(),
    tags=("bed", "furniture", "mattress", "platform", "headboard"),
)
