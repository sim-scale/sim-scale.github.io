from __future__ import annotations

import math
from typing import Any, Mapping, Sequence

from assetengine import (
    ActiveWhen,
    Constraint,
    Derived,
    GeneratorDesign,
    GeneratorSpec,
    JointMount,
    PopulationCheck,
    RigidMount,
    UniformChoice,
    UniformFloat,
)
from assetengine.articraft import (
    ArticulatedObject,
    ArticulationType,
    Box,
    Cylinder,
    MotionLimits,
    Origin,
    TestContext,
)


def _covers_bounds(
    samples: Sequence[Mapping[str, Any]], factor: str, *, low: float, high: float
) -> bool:
    values = [float(sample[factor]) for sample in samples]
    return min(values) <= low and max(values) >= high


def _covers_choices(samples: Sequence[Mapping[str, Any]], factor: str, required: set[str]) -> bool:
    return {str(sample[factor]) for sample in samples} >= required


def _add_door_handle(
    part,
    parameters,
    *,
    element_name: str,
    x: float,
    z: float,
    horizontal: bool = False,
) -> None:
    thickness = float(parameters["door_thickness"])
    projection = float(parameters["handle_projection"])
    if parameters["handle_style"] == "round_knob":
        part.visual(
            Cylinder(0.5 * float(parameters["knob_diameter"]), projection),
            origin=Origin(
                xyz=(x, -0.5 * (thickness + projection), z),
                rpy=(0.5 * math.pi, 0.0, 0.0),
            ),
            name=element_name,
        )
    else:
        bar_width = float(parameters["pull_width"])
        bar_height = float(parameters["pull_height"])
        grip_size = (
            (bar_height, bar_width, bar_width) if horizontal else (bar_width, bar_width, bar_height)
        )
        part.visual(
            Box(grip_size),
            origin=Origin(xyz=(x, -0.5 * thickness - projection, z)),
            name=f"{element_name}_grip",
        )
        roots = (
            (
                ("left_root", x - 0.5 * bar_height + 0.5 * bar_width, z),
                ("right_root", x + 0.5 * bar_height - 0.5 * bar_width, z),
            )
            if horizontal
            else (
                ("lower_root", x, z - 0.5 * bar_height + 0.5 * bar_width),
                ("upper_root", x, z + 0.5 * bar_height - 0.5 * bar_width),
            )
        )
        for suffix, root_x, root_z in roots:
            part.visual(
                Box((bar_width, projection, bar_width)),
                origin=Origin(xyz=(root_x, -0.5 * (thickness + projection), root_z)),
                name=f"{element_name}_{suffix}",
            )


def _add_recessed_door_frame(
    part,
    parameters,
    *,
    panel_name: str,
    direction: float,
    panel_width: float,
    panel_height: float,
) -> None:
    if parameters["door_profile"] != "recessed_panel":
        return
    gap = float(parameters["door_gap"])
    thickness = float(parameters["door_thickness"])
    rail = min(float(parameters["frame_rail_width"]), 0.22 * panel_width)
    relief = float(parameters["panel_relief"])
    center_x = direction * 0.5 * panel_width
    y = -0.5 * (thickness + relief)
    for suffix, x in (
        ("frame_hinge", direction * 0.5 * rail),
        ("frame_free", direction * (panel_width - 0.5 * rail)),
    ):
        part.visual(
            Box((rail, relief, panel_height)),
            origin=Origin(xyz=(x, y, 0.5 * panel_height)),
            name=f"{panel_name}_{suffix}",
        )
    for suffix, z in (
        ("frame_bottom", 0.5 * rail),
        ("frame_top", panel_height - 0.5 * rail),
    ):
        part.visual(
            Box((max(panel_width - 2.0 * rail, gap), relief, rail)),
            origin=Origin(xyz=(center_x, y, z)),
            name=f"{panel_name}_{suffix}",
        )


def _add_hinged_door(
    model,
    cabinet,
    parameters,
    *,
    part_name: str,
    panel_name: str,
    handle_name: str,
    joint_name: str,
    hinge_x: float,
    direction: float,
    panel_width: float,
    panel_height: float,
    panel_bottom: float,
) -> None:
    gap = float(parameters["door_gap"])
    door_thickness = float(parameters["door_thickness"])
    depth = float(parameters["overall_depth"])
    handle_margin = min(0.080, max(0.045, 0.13 * panel_width))
    door = model.part(part_name)
    door.visual(
        Box((panel_width, door_thickness, panel_height)),
        origin=Origin(xyz=(direction * 0.5 * panel_width, 0.0, 0.5 * panel_height)),
        name=panel_name,
    )
    _add_recessed_door_frame(
        door,
        parameters,
        panel_name=panel_name,
        direction=direction,
        panel_width=panel_width,
        panel_height=panel_height,
    )
    _add_door_handle(
        door,
        parameters,
        element_name=handle_name,
        x=direction * (panel_width - handle_margin),
        z=0.54 * panel_height,
    )
    model.articulation(
        joint_name,
        ArticulationType.REVOLUTE,
        parent=cabinet,
        child=door,
        origin=Origin(xyz=(hinge_x, -0.5 * depth - 0.5 * door_thickness, panel_bottom)),
        axis=(0.0, 0.0, -direction),
        motion_limits=MotionLimits(
            effort=8.0,
            velocity=1.5,
            lower=0.0,
            upper=float(parameters["door_open_angle"]),
        ),
    )


def _add_top_drawer(
    model,
    cabinet,
    parameters,
    *,
    width: float,
    depth: float,
    center_z: float,
    front_height: float,
) -> None:
    wall = float(parameters["panel_thickness"])
    door_thickness = float(parameters["door_thickness"])
    gap = float(parameters["door_gap"])
    clearance = 0.010
    box_width = width - 2.0 * wall - 2.0 * clearance
    box_depth = 0.68 * (depth - wall)
    drawer = model.part("top_drawer")
    drawer.visual(
        Box((width - 2.0 * wall, door_thickness, front_height)),
        origin=Origin(),
        name="drawer_front",
    )
    bottom_z = -0.5 * front_height + wall
    drawer.visual(
        Box((box_width, box_depth, wall)),
        origin=Origin(xyz=(0.0, 0.5 * box_depth, bottom_z)),
        name="drawer_bottom",
    )
    side_height = max(front_height - 3.0 * wall, 0.065)
    for suffix, x in (
        ("left", -0.5 * box_width + 0.5 * wall),
        ("right", 0.5 * box_width - 0.5 * wall),
    ):
        drawer.visual(
            Box((wall, box_depth, side_height)),
            origin=Origin(xyz=(x, 0.5 * box_depth, bottom_z + 0.5 * side_height)),
            name=f"drawer_{suffix}_side",
        )
    drawer.visual(
        Box((box_width - 2.0 * wall, wall, side_height)),
        origin=Origin(xyz=(0.0, box_depth - 0.5 * wall, bottom_z + 0.5 * side_height)),
        name="drawer_rear",
    )
    _add_door_handle(
        drawer,
        parameters,
        element_name="drawer_handle",
        x=0.0,
        z=0.0,
        horizontal=True,
    )
    model.articulation(
        "cabinet_to_top_drawer",
        ArticulationType.PRISMATIC,
        parent=cabinet,
        child=drawer,
        origin=Origin(xyz=(0.0, -0.5 * depth - 0.5 * door_thickness, center_z)),
        axis=(0.0, -1.0, 0.0),
        motion_limits=MotionLimits(
            effort=35.0,
            velocity=0.35,
            lower=0.0,
            upper=max(0.16, min(0.42, box_depth - 0.08)),
        ),
    )


def build_model(parameters: Mapping[str, Any]) -> ArticulatedObject:
    width = float(parameters["overall_width"])
    depth = float(parameters["overall_depth"])
    height = float(parameters["overall_height"])
    wall = float(parameters["panel_thickness"])
    gap = float(parameters["door_gap"])
    support_height = float(parameters["support_height"])
    carcass_height = height - support_height
    inner_width = width - 2.0 * wall
    inner_height = carcass_height - 2.0 * wall
    drawer_height = float(parameters["drawer_front_height"])
    panel_bottom = support_height + wall + gap
    panel_height = inner_height - drawer_height - 2.0 * gap

    model = ArticulatedObject(name="cabinet")
    cabinet = model.part("cabinet")
    cabinet.visual(
        Box((width, depth, wall)),
        origin=Origin(xyz=(0.0, 0.0, support_height + 0.5 * wall)),
        name="base_panel",
    )
    cabinet.visual(
        Box((width, depth, wall)),
        origin=Origin(xyz=(0.0, 0.0, height - 0.5 * wall)),
        name="top_panel",
    )
    side_depth = depth - wall
    side_y = -0.5 * wall
    side_z = support_height + 0.5 * carcass_height
    cabinet.visual(
        Box((wall, side_depth, inner_height)),
        origin=Origin(xyz=(-0.5 * width + 0.5 * wall, side_y, side_z)),
        name="left_side",
    )
    cabinet.visual(
        Box((wall, side_depth, inner_height)),
        origin=Origin(xyz=(0.5 * width - 0.5 * wall, side_y, side_z)),
        name="right_side",
    )
    cabinet.visual(
        Box((inner_width, wall, inner_height)),
        origin=Origin(xyz=(0.0, 0.5 * depth - 0.5 * wall, side_z)),
        name="back_panel",
    )

    shelf_depth = depth - wall - 0.030
    shelf_y = 0.5 * (0.030 - wall)
    shelf_count = int(parameters["shelf_count"])
    shelf_span = inner_height - drawer_height
    for index in range(1, shelf_count + 1):
        shelf_z = support_height + wall + index * shelf_span / (shelf_count + 1)
        cabinet.visual(
            Box((inner_width, shelf_depth, wall)),
            origin=Origin(xyz=(0.0, shelf_y, shelf_z)),
            name=f"shelf_{index}",
        )

    if parameters["base_style"] == "recessed_plinth":
        cabinet.visual(
            Box((width - 0.10, depth - 0.08, support_height)),
            origin=Origin(xyz=(0.0, 0.02, 0.5 * support_height)),
            name="plinth",
        )

    if parameters["facade_layout"] == "single_door":
        hinge_left = parameters["single_hinge_side"] == "left"
        direction = 1.0 if hinge_left else -1.0
        _add_hinged_door(
            model,
            cabinet,
            parameters,
            part_name="single_door",
            panel_name="single_door_panel",
            handle_name="single_handle",
            joint_name="cabinet_to_single_door",
            hinge_x=direction * (-0.5 * inner_width),
            direction=direction,
            panel_width=inner_width - gap,
            panel_height=panel_height,
            panel_bottom=panel_bottom,
        )
    else:
        leaf_width = 0.5 * (inner_width - gap)
        _add_hinged_door(
            model,
            cabinet,
            parameters,
            part_name="left_door",
            panel_name="left_door_panel",
            handle_name="left_handle",
            joint_name="cabinet_to_left_door",
            hinge_x=-0.5 * inner_width,
            direction=1.0,
            panel_width=leaf_width,
            panel_height=panel_height,
            panel_bottom=panel_bottom,
        )
        if parameters["facade_layout"] == "mixed_drawer_doors":
            drawer_center_z = height - wall - gap - 0.5 * drawer_height
            _add_top_drawer(
                model,
                cabinet,
                parameters,
                width=width,
                depth=depth,
                center_z=drawer_center_z,
                front_height=drawer_height - gap,
            )
        _add_hinged_door(
            model,
            cabinet,
            parameters,
            part_name="right_door",
            panel_name="right_door_panel",
            handle_name="right_handle",
            joint_name="cabinet_to_right_door",
            hinge_x=0.5 * inner_width,
            direction=-1.0,
            panel_width=leaf_width,
            panel_height=panel_height,
            panel_bottom=panel_bottom,
        )
    return model


def run_tests(model: ArticulatedObject, parameters: Mapping[str, Any]):
    ctx = TestContext(model)
    spacing = (
        float(parameters["overall_height"])
        - float(parameters["support_height"])
        - 2.0 * float(parameters["panel_thickness"])
    ) / (int(parameters["shelf_count"]) + 1)
    ctx.check("shelves-retain-usable-spacing", spacing >= 0.10)
    ctx.fail_if_articulation_overlaps(
        max_pose_samples=9,
        overlap_volume_tol=1e-8,
        name="doors-open-without-volumetric-collision",
    )
    return ctx.report()


_SHELF_ACTIVE_VALUES = {
    1: ("compact_one", "compact_two", "tall_three", "tall_four", "tall_five"),
    2: ("compact_two", "tall_three", "tall_four", "tall_five"),
    3: ("tall_three", "tall_four", "tall_five"),
    4: ("tall_four", "tall_five"),
    5: ("tall_five",),
}


GENERATOR = GeneratorSpec(
    name="cabinet",
    category="cabinet",
    description=(
        "Ordinary freestanding storage cabinet with a closed carcass, shelves, and one or two "
        "outward-opening hinged doors."
    ),
    design=GeneratorDesign(
        coverage=(
            "Freestanding household and office storage cabinets are represented from compact "
            "0.50 m units through 1.90 m tall cupboards, 0.38-1.20 m wide and 0.30-0.60 m deep. "
            "Narrow 0.38-0.68 m carcasses use one door; 0.65-1.20 m carcasses use paired doors. "
            "Full-height single and paired doors plus a compact-cabinet upper-drawer/paired-door facade, "
            "slab and recessed-panel profiles, height-appropriate one-to-five shelf interiors, "
            "flush and recessed-plinth supports, knobs, and two-root bar pulls are included. "
            "Built-in kitchen runs, corner and glass-display cabinets, drawer-only filing units, "
            "and legged credenzas/sideboards are excluded as adjacent construction populations."
        ),
        factors=(
            "Facade topology precedes its conditional width because common single-door and "
            "double-door cabinets occupy materially different width envelopes. Shelf-layout "
            "regimes couple compact 0.50-1.10 m cabinets to one or two shelves and tall "
            "1.10-1.90 m cabinets to three through five shelves. Depth remains independent within "
            "this rectilinear shelf-cabinet scope because compact and tall examples overlap from "
            "0.30-0.60 m. A named constraint excludes the incoherent mixed facade on tall shelf "
            "cupboards; its drawer front keeps an independent ordinary 0.12-0.24 m absolute "
            "height. Width, cabinet height, shelf count, and support height are exact consequences."
        ),
        components=(
            "The category-defining carcass has two sides, top, bottom, closed back, and a genuine "
            "front-accessible interior divided by one to five full-width shelves. Facades vary "
            "between full-height leaves and a complete articulated box drawer over shorter doors, with "
            "flat or recessed-panel faces. Handles vary between knobs and genuine two-root bar "
            "pulls with an open grasp span; shelf setback and joint dynamics remain incidental."
        ),
        physics_and_task=(
            "Top, base, and sides form one connected carcass through the back; every shelf has a "
            "full-width rear mounting edge and the optional plinth seats beneath the base. Every "
            "knob or pull root has a finite face seated directly on its front. Doors are separate "
            "links on outward-opening revolute joints; the mixed-front drawer is a retained box on "
            "an outward prismatic joint. All moving links are checked throughout their motion."
        ),
    ),
    factors=(
        UniformChoice(
            name="facade_layout",
            choices=("mixed_drawer_doors", "single_door", "double_door"),
            description="One leaf, paired full-height leaves, or an upper drawer over paired leaves.",
        ),
        UniformFloat(
            name="single_door_width",
            low=0.38,
            high=0.68,
            active_when=(ActiveWhen(factor="facade_layout", values=("single_door",)),),
            description="Overall width for the single-door construction.",
            unit="m",
        ),
        UniformFloat(
            name="double_door_width",
            low=0.65,
            high=1.20,
            active_when=(
                ActiveWhen(factor="facade_layout", values=("double_door", "mixed_drawer_doors")),
            ),
            description="Overall width for paired-door and mixed-front constructions.",
            unit="m",
        ),
        Derived(
            name="overall_width",
            derive=lambda p: (
                p["single_door_width"]
                if p["facade_layout"] == "single_door"
                else p["double_door_width"]
            ),
            depends_on=("facade_layout", "single_door_width", "double_door_width"),
            description="Resolved overall width from the active facade construction.",
            unit="m",
        ),
        UniformChoice(
            name="shelf_layout",
            choices=("compact_one", "compact_two", "tall_three", "tall_four", "tall_five"),
            description="Height-appropriate interior partition regime and shelf count.",
        ),
        UniformFloat(
            name="compact_height",
            low=0.50,
            high=1.10,
            active_when=(ActiveWhen(factor="shelf_layout", values=("compact_one", "compact_two")),),
            description="Overall height of a compact one- or two-shelf cabinet.",
            unit="m",
        ),
        UniformFloat(
            name="tall_height",
            low=1.10,
            high=1.90,
            active_when=(
                ActiveWhen(factor="shelf_layout", values=("tall_three", "tall_four", "tall_five")),
            ),
            description="Overall height of a tall three- to five-shelf cabinet.",
            unit="m",
        ),
        Derived(
            name="overall_height",
            derive=lambda p: (
                p["compact_height"] if p["shelf_layout"].startswith("compact") else p["tall_height"]
            ),
            depends_on=("shelf_layout", "compact_height", "tall_height"),
            description="Resolved height from the active shelf-layout regime.",
            unit="m",
        ),
        UniformFloat(
            name="overall_depth",
            low=0.30,
            high=0.60,
            description="Front-to-back depth excluding handles.",
            unit="m",
        ),
        UniformFloat(
            name="panel_thickness",
            low=0.016,
            high=0.025,
            description="Structural thickness of carcass panels and shelves.",
            unit="m",
        ),
        UniformFloat(
            name="door_thickness",
            low=0.016,
            high=0.024,
            description="Front-to-back thickness of each slab door.",
            unit="m",
        ),
        UniformFloat(
            name="door_gap",
            low=0.0025,
            high=0.006,
            description="Visible clearance around and between door leaves.",
            unit="m",
        ),
        Derived(
            name="shelf_count",
            derive=lambda p: {
                "compact_one": 1,
                "compact_two": 2,
                "tall_three": 3,
                "tall_four": 4,
                "tall_five": 5,
            }[p["shelf_layout"]],
            depends_on=("shelf_layout",),
            description="Exact shelf count selected by the height-appropriate layout regime.",
            unit="count",
        ),
        UniformChoice(
            name="base_style",
            choices=("flush", "recessed_plinth"),
            description="Floor-level carcass or recessed supporting plinth.",
        ),
        Derived(
            name="support_height",
            derive=lambda p: 0.08 if p["base_style"] == "recessed_plinth" else 0.0,
            depends_on=("base_style",),
            description="Support height contributed by the selected base.",
            unit="m",
        ),
        UniformChoice(
            name="single_hinge_side",
            choices=("left", "right"),
            active_when=(ActiveWhen(factor="facade_layout", values=("single_door",)),),
            description="Hinge side of an active single door.",
        ),
        UniformFloat(
            name="door_open_angle",
            low=1.57,
            high=1.92,
            description="Maximum outward door swing.",
            unit="rad",
        ),
        UniformChoice(
            name="door_profile",
            choices=("slab", "recessed_panel"),
            description="Flat slab or raised perimeter around a recessed center panel.",
        ),
        UniformFloat(
            name="frame_rail_width",
            low=0.040,
            high=0.075,
            active_when=(ActiveWhen(factor="door_profile", values=("recessed_panel",)),),
            description="Face width of each recessed-panel rail and stile.",
            unit="m",
        ),
        UniformFloat(
            name="panel_relief",
            low=0.006,
            high=0.015,
            active_when=(ActiveWhen(factor="door_profile", values=("recessed_panel",)),),
            description="Outward relief of the frame from the recessed center.",
            unit="m",
        ),
        UniformFloat(
            name="mixed_drawer_height",
            low=0.12,
            high=0.24,
            active_when=(ActiveWhen(factor="facade_layout", values=("mixed_drawer_doors",)),),
            description="Absolute vertical height occupied by the upper drawer front.",
            unit="m",
        ),
        Derived(
            name="drawer_front_height",
            derive=lambda p: (
                p["mixed_drawer_height"] if p["facade_layout"] == "mixed_drawer_doors" else 0.0
            ),
            depends_on=("facade_layout", "mixed_drawer_height"),
            description="Resolved upper-drawer height; zero outside the mixed branch.",
            unit="m",
        ),
        UniformChoice(
            name="handle_style",
            choices=("round_knob", "rectangular_pull"),
            description="Circular knob or vertical rectangular surface pull.",
        ),
        UniformFloat(
            name="handle_projection",
            low=0.020,
            high=0.040,
            description="Outward handle projection from the door face.",
            unit="m",
        ),
        UniformFloat(
            name="knob_diameter",
            low=0.024,
            high=0.050,
            active_when=(ActiveWhen(factor="handle_style", values=("round_knob",)),),
            description="Circular face diameter of an active knob.",
            unit="m",
        ),
        UniformFloat(
            name="pull_width",
            low=0.014,
            high=0.030,
            active_when=(ActiveWhen(factor="handle_style", values=("rectangular_pull",)),),
            description="Horizontal face width of an active rectangular pull.",
            unit="m",
        ),
        UniformFloat(
            name="pull_height",
            low=0.080,
            high=0.180,
            active_when=(ActiveWhen(factor="handle_style", values=("rectangular_pull",)),),
            description="Vertical face height of an active rectangular pull.",
            unit="m",
        ),
    ),
    constraints=(
        Constraint(
            name="mixed-facade-requires-compact-height-regime",
            predicate=lambda p: (
                p["facade_layout"] != "mixed_drawer_doors"
                or p["shelf_layout"] in {"compact_one", "compact_two"}
            ),
            message=(
                "The ordinary drawer-over-door frontage is limited to compact cabinet heights; "
                "tall shelf cupboards use full-height hinged fronts."
            ),
        ),
    ),
    relationships=(
        RigidMount(
            name="shelf-1-mounted-to-back",
            parent_part="cabinet",
            parent_element="back_panel",
            child_part="cabinet",
            child_element="shelf_1",
            active_when=(ActiveWhen(factor="shelf_layout", values=_SHELF_ACTIVE_VALUES[1]),),
        ),
        RigidMount(
            name="shelf-2-mounted-to-back",
            parent_part="cabinet",
            parent_element="back_panel",
            child_part="cabinet",
            child_element="shelf_2",
            active_when=(ActiveWhen(factor="shelf_layout", values=_SHELF_ACTIVE_VALUES[2]),),
        ),
        RigidMount(
            name="shelf-3-mounted-to-back",
            parent_part="cabinet",
            parent_element="back_panel",
            child_part="cabinet",
            child_element="shelf_3",
            active_when=(ActiveWhen(factor="shelf_layout", values=_SHELF_ACTIVE_VALUES[3]),),
        ),
        RigidMount(
            name="shelf-4-mounted-to-back",
            parent_part="cabinet",
            parent_element="back_panel",
            child_part="cabinet",
            child_element="shelf_4",
            active_when=(ActiveWhen(factor="shelf_layout", values=_SHELF_ACTIVE_VALUES[4]),),
        ),
        RigidMount(
            name="shelf-5-mounted-to-back",
            parent_part="cabinet",
            parent_element="back_panel",
            child_part="cabinet",
            child_element="shelf_5",
            active_when=(ActiveWhen(factor="shelf_layout", values=_SHELF_ACTIVE_VALUES[5]),),
        ),
        RigidMount(
            name="single-knob-mounted-to-door",
            parent_part="single_door",
            parent_element="single_door_panel",
            child_part="single_door",
            child_element="single_handle",
            active_when=(
                ActiveWhen(factor="facade_layout", values=("single_door",)),
                ActiveWhen(factor="handle_style", values=("round_knob",)),
            ),
        ),
        RigidMount(
            name="single-pull-lower-root-mounted",
            parent_part="single_door",
            parent_element="single_door_panel",
            child_part="single_door",
            child_element="single_handle_lower_root",
            active_when=(
                ActiveWhen(factor="facade_layout", values=("single_door",)),
                ActiveWhen(factor="handle_style", values=("rectangular_pull",)),
            ),
        ),
        RigidMount(
            name="single-pull-upper-root-mounted",
            parent_part="single_door",
            parent_element="single_door_panel",
            child_part="single_door",
            child_element="single_handle_upper_root",
            active_when=(
                ActiveWhen(factor="facade_layout", values=("single_door",)),
                ActiveWhen(factor="handle_style", values=("rectangular_pull",)),
            ),
        ),
        RigidMount(
            name="left-knob-mounted-to-door",
            parent_part="left_door",
            parent_element="left_door_panel",
            child_part="left_door",
            child_element="left_handle",
            active_when=(
                ActiveWhen(factor="facade_layout", values=("double_door", "mixed_drawer_doors")),
                ActiveWhen(factor="handle_style", values=("round_knob",)),
            ),
        ),
        RigidMount(
            name="left-pull-lower-root-mounted",
            parent_part="left_door",
            parent_element="left_door_panel",
            child_part="left_door",
            child_element="left_handle_lower_root",
            active_when=(
                ActiveWhen(factor="facade_layout", values=("double_door", "mixed_drawer_doors")),
                ActiveWhen(factor="handle_style", values=("rectangular_pull",)),
            ),
        ),
        RigidMount(
            name="left-pull-upper-root-mounted",
            parent_part="left_door",
            parent_element="left_door_panel",
            child_part="left_door",
            child_element="left_handle_upper_root",
            active_when=(
                ActiveWhen(factor="facade_layout", values=("double_door", "mixed_drawer_doors")),
                ActiveWhen(factor="handle_style", values=("rectangular_pull",)),
            ),
        ),
        RigidMount(
            name="right-knob-mounted-to-door",
            parent_part="right_door",
            parent_element="right_door_panel",
            child_part="right_door",
            child_element="right_handle",
            active_when=(
                ActiveWhen(factor="facade_layout", values=("double_door", "mixed_drawer_doors")),
                ActiveWhen(factor="handle_style", values=("round_knob",)),
            ),
        ),
        RigidMount(
            name="right-pull-lower-root-mounted",
            parent_part="right_door",
            parent_element="right_door_panel",
            child_part="right_door",
            child_element="right_handle_lower_root",
            active_when=(
                ActiveWhen(factor="facade_layout", values=("double_door", "mixed_drawer_doors")),
                ActiveWhen(factor="handle_style", values=("rectangular_pull",)),
            ),
        ),
        RigidMount(
            name="right-pull-upper-root-mounted",
            parent_part="right_door",
            parent_element="right_door_panel",
            child_part="right_door",
            child_element="right_handle_upper_root",
            active_when=(
                ActiveWhen(factor="facade_layout", values=("double_door", "mixed_drawer_doors")),
                ActiveWhen(factor="handle_style", values=("rectangular_pull",)),
            ),
        ),
        RigidMount(
            name="drawer-knob-mounted-to-front",
            parent_part="top_drawer",
            parent_element="drawer_front",
            child_part="top_drawer",
            child_element="drawer_handle",
            active_when=(
                ActiveWhen(factor="facade_layout", values=("mixed_drawer_doors",)),
                ActiveWhen(factor="handle_style", values=("round_knob",)),
            ),
        ),
        RigidMount(
            name="drawer-pull-left-root-mounted",
            parent_part="top_drawer",
            parent_element="drawer_front",
            child_part="top_drawer",
            child_element="drawer_handle_left_root",
            active_when=(
                ActiveWhen(factor="facade_layout", values=("mixed_drawer_doors",)),
                ActiveWhen(factor="handle_style", values=("rectangular_pull",)),
            ),
        ),
        RigidMount(
            name="drawer-pull-right-root-mounted",
            parent_part="top_drawer",
            parent_element="drawer_front",
            child_part="top_drawer",
            child_element="drawer_handle_right_root",
            active_when=(
                ActiveWhen(factor="facade_layout", values=("mixed_drawer_doors",)),
                ActiveWhen(factor="handle_style", values=("rectangular_pull",)),
            ),
        ),
        JointMount(
            name="single-door-hinged-to-cabinet",
            joint="cabinet_to_single_door",
            parent_part="cabinet",
            child_part="single_door",
            allowed_joint_types=("revolute",),
            active_when=(ActiveWhen(factor="facade_layout", values=("single_door",)),),
        ),
        JointMount(
            name="left-door-hinged-to-cabinet",
            joint="cabinet_to_left_door",
            parent_part="cabinet",
            child_part="left_door",
            allowed_joint_types=("revolute",),
            active_when=(
                ActiveWhen(factor="facade_layout", values=("double_door", "mixed_drawer_doors")),
            ),
        ),
        JointMount(
            name="right-door-hinged-to-cabinet",
            joint="cabinet_to_right_door",
            parent_part="cabinet",
            child_part="right_door",
            allowed_joint_types=("revolute",),
            active_when=(
                ActiveWhen(factor="facade_layout", values=("double_door", "mixed_drawer_doors")),
            ),
        ),
        JointMount(
            name="top-drawer-guided-by-cabinet",
            joint="cabinet_to_top_drawer",
            parent_part="cabinet",
            child_part="top_drawer",
            allowed_joint_types=("prismatic",),
            active_when=(ActiveWhen(factor="facade_layout", values=("mixed_drawer_doors",)),),
        ),
    ),
    population_checks=(
        PopulationCheck(
            name="covers-facade-layouts",
            predicate=lambda s: _covers_choices(
                s, "facade_layout", {"single_door", "double_door", "mixed_drawer_doors"}
            ),
            message="Exercise single, paired, and mixed drawer-over-door facades.",
        ),
        PopulationCheck(
            name="covers-door-profiles",
            predicate=lambda s: _covers_choices(s, "door_profile", {"slab", "recessed_panel"}),
            message="Exercise both slab and recessed-panel door faces.",
        ),
        PopulationCheck(
            name="covers-base-constructions",
            predicate=lambda s: _covers_choices(s, "base_style", {"flush", "recessed_plinth"}),
            message="Exercise both support constructions.",
        ),
        PopulationCheck(
            name="covers-handle-profiles",
            predicate=lambda s: _covers_choices(
                s, "handle_style", {"round_knob", "rectangular_pull"}
            ),
            message="Exercise knob and pull handles.",
        ),
        PopulationCheck(
            name="covers-height-envelope",
            predicate=lambda s: _covers_bounds(s, "overall_height", low=0.5001, high=1.8999),
            message="Reach compact and tall cabinet heights.",
        ),
        PopulationCheck(
            name="covers-depth-envelope",
            predicate=lambda s: _covers_bounds(s, "overall_depth", low=0.3001, high=0.5999),
            message="Reach shallow and deep cabinet depths.",
        ),
        PopulationCheck(
            name="covers-shelf-count-envelope",
            predicate=lambda s: (
                min(int(p["shelf_count"]) for p in s) == 1
                and max(int(p["shelf_count"]) for p in s) == 5
            ),
            message="Exercise one- through five-shelf height-appropriate interiors.",
        ),
    ),
    build=build_model,
    tests=run_tests,
    task_requirements=(
        "Every cabinet must have a closed-back carcass with a front-accessible interior.",
        "Every shelf must remain permanently mounted along its full rear edge.",
        "Every door must remain attached by an outward-opening revolute hinge and move without volumetric collision.",
        "The mixed facade must retain an outward-sliding box drawer above its hinged doors.",
        "Every active knob or pull root must have a finite face directly seated on its front.",
    ),
    tags=("cabinet", "storage", "freestanding", "hinged_doors", "shelved"),
)
