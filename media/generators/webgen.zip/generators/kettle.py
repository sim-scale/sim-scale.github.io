from __future__ import annotations

import math
from typing import Any, Mapping, Sequence

import manifold3d
import numpy as np

from assetengine import (
    ActiveWhen,
    Derived,
    GeneratorDesign,
    GeneratorSpec,
    JointMount,
    PopulationCheck,
    RelativeUniformFloat,
    RigidMount,
    SupportContact,
    UniformChoice,
    UniformFloat,
)
from assetengine.articraft import (
    ArticulatedObject,
    ArticulationType,
    CylinderGeometry,
    LatheGeometry,
    LoftGeometry,
    MeshGeometry,
    MotionLimits,
    Origin,
    TestContext,
    mesh_from_geometry,
)

N = 48
P = 16
S = 18
STOCK = 0.020


def _solid(g: MeshGeometry, label: str) -> manifold3d.Manifold:
    result = manifold3d.Manifold(
        manifold3d.Mesh(np.asarray(g.vertices, np.float32), np.asarray(g.faces, np.uint32))
    )
    if result.status() != manifold3d.Error.NoError:
        raise ValueError(f"invalid {label} solid")
    return result


def _mesh(solid: manifold3d.Manifold) -> MeshGeometry:
    data = solid.to_mesh()
    return MeshGeometry(
        vertices=[tuple(float(v) for v in row[:3]) for row in data.vert_properties],
        faces=[tuple(int(v) for v in row) for row in data.tri_verts],
    )


def _subtract(a: MeshGeometry, b: MeshGeometry, label: str) -> MeshGeometry:
    result = _solid(a, label) - _solid(b, f"{label} cutter")
    if result.is_empty() or result.status() != manifold3d.Error.NoError:
        raise ValueError(f"failed {label} subtraction")
    return _mesh(result)


def _trim(a: MeshGeometry, cutter: MeshGeometry, label: str) -> MeshGeometry:
    source, filled = _solid(a, label), _solid(cutter, "body envelope")
    pieces = list((source - filled).decompose())
    if not pieces:
        raise ValueError(f"body envelope removed {label}")
    return _mesh(max(pieces, key=lambda piece: abs(float(piece.volume()))))


def _radius(p: Mapping[str, Any], f: float) -> float:
    r = 0.5 * float(p["body_diameter"])
    top = float(p["top_radius_ratio"]) * r
    if p["construction"] == "electric":
        return 0.93 * r + (top - 0.93 * r) * f
    if f <= 0.48:
        return 0.82 * r + 0.18 * r * math.sin(math.pi * f / 0.96)
    u = (f - 0.48) / 0.52
    return r + (top - r) * (0.5 - 0.5 * math.cos(math.pi * u))


def _body(p: Mapping[str, Any]) -> tuple[MeshGeometry, MeshGeometry]:
    h, wall, floor = (float(p[k]) for k in ("body_height", "wall_thickness", "floor_thickness"))
    outer = [(0.0, 0.0)] + [(_radius(p, i / P), h * i / P) for i in range(P + 1)]
    filled = LatheGeometry([*outer, (0.0, h)], segments=N, closed=True)
    profile = list(outer) + [(_radius(p, 1.0) - wall, h)]
    profile += [
        (max(0.001, _radius(p, i / P) - wall), floor + (h - floor) * i / P)
        for i in range(P - 1, -1, -1)
    ]
    profile.append((0.0, floor))
    return LatheGeometry(profile, segments=N, closed=True), filled


def _bezier(a, b, c, d, t: float) -> tuple[float, float, float]:
    u = 1.0 - t
    return tuple(
        u**3 * a[i] + 3 * u * u * t * b[i] + 3 * u * t * t * c[i] + t**3 * d[i] for i in range(3)
    )


def _ring(center, tangent, radius: float):
    tx, _, tz = tangent
    length = math.hypot(tx, tz)
    tx, tz = tx / length, tz / length
    nx, nz = -tz, tx
    return [
        (
            center[0] + radius * nx * math.cos(a),
            center[1] + radius * math.sin(a),
            center[2] + radius * nz * math.cos(a),
        )
        for a in (2 * math.pi * i / S for i in range(S))
    ]


def _sweep(points, radii) -> MeshGeometry:
    sections = []
    for i, point in enumerate(points):
        before, after = points[max(0, i - 1)], points[min(len(points) - 1, i + 1)]
        tangent = tuple(after[j] - before[j] for j in range(3))
        sections.append(_ring(point, tangent, radii[i]))
    vertices = [vertex for section in sections for vertex in section]
    faces: list[tuple[int, int, int]] = []
    for section_index in range(len(sections) - 1):
        offset = section_index * S
        next_offset = (section_index + 1) * S
        for index in range(S):
            following = (index + 1) % S
            a, b = offset + index, offset + following
            c, d = next_offset + following, next_offset + index
            faces.extend(((a, c, b), (a, d, c)))
    start_center = len(vertices)
    vertices.append(tuple(float(sum(v[a] for v in sections[0]) / S) for a in range(3)))
    end_center = len(vertices)
    vertices.append(tuple(float(sum(v[a] for v in sections[-1]) / S) for a in range(3)))
    end_offset = (len(sections) - 1) * S
    for index in range(S):
        following = (index + 1) % S
        faces.append((start_center, index, following))
        faces.append((end_center, end_offset + following, end_offset + index))
    return MeshGeometry(vertices=vertices, faces=faces)


def _tube(points, outer_radii, inner_radii) -> MeshGeometry:
    outer, inner = [], []
    for i, point in enumerate(points):
        before, after = points[max(0, i - 1)], points[min(len(points) - 1, i + 1)]
        tangent = tuple(after[j] - before[j] for j in range(3))
        outer.append(_ring(point, tangent, outer_radii[i]))
        inner.append(_ring(point, tangent, inner_radii[i]))
    vertices = [v for section in outer for v in section]
    inner_offset = len(vertices)
    vertices += [v for section in inner for v in section]
    faces: list[tuple[int, int, int]] = []
    for section_index in range(len(points) - 1):
        o, on = section_index * S, (section_index + 1) * S
        i, inn = inner_offset + o, inner_offset + on
        for index in range(S):
            following = (index + 1) % S
            faces.extend(
                (
                    (o + index, on + following, o + following),
                    (o + index, on + index, on + following),
                    (i + index, i + following, inn + following),
                    (i + index, inn + following, inn + index),
                )
            )
    eo, ei = (len(points) - 1) * S, inner_offset + (len(points) - 1) * S
    for index in range(S):
        following = (index + 1) % S
        faces.extend(
            (
                (index, following, inner_offset + following),
                (index, inner_offset + following, inner_offset + index),
                (eo + index, ei + following, eo + following),
                (eo + index, ei + index, ei + following),
            )
        )
    return MeshGeometry(vertices=vertices, faces=faces)


def _spout(p: Mapping[str, Any], filled: MeshGeometry) -> tuple[MeshGeometry, MeshGeometry]:
    h = float(p["body_height"])
    f = float(p["spout_root_height_ratio"])
    length = float(p["spout_length"])
    start = (_radius(p, f) - STOCK, 0.0, h * f)
    if p["spout_profile"] == "conventional":
        angle = float(p["spout_rise_angle"])
        points = [
            (start[0] + length * t * math.cos(angle), 0.0, start[2] + length * t * math.sin(angle))
            for t in (i / P for i in range(P + 1))
        ]
    else:
        end = (start[0] + 0.72 * length, 0.0, start[2] + 0.68 * length)
        b = (start[0] + 0.34 * length, 0.0, start[2] + 0.05 * length)
        c = (start[0] + 0.50 * length, 0.0, start[2] + 0.82 * length)
        points = [_bezier(start, b, c, end, i / P) for i in range(P + 1)]
    root = 0.5 * float(p["spout_root_diameter"])
    outlet = 0.5 * float(p["spout_outlet_diameter"])
    outer_r = [root + (outlet - root) * i / P for i in range(P + 1)]
    wall = float(p["spout_wall_thickness"])
    unit0 = tuple((points[1][j] - points[0][j]) / math.dist(points[0], points[1]) for j in range(3))
    inner_r = [v - wall for v in outer_r]
    tube = _tube(points, outer_r, inner_r)
    trimmed = _trim(tube, filled, "spout")
    # The body aperture follows the actual root tangent and is smaller than the outer root,
    # leaving a finite annular mounting footprint after the spout stock is trimmed.
    aperture = (
        CylinderGeometry(min(root - wall, 0.018), 0.09, radial_segments=S, closed=True)
        .rotate_y(math.pi / 2)
        .translate(_radius(p, f) - 0.040, 0.0, h * f)
    )
    return trimmed, aperture


def _handle(p: Mapping[str, Any], filled: MeshGeometry) -> MeshGeometry:
    h, r = float(p["body_height"]), 0.5 * float(p["body_diameter"])
    clearance = float(p["handle_clearance"])
    if p["construction"] == "stovetop":
        x, z, crown = 0.60 * r, 0.70 * h, h + clearance
        a, b = (-x, 0.0, z - 0.008), (-r - 0.16 * clearance, 0.0, crown)
        c, d = (r + 0.16 * clearance, 0.0, crown), (x, 0.0, z - 0.008)
    else:
        x, upper, lower = -_radius(p, 0.76), 0.82 * h, 0.28 * h
        a, b = (x + STOCK, 0.0, upper), (x - clearance, 0.0, upper + 0.02 * h)
        c, d = (x - clearance, 0.0, lower - 0.02 * h), (x + STOCK, 0.0, lower)
    points = [_bezier(a, b, c, d, i / P) for i in range(P + 1)]
    geometry = _sweep(points, [0.5 * float(p["handle_member_diameter"])] * len(points))
    geometry.scale(1.0, float(p["handle_section_aspect"]), 1.0)
    if p["construction"] == "stovetop":
        geometry.rotate_z(0.5 * math.pi)
    return _trim(geometry, filled, "handle")


def _lid(p: Mapping[str, Any]) -> MeshGeometry:
    h, wall, dome = (float(p[k]) for k in ("body_height", "wall_thickness", "lid_dome_height"))
    radius = _radius(p, 1.0) - 0.25 * wall
    profile = [(0.0, h), (radius, h)] + [
        (radius * f, h + dome * math.sqrt(max(0.0, 1.0 - f * f)))
        for f in (i / P for i in range(P, -1, -1))
    ]
    return LatheGeometry(profile, segments=N, closed=True)


def build_model(p: Mapping[str, Any]) -> ArticulatedObject:
    model = ArticulatedObject(name="kettle")
    material = model.material("neutral", rgba=(0.48, 0.50, 0.52, 1.0))
    part = model.part("kettle")
    body, filled = _body(p)
    spout, aperture = _spout(p, filled)
    body = _subtract(body, aperture, "body pour aperture")
    for name, geometry in (("body_shell", body), ("spout", spout), ("handle", _handle(p, filled))):
        part.visual(mesh_from_geometry(geometry, name), material=material, name=name)
    h, dome = float(p["body_height"]), float(p["lid_dome_height"])
    knob_h = float(p["lid_knob_height"])
    knob = CylinderGeometry(
        0.5 * float(p["lid_knob_diameter"]), knob_h, radial_segments=S, closed=True
    )
    knob.translate(0.0, 0.0, h + dome + 0.5 * knob_h)
    if p["construction"] == "electric":
        hinge = (-_radius(p, 1.0), 0.0, h)
        lid_part = model.part("lid")
        lid_part.visual(
            mesh_from_geometry(_lid(p).translate(-hinge[0], 0.0, -hinge[2]), "lid"),
            material=material,
            name="lid",
        )
        lid_part.visual(
            mesh_from_geometry(knob.translate(-hinge[0], 0.0, -hinge[2]), "lid_knob"),
            material=material,
            name="lid_knob",
        )
        model.articulation(
            "body_to_hinged_lid",
            ArticulationType.REVOLUTE,
            parent=part,
            child=lid_part,
            origin=Origin(xyz=hinge),
            # The lid lies toward +x from its back-edge hinge, so it opens upward about -y.
            axis=(0.0, -1.0, 0.0),
            motion_limits=MotionLimits(lower=0.0, upper=math.radians(75.0)),
        )
    else:
        part.visual(mesh_from_geometry(_lid(p), "lid"), material=material, name="lid")
        part.visual(mesh_from_geometry(knob, "lid_knob"), material=material, name="lid_knob")
    if p["construction"] == "electric":
        bh = float(p["electric_base_height"])
        base = CylinderGeometry(
            0.5 * float(p["electric_base_diameter"]), bh, radial_segments=N, closed=True
        )
        base.translate(0.0, 0.0, -0.5 * bh)
        base_part = model.part("power_base")
        base_part.visual(
            mesh_from_geometry(base, "electric_base"), material=material, name="electric_base"
        )
        model.articulation(
            "power_base_to_lift_off_vessel",
            ArticulationType.FLOATING,
            parent=base_part,
            child=part,
        )
    return model


def run_tests(model: ArticulatedObject, p: Mapping[str, Any]):
    ctx = TestContext(model)
    ctx.check_model_valid()
    v = lambda k: float(p[k])
    ctx.check("positive-water-cavity", v("body_height") > 3 * v("floor_thickness"))
    ctx.check(
        "open-spout-bore",
        min(v("spout_root_diameter"), v("spout_outlet_diameter")) > 2 * v("spout_wall_thickness"),
    )
    ctx.check("bounded-handle-opening", v("handle_clearance") > v("handle_member_diameter"))
    ctx.check(
        "lid-has-rim-bearing",
        _radius(p, 1.0) - 0.25 * v("wall_thickness") > _radius(p, 1.0) - v("wall_thickness"),
    )
    return ctx.report()


def _choices(samples: Sequence[Mapping[str, Any]], key: str, needed: set[str]) -> bool:
    return {str(s[key]) for s in samples} >= needed


GENERATOR = GeneratorSpec(
    name="kettle",
    category="kettle",
    description="Ordinary household stovetop and electric kettles with functional openings and mounts.",
    design=GeneratorDesign(
        coverage=(
            "Rounded stovetop kettles span 0.16-0.22 m diameter and 0.10-0.16 m vessel height; tall electric jugs span 0.14-0.19 m diameter and 0.17-0.26 m height. Both include conventional tapered and gooseneck spouts, fitted lids, and 14-25 mm handle stock. Travel, collapsible, samovar, novelty, and commercial urn forms are excluded."
        ),
        factors=(
            "Construction conditions body envelopes and handle topology. Diameter and height remain independent within each regime; top radius and spout-root height are body-relative. Spout profile conditions independent length and outlet ranges. Wall, floor, lid, knob, handle section, and handle clearance retain independent ordinary targets. Every stochastic factor is uniform."
        ),
        components=(
            "A hollow rounded or tapered body supports a smooth tapered hollow spout, an overhead stovetop arch or electric side D-handle, shallow domed lid and knob, plus an electric-only base. Spout path, taper, outlet, handle clearance and stock, body proportion, lid dome, and base dimensions vary appreciably; switches, whistles, markings, and finishes remain incidental."
        ),
        physics_and_task=(
            "The hollow body is the root. Fixed inward stock on the spout and both handle roots is trimmed against a filled body envelope, leaving finite seated interfaces without connector pads. The lid rests on the annular rim; its knob is rigidly mounted. The electric base is mounted only in that branch. The body aperture joins the spout bore as real pouring free space; no robot-specific clearance is inferred."
        ),
    ),
    factors=(
        UniformChoice(
            name="construction",
            choices=("stovetop", "electric"),
            description="Rounded stovetop or tall electric-jug construction.",
        ),
        UniformFloat(
            name="stovetop_body_diameter",
            low=0.16,
            high=0.22,
            active_when=(ActiveWhen(factor="construction", values=("stovetop",)),),
            description="Maximum stovetop body diameter.",
            unit="m",
        ),
        UniformFloat(
            name="electric_body_diameter",
            low=0.14,
            high=0.19,
            active_when=(ActiveWhen(factor="construction", values=("electric",)),),
            description="Maximum electric body diameter.",
            unit="m",
        ),
        Derived(
            name="body_diameter",
            derive=lambda p: p[f"{p['construction']}_body_diameter"],
            depends_on=("construction", "stovetop_body_diameter", "electric_body_diameter"),
            description="Construction-resolved vessel diameter.",
            unit="m",
        ),
        UniformFloat(
            name="stovetop_body_height",
            low=0.10,
            high=0.16,
            active_when=(ActiveWhen(factor="construction", values=("stovetop",)),),
            description="Independent stovetop vessel height.",
            unit="m",
        ),
        UniformFloat(
            name="electric_body_height",
            low=0.17,
            high=0.26,
            active_when=(ActiveWhen(factor="construction", values=("electric",)),),
            description="Independent electric vessel height.",
            unit="m",
        ),
        Derived(
            name="body_height",
            derive=lambda p: p[f"{p['construction']}_body_height"],
            depends_on=("construction", "stovetop_body_height", "electric_body_height"),
            description="Construction-resolved vessel height.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="top_radius",
            reference="body_diameter",
            ratio_low=0.29,
            ratio_high=0.43,
            description="Outer top radius correlated with body diameter.",
            unit="m",
        ),
        Derived(
            name="top_radius_ratio",
            derive=lambda p: p["top_radius"] / (0.5 * p["body_diameter"]),
            depends_on=("top_radius", "body_diameter"),
            description="Top radius over maximum body radius.",
            unit="ratio",
        ),
        UniformFloat(
            name="wall_thickness",
            low=0.002,
            high=0.004,
            description="Vessel shell thickness.",
            unit="m",
        ),
        UniformFloat(
            name="floor_thickness",
            low=0.003,
            high=0.007,
            description="Vessel floor thickness.",
            unit="m",
        ),
        UniformChoice(
            name="spout_profile",
            choices=("conventional", "gooseneck"),
            description="Short tapered or long curved spout path.",
        ),
        UniformFloat(
            name="conventional_spout_length",
            low=0.09,
            high=0.15,
            active_when=(ActiveWhen(factor="spout_profile", values=("conventional",)),),
            description="Conventional-spout centerline length.",
            unit="m",
        ),
        UniformFloat(
            name="gooseneck_spout_length",
            low=0.16,
            high=0.24,
            active_when=(ActiveWhen(factor="spout_profile", values=("gooseneck",)),),
            description="Gooseneck centerline scale.",
            unit="m",
        ),
        Derived(
            name="spout_length",
            derive=lambda p: p[f"{p['spout_profile']}_spout_length"],
            depends_on=("spout_profile", "conventional_spout_length", "gooseneck_spout_length"),
            description="Profile-resolved spout length.",
            unit="m",
        ),
        UniformFloat(
            name="conventional_outlet_diameter",
            low=0.030,
            high=0.052,
            active_when=(ActiveWhen(factor="spout_profile", values=("conventional",)),),
            description="Conventional outlet diameter.",
            unit="m",
        ),
        UniformFloat(
            name="gooseneck_outlet_diameter",
            low=0.010,
            high=0.018,
            active_when=(ActiveWhen(factor="spout_profile", values=("gooseneck",)),),
            description="Gooseneck outlet diameter.",
            unit="m",
        ),
        Derived(
            name="spout_outlet_diameter",
            derive=lambda p: p[f"{p['spout_profile']}_outlet_diameter"],
            depends_on=(
                "spout_profile",
                "conventional_outlet_diameter",
                "gooseneck_outlet_diameter",
            ),
            description="Profile-resolved outlet diameter.",
            unit="m",
        ),
        UniformFloat(
            name="spout_root_diameter",
            low=0.040,
            high=0.065,
            description="Outer spout root diameter.",
            unit="m",
        ),
        UniformFloat(
            name="spout_wall_thickness",
            low=0.002,
            high=0.0035,
            description="Spout wall thickness.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="spout_root_height",
            reference="body_height",
            ratio_low=0.42,
            ratio_high=0.68,
            description="Body-relative spout center height.",
            unit="m",
        ),
        Derived(
            name="spout_root_height_ratio",
            derive=lambda p: p["spout_root_height"] / p["body_height"],
            depends_on=("spout_root_height", "body_height"),
            description="Spout height fraction.",
            unit="ratio",
        ),
        UniformFloat(
            name="spout_rise_angle",
            low=math.radians(22),
            high=math.radians(48),
            description="Initial spout rise angle.",
            unit="rad",
        ),
        UniformFloat(
            name="handle_member_diameter",
            low=0.014,
            high=0.025,
            description="Circular handle-stock diameter.",
            unit="m",
        ),
        UniformFloat(
            name="handle_section_aspect",
            low=1.0,
            high=2.4,
            description="Width-to-depth aspect of round through broad oval molded handle stock.",
            unit="ratio",
        ),
        UniformFloat(
            name="handle_clearance",
            low=0.055,
            high=0.095,
            description="Clear offset enclosed by the handle path.",
            unit="m",
        ),
        UniformFloat(
            name="lid_dome_height", low=0.006, high=0.022, description="Lid dome height.", unit="m"
        ),
        UniformFloat(
            name="lid_knob_diameter",
            low=0.020,
            high=0.040,
            description="Lid-knob diameter.",
            unit="m",
        ),
        UniformFloat(
            name="lid_knob_height", low=0.012, high=0.028, description="Lid-knob height.", unit="m"
        ),
        RelativeUniformFloat(
            name="electric_base_diameter",
            reference="body_diameter",
            ratio_low=0.82,
            ratio_high=1.02,
            active_when=(ActiveWhen(factor="construction", values=("electric",)),),
            description="Electric-base diameter relative to body.",
            unit="m",
        ),
        UniformFloat(
            name="electric_base_height",
            low=0.012,
            high=0.028,
            active_when=(ActiveWhen(factor="construction", values=("electric",)),),
            description="Electric-base height.",
            unit="m",
        ),
    ),
    relationships=(
        RigidMount(
            name="spout-mounted-to-body",
            parent_part="kettle",
            parent_element="body_shell",
            child_part="kettle",
            child_element="spout",
        ),
        RigidMount(
            name="handle-mounted-to-body",
            parent_part="kettle",
            parent_element="body_shell",
            child_part="kettle",
            child_element="handle",
            contact_tolerance=0.003,
        ),
        SupportContact(
            name="lid-rests-on-rim",
            supporting_part="kettle",
            supporting_element="body_shell",
            supported_part="kettle",
            supported_element="lid",
            active_when=(ActiveWhen(factor="construction", values=("stovetop",)),),
        ),
        JointMount(
            name="electric-lid-hinged-to-body",
            joint="body_to_hinged_lid",
            parent_part="kettle",
            child_part="lid",
            allowed_joint_types=("revolute",),
            active_when=(ActiveWhen(factor="construction", values=("electric",)),),
        ),
        RigidMount(
            name="knob-mounted-to-lid",
            parent_part="lid",
            parent_element="lid",
            child_part="lid",
            child_element="lid_knob",
            active_when=(ActiveWhen(factor="construction", values=("electric",)),),
        ),
        RigidMount(
            name="stovetop-knob-mounted-to-lid",
            parent_part="kettle",
            parent_element="lid",
            child_part="kettle",
            child_element="lid_knob",
            active_when=(ActiveWhen(factor="construction", values=("stovetop",)),),
        ),
        SupportContact(
            name="electric-vessel-rests-on-power-base",
            supporting_part="power_base",
            supporting_element="electric_base",
            supported_part="kettle",
            supported_element="body_shell",
            active_when=(ActiveWhen(factor="construction", values=("electric",)),),
        ),
    ),
    population_checks=(
        PopulationCheck(
            name="covers-constructions",
            predicate=lambda s: _choices(s, "construction", {"stovetop", "electric"}),
            message="Exercise both construction regimes.",
        ),
        PopulationCheck(
            name="covers-spout-profiles",
            predicate=lambda s: _choices(s, "spout_profile", {"conventional", "gooseneck"}),
            message="Exercise both common spout profiles.",
        ),
    ),
    build=build_model,
    tests=run_tests,
    task_requirements=(
        "Every kettle has a hollow water vessel with an open top beneath the removable lid.",
        "The body aperture and hollow spout form an unobstructed route to the outlet.",
        "The carrying handle retains a bounded opening and two seated body roots.",
        "The lid rests on the rim and its lifting knob remains permanently mounted.",
        "Electric constructions include a mounted base; stovetop constructions do not.",
    ),
    tags=("kettle", "stovetop", "electric", "gooseneck", "pouring vessel"),
)
