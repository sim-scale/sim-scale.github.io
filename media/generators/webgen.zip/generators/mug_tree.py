from __future__ import annotations

import math
from typing import Any, Mapping, Sequence

import manifold3d
import numpy as np

from assetengine import (
    Derived,
    GeneratorDesign,
    GeneratorSpec,
    PopulationCheck,
    RigidMount,
    UniformChoice,
    UniformFloat,
)
from assetengine.articraft import (
    ArticulatedObject,
    BoxGeometry,
    CylinderGeometry,
    MeshGeometry,
    Origin,
    TestContext,
    mesh_from_geometry,
)

_RADIAL_SEGMENTS = 48
_POST_MOUNT_STOCK = 0.008
_BRANCH_MOUNT_STOCK = 0.008
_BRANCH_ROOT_SEAT_DEPTH = 0.001
_FINAL_OVERLAP_TOLERANCE = 1e-8
_LAYER_COUNT = 3
_BRANCHES_PER_LAYER = 2
_BRANCH_COUNT = _LAYER_COUNT * _BRANCHES_PER_LAYER
_LAYER_ROTATION = 0.5 * math.pi
_OPPOSITE_ROTATION = math.pi


def _as_manifold(geometry: MeshGeometry, *, context: str) -> manifold3d.Manifold:
    mesh = manifold3d.Mesh(
        np.asarray(geometry.vertices, dtype=np.float32),
        np.asarray(geometry.faces, dtype=np.uint32),
    )
    solid = manifold3d.Manifold(mesh)
    if solid.status() != manifold3d.Error.NoError:
        raise ValueError(f"{context} is not a valid manifold solid")
    return solid


def _mesh_from_manifold(solid: manifold3d.Manifold) -> MeshGeometry:
    output = solid.to_mesh()
    return MeshGeometry(
        vertices=[tuple(float(value) for value in row[:3]) for row in output.vert_properties],
        faces=[tuple(int(value) for value in row) for row in output.tri_verts],
    )


def _weld_close_vertices(geometry: MeshGeometry, tolerance: float = 1e-6) -> MeshGeometry:
    """Collapse Boolean seam vertices that differ only below OBJ export precision."""
    canonical: list[tuple[float, float, float]] = []
    remap: list[int] = []
    tolerance_squared = tolerance * tolerance
    for vertex in geometry.vertices:
        point = tuple(float(value) for value in vertex)
        match = next(
            (
                index
                for index, candidate in enumerate(canonical)
                if sum((point[axis] - candidate[axis]) ** 2 for axis in range(3))
                <= tolerance_squared
            ),
            None,
        )
        if match is None:
            match = len(canonical)
            canonical.append(point)
        remap.append(match)

    faces: list[tuple[int, int, int]] = []
    seen_faces: set[tuple[int, int, int]] = set()
    for face in geometry.faces:
        welded = tuple(remap[int(index)] for index in face)
        if len(set(welded)) != 3:
            continue
        identity = tuple(sorted(welded))
        if identity in seen_faces:
            continue
        seen_faces.add(identity)
        faces.append(welded)
    return MeshGeometry(vertices=canonical, faces=faces)


def _to_parent_frame(geometry: MeshGeometry, origin: Origin) -> MeshGeometry:
    roll, pitch, yaw = origin.rpy
    return (
        geometry.copy()
        .rotate_x(float(roll))
        .rotate_y(float(pitch))
        .rotate_z(float(yaw))
        .translate(*origin.xyz)
    )


def _to_child_frame(geometry: MeshGeometry, origin: Origin) -> MeshGeometry:
    roll, pitch, yaw = origin.rpy
    return (
        geometry.copy()
        .translate(*(-float(value) for value in origin.xyz))
        .rotate_z(-float(yaw))
        .rotate_y(-float(pitch))
        .rotate_x(-float(roll))
    )


def _trim_mounted_child(
    *,
    parent_geometry: MeshGeometry,
    extended_child_local: MeshGeometry,
    parent_from_child: Origin,
    keep_axis: int,
    minimum_intersection_volume: float,
    component_name: str,
) -> MeshGeometry:
    """Remove fixed inward root stock while retaining the complete exterior child."""
    positioned_child = _to_parent_frame(extended_child_local, parent_from_child)
    child_solid = _as_manifold(positioned_child, context=f"extended {component_name}")
    parent_solid = _as_manifold(parent_geometry, context=f"{component_name} parent")
    pretrim_intersection = float((child_solid ^ parent_solid).volume())
    if pretrim_intersection < minimum_intersection_volume:
        raise ValueError(f"extended {component_name} stock did not positively intersect its parent")

    components = list((child_solid - parent_solid).decompose())
    if not components:
        raise ValueError(f"parent trimming removed the complete {component_name}")

    exterior = max(
        components,
        key=lambda component: max(
            vertex[keep_axis]
            for vertex in _to_child_frame(
                _mesh_from_manifold(component), parent_from_child
            ).vertices
        ),
    )
    exterior_parent = _mesh_from_manifold(exterior)
    final_overlap = float(
        (_as_manifold(exterior_parent, context=f"trimmed {component_name}") ^ parent_solid).volume()
    )
    if final_overlap > _FINAL_OVERLAP_TOLERANCE:
        raise ValueError(f"trimmed {component_name} retains parent penetration")
    child_local = _weld_close_vertices(_to_child_frame(exterior_parent, parent_from_child))
    return _mesh_from_manifold(
        _as_manifold(child_local, context=f"cleaned trimmed {component_name}")
    )


def _base_geometry(parameters: Mapping[str, Any]) -> MeshGeometry:
    diameter = float(parameters["base_diameter"])
    thickness = float(parameters["base_thickness"])
    if parameters["base_footprint"] == "round":
        return CylinderGeometry(
            0.5 * diameter,
            thickness,
            radial_segments=_RADIAL_SEGMENTS,
            closed=True,
        ).translate(0.0, 0.0, 0.5 * thickness)
    square = BoxGeometry((diameter, diameter, thickness)).translate(0.0, 0.0, 0.5 * thickness)
    # Reverse the primitive's inward triangle order before Boolean mounting and compilation.
    square.faces = [(a, c, b) for a, b, c in square.faces]
    return square


def _extended_post_geometry(parameters: Mapping[str, Any]) -> MeshGeometry:
    height = float(parameters["post_height_above_base"])
    return CylinderGeometry(
        0.5 * float(parameters["post_diameter"]),
        height + _POST_MOUNT_STOCK,
        radial_segments=_RADIAL_SEGMENTS,
        closed=True,
    ).translate(0.0, 0.0, 0.5 * (height - _POST_MOUNT_STOCK))


def _extended_branch_geometry(parameters: Mapping[str, Any]) -> MeshGeometry:
    exposed_length = float(parameters["branch_length"])
    outward_local_length = exposed_length + _BRANCH_ROOT_SEAT_DEPTH
    total_length = outward_local_length + _BRANCH_MOUNT_STOCK
    return (
        CylinderGeometry(
            0.5 * float(parameters["branch_diameter"]),
            total_length,
            radial_segments=_RADIAL_SEGMENTS,
            closed=True,
        )
        .rotate_y(0.5 * math.pi)
        .translate(0.5 * (outward_local_length - _BRANCH_MOUNT_STOCK), 0.0, 0.0)
    )


def _branch_name(layer_index: int, branch_index: int) -> str:
    side = "a" if branch_index == 0 else "b"
    return f"branch_layer_{layer_index + 1}_{side}"


def build_model(parameters: Mapping[str, Any]) -> ArticulatedObject:
    model = ArticulatedObject(name="ordinary_household_mug_tree")
    neutral = model.material("neutral", rgba=(0.48, 0.49, 0.50, 1.0))
    stand = model.part("stand")

    base_geometry = _base_geometry(parameters)
    stand.visual(
        mesh_from_geometry(base_geometry, "base"),
        origin=Origin(),
        material=neutral,
        name="base",
    )

    post_origin = Origin(xyz=(0.0, 0.0, float(parameters["base_thickness"])))
    post_area = math.pi * (0.5 * float(parameters["post_diameter"])) ** 2
    post_local = _trim_mounted_child(
        parent_geometry=base_geometry,
        extended_child_local=_extended_post_geometry(parameters),
        parent_from_child=post_origin,
        keep_axis=2,
        minimum_intersection_volume=0.25 * post_area * _POST_MOUNT_STOCK,
        component_name="central post",
    )
    stand.visual(
        mesh_from_geometry(post_local, "central_post"),
        origin=post_origin,
        material=neutral,
        name="central_post",
    )
    post_world = _to_parent_frame(post_local, post_origin)

    branch_radius = 0.5 * float(parameters["branch_diameter"])
    branch_witness = max(
        1e-10,
        0.03 * math.pi * branch_radius**2 * _BRANCH_MOUNT_STOCK,
    )
    branch_mount_radius = 0.5 * float(parameters["post_diameter"]) - _BRANCH_ROOT_SEAT_DEPTH
    rise = float(parameters["branch_rise_angle"])
    base_top = float(parameters["base_thickness"])
    first_height = float(parameters["first_layer_height_above_base"])
    spacing = float(parameters["layer_spacing"])

    for layer_index in range(_LAYER_COUNT):
        layer_yaw = layer_index * _LAYER_ROTATION
        layer_z = base_top + first_height + layer_index * spacing
        for branch_index in range(_BRANCHES_PER_LAYER):
            yaw = layer_yaw + branch_index * _OPPOSITE_ROTATION
            branch_origin = Origin(
                xyz=(
                    branch_mount_radius * math.cos(yaw),
                    branch_mount_radius * math.sin(yaw),
                    layer_z,
                ),
                rpy=(0.0, -rise, yaw),
            )
            name = _branch_name(layer_index, branch_index)
            branch_local = _trim_mounted_child(
                parent_geometry=post_world,
                extended_child_local=_extended_branch_geometry(parameters),
                parent_from_child=branch_origin,
                keep_axis=0,
                minimum_intersection_volume=branch_witness,
                component_name=name.replace("_", " "),
            )
            stand.visual(
                mesh_from_geometry(branch_local, name),
                origin=branch_origin,
                material=neutral,
                name=name,
            )

    return model


def run_tests(model: ArticulatedObject, parameters: Mapping[str, Any]):
    value = lambda name: float(parameters[name])
    ctx = TestContext(model)
    checks = (
        ("exactly-three-branch-layers", int(parameters["layer_count"]) == 3),
        ("exactly-two-branches-per-layer", int(parameters["branches_per_layer"]) == 2),
        ("exactly-six-branches-total", int(parameters["branch_count"]) == 6),
        (
            "within-layer-branches-are-opposite",
            abs(value("within_layer_separation_degrees") - 180.0) <= 1e-9,
        ),
        (
            "adjacent-layers-rotate-ninety-degrees",
            abs(value("adjacent_layer_rotation_degrees") - 90.0) <= 1e-9,
        ),
        (
            "branch-rods-stay-slender",
            0.008 <= value("branch_diameter") <= 0.010,
        ),
        (
            "branch-rods-remain-no-wider-than-post-radius",
            value("branch_diameter") <= 0.5 * value("post_diameter"),
        ),
        (
            "post-height-follows-all-three-layers-and-top-clearance",
            abs(
                value("post_height_above_base")
                - value("first_layer_height_above_base")
                - 2.0 * value("layer_spacing")
                - value("top_clearance_above_top_layer")
            )
            <= 1e-9,
        ),
        (
            "base-presents-flat-tabletop-contact",
            value("base_diameter") > value("post_diameter")
            and value("base_thickness") > _POST_MOUNT_STOCK,
        ),
        (
            "branch-stock-stays-within-central-post",
            _BRANCH_MOUNT_STOCK < 0.5 * value("post_diameter"),
        ),
    )
    for name, passed in checks:
        ctx.check(name, passed)
    return ctx.report()


def _covers_bounds(
    samples: Sequence[Mapping[str, Any]],
    factor: str,
    low: float,
    high: float,
) -> bool:
    values = [float(sample[factor]) for sample in samples]
    tolerance = 0.02 * (high - low)
    return min(values) <= low + tolerance and max(values) >= high - tolerance


def _bounds_check(name: str, factor: str, low: float, high: float) -> PopulationCheck:
    return PopulationCheck(
        name=name,
        predicate=lambda samples: _covers_bounds(samples, factor, low, high),
        message=f"Population must exercise both ordinary bounds of {factor}.",
    )


GENERATOR = GeneratorSpec(
    name="mug_tree_1",
    category="mug_tree_1",
    description=(
        "An undecorated freestanding household mug tree with exactly three branch layers, "
        "two opposite branches per layer, and ninety-degree rotation between adjacent layers."
    ),
    design=GeneratorDesign(
        coverage=(
            "Covers the common compact freestanding six-mug pedestal family with round or square "
            "flat bases, a straight round post, and simple upward-sloping round branches. Overall "
            "height spans ordinary roughly 31-44 cm countertop examples. Decorative silhouettes, "
            "trays, baskets, knobs, extra hooks, mugs, and wall-mounted or carousel racks are "
            "excluded."
        ),
        factors=(
            "Base footprint, base diameter and thickness, post diameter, first-layer height, "
            "inter-layer spacing, top clearance, branch length, branch diameter, and branch rise "
            "vary uniformly over ordinary intervals. These human-scale component dimensions have "
            "overlapping ordinary ranges and remain independent; post height is the exact derived "
            "consequence of the three layer positions and top clearance. Counts and 180/90-degree "
            "rotations are fixed derived request invariants."
        ),
        components=(
            "The visible base changes between common round and square footprints and varies in "
            "diameter and thickness; the cylindrical post varies in thickness and height; all six "
            "cylindrical hanging branches share one sampled slender diameter, exposed length, and "
            "upward slope. Flat rod ends and a neutral material are incidental undecorated details."
        ),
        physics_and_task=(
            "The flat base supports the tree on a countertop. The post is permanently seated over "
            "its full circular root on the base, and each of six branches is permanently seated on "
            "the curved post. Every mount is built with fixed inward sacrificial stock, positive "
            "pre-trim intersection, and parent subtraction that leaves zero-gap finite contact. "
            "Upward-sloping 8-10 mm branches provide genuine mug-hanging members without "
            "inventing a mug-handle or robot clearance threshold."
        ),
    ),
    factors=(
        UniformChoice(
            name="base_footprint",
            choices=("round", "square"),
            description="Common undecorated footprint profile of the flat freestanding base.",
            unit="category",
        ),
        UniformFloat(
            name="base_diameter",
            low=0.130,
            high=0.200,
            description="Diameter or side length of the countertop base footprint.",
            unit="m",
        ),
        UniformFloat(
            name="base_thickness",
            low=0.014,
            high=0.030,
            description="Vertical thickness of the flat base.",
            unit="m",
        ),
        UniformFloat(
            name="post_diameter",
            low=0.020,
            high=0.030,
            description="Diameter of the straight vertical central post.",
            unit="m",
        ),
        UniformFloat(
            name="first_layer_height_above_base",
            low=0.095,
            high=0.130,
            description="Height from the base top to the centerline of the lowest branch layer.",
            unit="m",
        ),
        UniformFloat(
            name="layer_spacing",
            low=0.085,
            high=0.115,
            description="Vertical centerline spacing between adjacent branch layers.",
            unit="m",
        ),
        UniformFloat(
            name="top_clearance_above_top_layer",
            low=0.030,
            high=0.050,
            description="Post height retained above the top branch-layer centerline.",
            unit="m",
        ),
        UniformFloat(
            name="branch_length",
            low=0.070,
            high=0.100,
            description="Exposed branch-axis length measured outward from the post surface.",
            unit="m",
        ),
        UniformFloat(
            name="branch_diameter",
            low=0.008,
            high=0.010,
            description="Slender circular branch diameter suitable for ordinary mug handles.",
            unit="m",
        ),
        UniformFloat(
            name="branch_rise_angle",
            low=math.radians(12.0),
            high=math.radians(28.0),
            description="Upward pitch of every branch axis away from the central post.",
            unit="rad",
        ),
        Derived(
            name="post_height_above_base",
            derive=lambda p: (
                p["first_layer_height_above_base"]
                + 2.0 * p["layer_spacing"]
                + p["top_clearance_above_top_layer"]
            ),
            depends_on=(
                "first_layer_height_above_base",
                "layer_spacing",
                "top_clearance_above_top_layer",
            ),
            description="Exact post height required by all three layers plus top clearance.",
            unit="m",
        ),
        Derived(
            name="layer_count",
            derive=lambda _p: _LAYER_COUNT,
            description="Exact number of branch layers required by the request.",
            unit="count",
        ),
        Derived(
            name="branches_per_layer",
            derive=lambda _p: _BRANCHES_PER_LAYER,
            description="Exact number of opposite branches in every layer.",
            unit="count",
        ),
        Derived(
            name="branch_count",
            derive=lambda _p: _BRANCH_COUNT,
            description="Exact total number of hanging branches.",
            unit="count",
        ),
        Derived(
            name="within_layer_separation_degrees",
            derive=lambda _p: 180.0,
            description="Exact angular separation of the two branches within each layer.",
            unit="deg",
        ),
        Derived(
            name="adjacent_layer_rotation_degrees",
            derive=lambda _p: 90.0,
            description="Exact rotation from one branch layer to the next.",
            unit="deg",
        ),
    ),
    relationships=(
        RigidMount(
            name="central-post-mounted-to-base",
            parent_part="stand",
            parent_element="base",
            child_part="stand",
            child_element="central_post",
        ),
        *tuple(
            RigidMount(
                name=f"{_branch_name(layer_index, branch_index)}-mounted-to-post",
                parent_part="stand",
                parent_element="central_post",
                child_part="stand",
                child_element=_branch_name(layer_index, branch_index),
            )
            for layer_index in range(_LAYER_COUNT)
            for branch_index in range(_BRANCHES_PER_LAYER)
        ),
    ),
    build=build_model,
    tests=run_tests,
    population_checks=(
        PopulationCheck(
            name="covers-both-base-footprints",
            predicate=lambda samples: (
                {sample["base_footprint"] for sample in samples} >= {"round", "square"}
            ),
            message="Population must include both common undecorated base footprints.",
        ),
        _bounds_check("covers-base-diameter", "base_diameter", 0.130, 0.200),
        _bounds_check("covers-base-thickness", "base_thickness", 0.014, 0.030),
        _bounds_check("covers-post-diameter", "post_diameter", 0.020, 0.030),
        _bounds_check(
            "covers-first-layer-height",
            "first_layer_height_above_base",
            0.095,
            0.130,
        ),
        _bounds_check("covers-layer-spacing", "layer_spacing", 0.085, 0.115),
        _bounds_check("covers-branch-length", "branch_length", 0.070, 0.100),
        _bounds_check("covers-branch-diameter", "branch_diameter", 0.008, 0.010),
        _bounds_check(
            "covers-branch-rise",
            "branch_rise_angle",
            math.radians(12.0),
            math.radians(28.0),
        ),
    ),
    task_requirements=(
        "Exactly three branch layers and exactly two opposite branches per layer, for six total.",
        "Branches within a layer are 180 degrees apart; adjacent layers rotate by 90 degrees.",
        "Every branch is a genuine slender upward-sloping hanging member rigidly mounted to the post.",
        "The assembled tree contains no decorative or accessory obstacles.",
    ),
    tags=("mug tree", "countertop", "six branches", "household storage"),
)
