from __future__ import annotations

import math
from collections.abc import Mapping, Sequence
from typing import Any

from assetengine import (
    ActiveWhen,
    Derived,
    GeneratorDesign,
    GeneratorSpec,
    JointMount,
    PopulationCheck,
    RelativeUniformFloat,
    RigidMount,
    UniformChoice,
    UniformFloat,
    place_rigid_mount,
)
from assetengine.articraft import (
    ArticulatedObject,
    ArticulationType,
    Box,
    ExtrudeGeometry,
    MeshGeometry,
    MotionLimits,
    Origin,
    TestContext,
    mesh_from_geometry,
    rounded_rect_profile,
    superellipse_profile,
)


def _semi_round_profile(
    width: float, depth: float, rear_radius: float, *, curve_segments: int = 32
) -> list[tuple[float, float]]:
    """Flat rear with tangent-continuous rounded corners and an elliptical front."""
    half_width = 0.5 * width
    half_depth = 0.5 * depth
    radius = min(rear_radius, 0.30 * width, 0.35 * depth)
    center_y = half_depth - radius
    points = [(-half_width + radius, half_depth), (half_width - radius, half_depth)]
    for index in range(1, 9):
        angle = 0.5 * math.pi * (1.0 - index / 8.0)
        points.append(
            (
                half_width - radius + radius * math.cos(angle),
                center_y + radius * math.sin(angle),
            )
        )
    front_depth = depth - radius
    for index in range(1, curve_segments + 1):
        angle = math.pi * index / curve_segments
        points.append((half_width * math.cos(angle), center_y - front_depth * math.sin(angle)))
    for index in range(1, 8):
        angle = math.pi - 0.5 * math.pi * index / 8.0
        points.append(
            (
                -half_width + radius + radius * math.cos(angle),
                center_y + radius * math.sin(angle),
            )
        )
    area = sum(
        points[index][0] * points[(index + 1) % len(points)][1]
        - points[(index + 1) % len(points)][0] * points[index][1]
        for index in range(len(points))
    )
    return points if area > 0.0 else list(reversed(points))


def _plan_profile(
    parameters: Mapping[str, Any],
    width: float,
    depth: float,
    *,
    inset: float = 0.0,
) -> list[tuple[float, float]]:
    width -= 2.0 * inset
    depth -= 2.0 * inset
    planform = parameters["body_planform"]
    if planform == "round":
        return superellipse_profile(width, depth, exponent=2.0, segments=64)
    corner_radius = max(0.004, float(parameters["corner_radius"]) - inset)
    if planform == "semi_round":
        return _semi_round_profile(width, depth, corner_radius)
    corner_radius = min(corner_radius, 0.5 * min(width, depth) - 0.001)
    return rounded_rect_profile(width, depth, corner_radius, corner_segments=8)


def _wall_geometry(
    bottom_outer: Sequence[tuple[float, float]],
    top_outer: Sequence[tuple[float, float]],
    bottom_inner: Sequence[tuple[float, float]],
    top_inner: Sequence[tuple[float, float]],
    height: float,
) -> MeshGeometry:
    """Build one coherent, watertight, optionally flared annular wall."""
    counts = {len(bottom_outer), len(top_outer), len(bottom_inner), len(top_inner)}
    if len(counts) != 1:
        raise ValueError("Corresponding wall profiles must have equal point counts")
    count = len(bottom_outer)
    vertices = (
        [(x, y, 0.0) for x, y in bottom_outer]
        + [(x, y, height) for x, y in top_outer]
        + [(x, y, 0.0) for x, y in bottom_inner]
        + [(x, y, height) for x, y in top_inner]
    )
    faces: list[tuple[int, int, int]] = []
    for index in range(count):
        nxt = (index + 1) % count
        ob, on = index, nxt
        ot, otn = count + index, count + nxt
        ib, ibn = 2 * count + index, 2 * count + nxt
        it, itn = 3 * count + index, 3 * count + nxt
        faces.extend(
            (
                (ob, on, otn),
                (ob, otn, ot),
                (ib, itn, ibn),
                (ib, it, itn),
                (ob, ibn, on),
                (ob, ib, ibn),
                (ot, otn, itn),
                (ot, itn, it),
            )
        )
    return MeshGeometry(vertices=vertices, faces=faces)


def _hinge_housing_geometry(
    parameters: Mapping[str, Any], width: float, depth: float
) -> MeshGeometry:
    """Create a rear housing whose complete inner face follows the parent wall."""
    housing_width = 0.46 * width
    housing_depth = 0.003
    root_stock = 0.004
    if parameters["body_planform"] == "round":
        radius = 0.5 * width
        half_angle = math.asin(0.5 * housing_width / radius)
        inner = [
            (
                radius * math.sin(-half_angle + 2.0 * half_angle * index / 16.0),
                radius * math.cos(-half_angle + 2.0 * half_angle * index / 16.0),
            )
            for index in range(17)
        ]
        profile = [(x, y - root_stock) for x, y in inner] + [
            (x, y + housing_depth) for x, y in reversed(inner)
        ]
    else:
        back_y = 0.5 * depth
        half_width = 0.5 * housing_width
        profile = [
            (-half_width, back_y - root_stock),
            (half_width, back_y - root_stock),
            (half_width, back_y + housing_depth),
            (-half_width, back_y + housing_depth),
        ]
    return ExtrudeGeometry.from_z0(profile, 0.018, cap=True, closed=True)


def build_model(parameters: Mapping[str, Any]) -> ArticulatedObject:
    model = ArticulatedObject(name="trash_can")
    neutral = model.material("neutral", rgba=(0.48, 0.50, 0.52, 1.0))
    accent = model.material("accent", rgba=(0.34, 0.36, 0.38, 1.0))
    body = model.part("body")
    wall = float(parameters["wall_thickness"])
    base_thickness = float(parameters["base_thickness"])
    body_height = float(parameters["body_height"])
    top_width = float(parameters["body_width"])
    top_depth = float(parameters["body_depth"])
    bottom_width = float(parameters["base_width"])
    bottom_depth = float(parameters["base_depth"])
    bottom_outer = _plan_profile(parameters, bottom_width, bottom_depth)
    top_outer = _plan_profile(parameters, top_width, top_depth)
    bottom_inner = _plan_profile(parameters, bottom_width, bottom_depth, inset=wall)
    top_inner = _plan_profile(parameters, top_width, top_depth, inset=wall)

    body.visual(
        mesh_from_geometry(
            ExtrudeGeometry.from_z0(bottom_outer, base_thickness, cap=True, closed=True),
            "body_base",
        ),
        origin=Origin(),
        material=neutral,
        name="body_base",
    )
    body.visual(
        mesh_from_geometry(
            _wall_geometry(
                bottom_outer,
                top_outer,
                bottom_inner,
                top_inner,
                body_height - base_thickness,
            ),
            "body_wall",
        ),
        origin=Origin(xyz=(0.0, 0.0, base_thickness)),
        material=neutral,
        name="body_wall",
    )

    if parameters["top_construction"] == "step_lid":
        overhang = float(parameters["lid_overhang"])
        lid_thickness = float(parameters["lid_thickness"])
        lid_width = top_width + 2.0 * overhang
        lid_depth = top_depth + 2.0 * overhang
        lid_profile = _plan_profile(parameters, lid_width, lid_depth)
        lid = model.part("lid")
        lid.visual(
            mesh_from_geometry(
                ExtrudeGeometry.from_z0(lid_profile, lid_thickness, cap=True, closed=True),
                "lid_panel",
            ),
            origin=Origin(xyz=(0.0, -0.5 * lid_depth, 0.0)),
            material=neutral,
            name="lid_panel",
        )

        hinge_height = 0.018
        housing_placement = place_rigid_mount(
            parent_geometry=ExtrudeGeometry.from_z0(top_outer, body_height, cap=True, closed=True),
            child_geometry=_hinge_housing_geometry(parameters, top_width, top_depth),
            parent_from_child=Origin(xyz=(0.0, 0.0, body_height - hinge_height)),
            mount_direction=(0.0, 1.0, 0.0),
            keep_point=(0.0, 0.5 * top_depth + 0.0015, 0.009),
            max_translation=0.010,
        )
        body.visual(
            mesh_from_geometry(
                housing_placement.child_geometry,
                "rear_hinge_housing",
            ),
            origin=housing_placement.parent_from_child,
            material=accent,
            name="rear_hinge_housing",
        )
        model.articulation(
            "body_to_lid",
            ArticulationType.REVOLUTE,
            parent=body,
            child=lid,
            origin=Origin(xyz=(0.0, 0.5 * lid_depth, body_height)),
            axis=(-1.0, 0.0, 0.0),
            motion_limits=MotionLimits(
                effort=5.0,
                velocity=2.0,
                lower=0.0,
                upper=float(parameters["lid_open_angle"]),
            ),
        )

        pedal = model.part("pedal")
        pedal_depth = float(parameters["pedal_depth"])
        pedal_thickness = float(parameters["pedal_thickness"])
        pedal.visual(
            Box((float(parameters["pedal_width"]), pedal_depth, pedal_thickness)),
            origin=Origin(xyz=(0.0, -0.5 * pedal_depth, 0.5 * pedal_thickness)),
            material=accent,
            name="foot_pedal",
        )
        model.articulation(
            "body_to_pedal",
            ArticulationType.REVOLUTE,
            parent=body,
            child=pedal,
            origin=Origin(xyz=(0.0, -0.5 * bottom_depth, 0.030)),
            axis=(1.0, 0.0, 0.0),
            motion_limits=MotionLimits(
                effort=8.0,
                velocity=1.0,
                lower=0.0,
                upper=0.14,
            ),
        )
    return model


def run_tests(model: ArticulatedObject, parameters: Mapping[str, Any]):
    ctx = TestContext(model)
    wall = float(parameters["wall_thickness"])
    checks = (
        ("cavity-retains-positive-width", float(parameters["base_width"]) - 2.0 * wall > 0.15),
        ("cavity-retains-positive-depth", float(parameters["base_depth"]) - 2.0 * wall > 0.12),
        (
            "wall-rises-above-floor",
            float(parameters["body_height"]) > float(parameters["base_thickness"]),
        ),
        (
            "round-planform-has-equal-axes",
            parameters["body_planform"] != "round"
            or abs(float(parameters["body_width"]) - float(parameters["body_depth"])) <= 1e-9,
        ),
        (
            "flare-never-narrows-opening",
            float(parameters["base_width"]) <= float(parameters["body_width"])
            and float(parameters["base_depth"]) <= float(parameters["body_depth"]),
        ),
    )
    for name, passed in checks:
        ctx.check(name, passed)
    if parameters["top_construction"] == "step_lid":
        ctx.check(
            "lid-opens-through-ordinary-positive-angle",
            1.30 <= float(parameters["lid_open_angle"]) <= 1.95,
        )
        ctx.check(
            "pedal-is-narrower-than-body",
            float(parameters["pedal_width"]) < float(parameters["body_width"]),
        )
    return ctx.report()


def _covers_choice(samples: Sequence[Mapping[str, Any]], factor: str, choices: set[str]) -> bool:
    return {str(sample[factor]) for sample in samples} >= choices


def _covers_bounds(
    samples: Sequence[Mapping[str, Any]],
    factor: str,
    *,
    minimum_at_most: float,
    maximum_at_least: float,
) -> bool:
    values = [float(sample[factor]) for sample in samples]
    return min(values) <= minimum_at_most and max(values) >= maximum_at_least


GENERATOR = GeneratorSpec(
    name="trash_can",
    category="trash_can",
    description=(
        "Procedural ordinary indoor household trash cans with a real open cavity, round, "
        "rounded-rectangular, or flat-backed semi-round bodies, and open or foot-operated tops."
    ),
    design=GeneratorDesign(
        coverage=(
            "Ordinary freestanding indoor household trash cans include circular, rounded-rectangular, "
            "and flat-backed semi-round planforms; open-top wastebaskets and foot-operated step cans; "
            "0.20-0.42 m family-conditional widths; 0.25-0.66 m target heights; near-vertical bodies and "
            "open-top bodies flared to 78-93% base-to-opening width. Rectangular and semi-round depths "
            "are 58-82% of width. This retains compact bathroom/office bins and 30-60 L-class kitchen "
            "cans. A transparent 0.068 m3 planform-envelope cap removes only the commercial-scale "
            "high-width/high-depth/high-height corner. Outdoor "
            "wheeled carts, dumpsters, built-in pullouts, multi-stream sorters, mesh, novelty, ash, and "
            "medical receptacles remain excluded."
        ),
        factors=(
            "Planform and open-versus-step construction are independent topologies. Width is sampled "
            "conditionally because round bodies ordinarily stop narrower than wall-adjacent semi-round "
            "and rectangular cans. Nonround depth scales with width; an ordinary height target scales "
            "with resolved width, then a planform-area-derived cap limits only combinations whose outer "
            "envelope would exceed 0.068 m3. Open tops choose near-vertical or outward-flared profiles; "
            "only the flared family samples a base-to-opening ratio. Corner radius scales with depth. "
            "Wall/floor thicknesses and step-lid/pedal dimensions retain ordinary independent or "
            "body-relative controls. All stochastic factors are uniform."
        ),
        components=(
            "A coherent annular wall lofts corresponding bottom and opening profiles around real free "
            "space and seats continuously on a matching floor. Open wastebaskets vary between vertical "
            "and visibly flared silhouettes. Semi-round bodies combine a straight back, tangent rear "
            "rounds, and elliptical front. Step cans add a body-matched coherent lid, rear hinge housing, "
            "and visible lower-front pedal with varying width, reach, and thickness. Liners, linkage, "
            "fasteners, dampers, logos, casters, and finish are incidental or excluded."
        ),
        physics_and_task=(
            "The floor supports the complete wall over a finite perimeter RigidMount. On step cans, a "
            "second RigidMount seats the rear hinge housing into the upper wall, a revolute JointMount "
            "attaches the lid at that rear region, and another revolute JointMount supports the front "
            "pedal. The lid opens upward and the pedal depresses about its body-side root. No linkage is "
            "claimed, and no robot-, hand-, or bag-specific clearance is inferred."
        ),
    ),
    factors=(
        UniformChoice(
            name="body_planform",
            choices=("round", "rounded_rectangle", "semi_round"),
            description="Circular, rounded-rectangular, or flat-backed semi-round planform.",
        ),
        UniformChoice(
            name="top_construction",
            choices=("open_top", "step_lid"),
            description="Always-open wastebasket or foot-operated rear-hinged step can.",
        ),
        UniformFloat(
            name="round_width",
            low=0.20,
            high=0.36,
            active_when=(ActiveWhen(factor="body_planform", values=("round",)),),
            description="Outside diameter of round bodies.",
            unit="m",
        ),
        UniformFloat(
            name="rectangular_width",
            low=0.22,
            high=0.42,
            active_when=(ActiveWhen(factor="body_planform", values=("rounded_rectangle",)),),
            description="Outside width of rounded-rectangular bodies.",
            unit="m",
        ),
        UniformFloat(
            name="semi_round_width",
            low=0.24,
            high=0.42,
            active_when=(ActiveWhen(factor="body_planform", values=("semi_round",)),),
            description="Outside width across the flat-backed semi-round body.",
            unit="m",
        ),
        Derived(
            name="body_width",
            derive=lambda p: {
                "round": p["round_width"],
                "rounded_rectangle": p["rectangular_width"],
                "semi_round": p["semi_round_width"],
            }[p["body_planform"]],
            depends_on=("body_planform", "round_width", "rectangular_width", "semi_round_width"),
            description="Resolved family-specific outside width.",
            unit="m",
        ),
        UniformFloat(
            name="nonround_depth_ratio",
            low=0.58,
            high=0.82,
            active_when=(
                ActiveWhen(factor="body_planform", values=("rounded_rectangle", "semi_round")),
            ),
            description="Nonround outside depth divided by width.",
            unit="ratio",
        ),
        Derived(
            name="body_depth",
            derive=lambda p: (
                p["body_width"]
                if p["body_planform"] == "round"
                else p["body_width"] * p["nonround_depth_ratio"]
            ),
            depends_on=("body_planform", "body_width", "nonround_depth_ratio"),
            description="Resolved outside depth.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="body_height_target",
            reference="body_width",
            ratio_low=1.20,
            ratio_high=2.20,
            hard_min=0.25,
            hard_max=0.66,
            description="Independent ordinary height target whose interval shifts with width.",
            unit="m",
        ),
        Derived(
            name="body_height",
            derive=lambda p: min(
                p["body_height_target"],
                0.068
                / (
                    p["body_width"]
                    * p["body_depth"]
                    * {"round": 0.785, "rounded_rectangle": 0.90, "semi_round": 0.76}[
                        p["body_planform"]
                    ]
                ),
            ),
            depends_on=(
                "body_height_target",
                "body_width",
                "body_depth",
                "body_planform",
            ),
            description=(
                "Realized height after the planform-aware 0.068 cubic-meter household outer-envelope "
                "cap removes only oversized joint boundary combinations."
            ),
            unit="m",
        ),
        UniformChoice(
            name="open_side_profile",
            choices=("near_vertical", "outward_flared"),
            active_when=(ActiveWhen(factor="top_construction", values=("open_top",)),),
            description="Vertical or outward-flared open-top wastebasket silhouette.",
        ),
        UniformFloat(
            name="flared_base_ratio",
            low=0.78,
            high=0.93,
            active_when=(
                ActiveWhen(factor="top_construction", values=("open_top",)),
                ActiveWhen(factor="open_side_profile", values=("outward_flared",)),
            ),
            description="Flared-family base width and depth divided by opening dimensions.",
            unit="ratio",
        ),
        Derived(
            name="base_width",
            derive=lambda p: (
                p["body_width"]
                * (
                    p["flared_base_ratio"]
                    if p["top_construction"] == "open_top"
                    and p["open_side_profile"] == "outward_flared"
                    else 1.0
                )
            ),
            depends_on=(
                "body_width",
                "top_construction",
                "open_side_profile",
                "flared_base_ratio",
            ),
            description="Bottom width, reduced only for the flared open-top family.",
            unit="m",
        ),
        Derived(
            name="base_depth",
            derive=lambda p: (
                p["body_depth"]
                * (
                    p["flared_base_ratio"]
                    if p["top_construction"] == "open_top"
                    and p["open_side_profile"] == "outward_flared"
                    else 1.0
                )
            ),
            depends_on=(
                "body_depth",
                "top_construction",
                "open_side_profile",
                "flared_base_ratio",
            ),
            description="Bottom depth, reduced only for the flared open-top family.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="corner_radius",
            reference="body_depth",
            ratio_low=0.08,
            ratio_high=0.20,
            active_when=(
                ActiveWhen(factor="body_planform", values=("rounded_rectangle", "semi_round")),
            ),
            description="Corner radius for nonround planforms.",
            unit="m",
        ),
        UniformFloat(
            name="wall_thickness",
            low=0.003,
            high=0.007,
            description="Thickness of the continuous body wall.",
            unit="m",
        ),
        UniformFloat(
            name="base_thickness",
            low=0.005,
            high=0.014,
            description="Thickness of the solid bottom floor.",
            unit="m",
        ),
        UniformFloat(
            name="lid_overhang",
            low=0.004,
            high=0.014,
            active_when=(ActiveWhen(factor="top_construction", values=("step_lid",)),),
            description="Lid extension beyond each body side.",
            unit="m",
        ),
        UniformFloat(
            name="lid_thickness",
            low=0.012,
            high=0.026,
            active_when=(ActiveWhen(factor="top_construction", values=("step_lid",)),),
            description="Vertical thickness of the coherent lid panel.",
            unit="m",
        ),
        UniformFloat(
            name="lid_open_angle",
            low=1.35,
            high=1.92,
            active_when=(ActiveWhen(factor="top_construction", values=("step_lid",)),),
            description="Maximum upward rear-hinge travel from closed.",
            unit="rad",
        ),
        RelativeUniformFloat(
            name="pedal_width",
            reference="body_width",
            ratio_low=0.18,
            ratio_high=0.32,
            active_when=(ActiveWhen(factor="top_construction", values=("step_lid",)),),
            description="Visible pedal width across the lower front.",
            unit="m",
        ),
        UniformFloat(
            name="pedal_depth",
            low=0.045,
            high=0.075,
            active_when=(ActiveWhen(factor="top_construction", values=("step_lid",)),),
            description="Pedal reach outward from the lower front wall.",
            unit="m",
        ),
        UniformFloat(
            name="pedal_thickness",
            low=0.008,
            high=0.014,
            active_when=(ActiveWhen(factor="top_construction", values=("step_lid",)),),
            description="Vertical pedal plate thickness.",
            unit="m",
        ),
    ),
    relationships=(
        RigidMount(
            name="wall-seated-on-base",
            parent_part="body",
            parent_element="body_base",
            child_part="body",
            child_element="body_wall",
            contact_tolerance=1e-6,
        ),
        RigidMount(
            name="hinge-housing-seated-on-wall",
            parent_part="body",
            parent_element="body_wall",
            child_part="body",
            child_element="rear_hinge_housing",
            contact_tolerance=1e-6,
            active_when=(ActiveWhen(factor="top_construction", values=("step_lid",)),),
        ),
        JointMount(
            name="lid-hinged-to-body",
            joint="body_to_lid",
            parent_part="body",
            child_part="lid",
            allowed_joint_types=("revolute",),
            active_when=(ActiveWhen(factor="top_construction", values=("step_lid",)),),
        ),
        JointMount(
            name="pedal-hinged-to-body",
            joint="body_to_pedal",
            parent_part="body",
            child_part="pedal",
            allowed_joint_types=("revolute",),
            active_when=(ActiveWhen(factor="top_construction", values=("step_lid",)),),
        ),
    ),
    build=build_model,
    tests=run_tests,
    population_checks=(
        PopulationCheck(
            name="covers-body-planforms",
            predicate=lambda samples: _covers_choice(
                samples, "body_planform", {"round", "rounded_rectangle", "semi_round"}
            ),
            message="Population must include all three common planforms.",
        ),
        PopulationCheck(
            name="covers-top-constructions",
            predicate=lambda samples: _covers_choice(
                samples, "top_construction", {"open_top", "step_lid"}
            ),
            message="Population must include open and step-lid constructions.",
        ),
        PopulationCheck(
            name="covers-open-side-profiles",
            predicate=lambda samples: _covers_choice(
                [sample for sample in samples if sample["top_construction"] == "open_top"],
                "open_side_profile",
                {"near_vertical", "outward_flared"},
            ),
            message="Open-top population must include vertical and flared bodies.",
        ),
        PopulationCheck(
            name="covers-body-width-envelope",
            predicate=lambda samples: _covers_bounds(
                samples, "body_width", minimum_at_most=0.205, maximum_at_least=0.415
            ),
            message="Population must exercise compact and full household widths.",
        ),
        PopulationCheck(
            name="covers-body-height-envelope",
            predicate=lambda samples: _covers_bounds(
                samples, "body_height", minimum_at_most=0.27, maximum_at_least=0.61
            ),
            message="Population must exercise short and tall household cans.",
        ),
    ),
    task_requirements=(
        "Every instance must contain a genuine positive-volume waste receptacle cavity.",
        "Step-can lids and pedals must be attached by their declared revolute joints.",
        "Every step-can lid must open upward through its authored range.",
    ),
    tags=("trash_can", "waste_receptacle", "open_cavity", "step_can", "semi_round"),
)
