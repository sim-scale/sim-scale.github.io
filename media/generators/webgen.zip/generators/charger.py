from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Mapping, Sequence

from assetengine import (
    ActiveWhen,
    Constraint,
    GeneratorDesign,
    GeneratorSpec,
    JointMount,
    PopulationCheck,
    RelativeUniformFloat,
    RigidMount,
    UniformChoice,
    UniformFloat,
)
from assetengine.articraft import (
    ArticulatedObject,
    ArticulationType,
    Box,
    Cylinder,
    CylinderGeometry,
    ExtrudeGeometry,
    MeshGeometry,
    MotionLimits,
    Origin,
    TestContext,
    boolean_difference,
    boolean_union,
    mesh_from_geometry,
    rounded_rect_profile,
)

_USB_A_WIDTH = 0.0124
_USB_A_HEIGHT = 0.0052
_USB_C_WIDTH = 0.0092
_USB_C_HEIGHT = 0.0036
_USB_A_MATING_DEPTH = 0.012
_USB_C_MATING_DEPTH = 0.008
_PORT_CUTTER_OVERTRAVEL = 0.001
_PORT_SIDE_MARGIN = 0.004
_PORT_VERTICAL_MARGIN = 0.004
_FOLDING_ROTOR_RADIUS = 0.0032
_FOLDING_ROTOR_WIDTH = 0.018


@dataclass(frozen=True)
class _PortSpec:
    connector: str
    center_z: float
    name: str


def _port_specs(parameters: Mapping[str, Any]) -> tuple[_PortSpec, ...]:
    configuration = str(parameters["output_configuration"])
    if configuration == "single_usb_a":
        return (_PortSpec("usb_a", 0.0, "primary"),)
    if configuration == "single_usb_c":
        return (_PortSpec("usb_c", 0.0, "primary"),)

    connector_pairs = {
        "dual_usb_a": ("usb_a", "usb_a"),
        "dual_usb_a_c": ("usb_a", "usb_c"),
        "dual_usb_c": ("usb_c", "usb_c"),
    }
    primary_connector, secondary_connector = connector_pairs[configuration]
    spacing = float(parameters["dual_port_edge_spacing"])
    primary_height = _port_dimensions(primary_connector)[1]
    secondary_height = _port_dimensions(secondary_connector)[1]
    total_height = primary_height + spacing + secondary_height
    return (
        _PortSpec(
            primary_connector,
            0.5 * total_height - 0.5 * primary_height,
            "primary",
        ),
        _PortSpec(
            secondary_connector,
            -0.5 * total_height + 0.5 * secondary_height,
            "secondary",
        ),
    )


def _port_dimensions(connector: str) -> tuple[float, float, float, float]:
    if connector == "usb_a":
        return (_USB_A_WIDTH, _USB_A_HEIGHT, 0.0007, _USB_A_MATING_DEPTH)
    return (_USB_C_WIDTH, _USB_C_HEIGHT, 0.00165, _USB_C_MATING_DEPTH)


def _weld_boolean_mesh(geometry: MeshGeometry) -> MeshGeometry:
    """Weld manifold Boolean seams at the precision used for exported assets."""

    tolerance = 1e-7
    vertices: list[tuple[float, float, float]] = []
    remap: list[int] = []
    for vertex in geometry.vertices:
        existing = next(
            (
                index
                for index, candidate in enumerate(vertices)
                if max(abs(float(vertex[axis]) - float(candidate[axis])) for axis in range(3))
                <= tolerance
            ),
            None,
        )
        if existing is None:
            existing = len(vertices)
            vertices.append(tuple(float(value) for value in vertex))
        remap.append(existing)
    faces = [tuple(remap[index] for index in face) for face in geometry.faces]
    faces = [face for face in faces if len(set(face)) == 3]
    return MeshGeometry(vertices=vertices, faces=faces)


def _housing_geometry(parameters: Mapping[str, Any]):
    body_width = float(parameters["body_width"])
    body_height = float(parameters["body_height"])
    body_depth = float(parameters["body_depth"])
    corner_radius = float(parameters["corner_radius"])

    body = ExtrudeGeometry(
        rounded_rect_profile(
            body_width,
            body_height,
            corner_radius,
            corner_segments=8,
        ),
        body_depth,
        cap=True,
        center=True,
        closed=True,
    ).rotate_x(math.pi / 2.0)

    cutters = []
    for port in _port_specs(parameters):
        width, height, radius, cavity_depth = _port_dimensions(port.connector)
        cutter_center = (
            0.0,
            0.5 * body_depth - 0.5 * cavity_depth + 0.5 * _PORT_CUTTER_OVERTRAVEL,
            port.center_z,
        )
        cutter = (
            ExtrudeGeometry(
                rounded_rect_profile(width, height, radius, corner_segments=8),
                cavity_depth + _PORT_CUTTER_OVERTRAVEL,
                cap=True,
                center=True,
                closed=True,
            )
            .rotate_x(math.pi / 2.0)
            .translate(*cutter_center)
        )
        cutters.append(cutter)
    combined_cutter = cutters[0]
    for cutter in cutters[1:]:
        combined_cutter = boolean_union(combined_cutter, cutter)
    return _weld_boolean_mesh(boolean_difference(body, combined_cutter))


def _add_ac_prongs(part, parameters: Mapping[str, Any], material) -> None:
    body_depth = float(parameters["body_depth"])
    plug_family = str(parameters["plug_family"])

    if plug_family == "type_a_flat_blade":
        if parameters["type_a_construction"] == "folding":
            return
        length = float(parameters["type_a_blade_length"])
        size = (0.0016, length, 0.0063)
        centers: Sequence[tuple[str, float, float]] = (
            ("ac_pin_left", -0.00635, 0.0),
            ("ac_pin_right", 0.00635, 0.0),
        )
        for name, center_x, center_z in centers:
            part.visual(
                Box(size),
                origin=Origin(xyz=(center_x, -0.5 * body_depth - 0.5 * length, center_z)),
                material=material,
                name=name,
            )
        return

    if plug_family == "type_c_round_pin":
        length = float(parameters["type_c_pin_length"])
        for name, center_x in (
            ("ac_pin_left", -0.0095),
            ("ac_pin_right", 0.0095),
        ):
            part.visual(
                Cylinder(radius=0.002, length=length),
                origin=Origin(
                    xyz=(center_x, -0.5 * body_depth - 0.5 * length, 0.0),
                    rpy=(math.pi / 2.0, 0.0, 0.0),
                ),
                material=material,
                name=name,
            )
        return

    line_length = float(parameters["type_g_line_pin_length"])
    ground_length = line_length + float(parameters["type_g_ground_extension"])
    type_g_pins = (
        (
            "ac_pin_left",
            -0.01115,
            -0.00635,
            (0.0040, line_length, 0.00635),
            line_length,
        ),
        (
            "ac_pin_right",
            0.01115,
            -0.00635,
            (0.0040, line_length, 0.00635),
            line_length,
        ),
        (
            "ac_ground_pin",
            0.0,
            0.01115,
            (0.0040, ground_length, 0.0080),
            ground_length,
        ),
    )
    for name, center_x, center_z, size, pin_length in type_g_pins:
        part.visual(
            Box(size),
            origin=Origin(xyz=(center_x, -0.5 * body_depth - 0.5 * pin_length, center_z)),
            material=material,
            name=name,
        )


def _folding_blade_geometry(parameters: Mapping[str, Any]) -> MeshGeometry:
    exposed_length = float(parameters["type_a_blade_length"])
    rotor = CylinderGeometry(
        _FOLDING_ROTOR_RADIUS,
        _FOLDING_ROTOR_WIDTH,
        radial_segments=32,
        closed=True,
    ).rotate_y(math.pi / 2.0)
    blade_total_length = exposed_length - _FOLDING_ROTOR_RADIUS + 0.001
    blade_center_y = 0.5 * (0.001 + _FOLDING_ROTOR_RADIUS - exposed_length)
    assembly = rotor
    for center_x in (-0.00635, 0.00635):
        blade = (
            ExtrudeGeometry(
                rounded_rect_profile(0.0016, 0.0063, 0.0),
                blade_total_length,
                cap=True,
                center=True,
                closed=True,
            )
            .rotate_x(math.pi / 2.0)
            .translate(center_x, blade_center_y, 0.0)
        )
        assembly = boolean_union(assembly, blade)
    return _weld_boolean_mesh(assembly)


def _add_folding_type_a_plug(
    model: ArticulatedObject,
    adapter,
    parameters: Mapping[str, Any],
    material,
) -> None:
    if not (
        parameters["plug_family"] == "type_a_flat_blade"
        and parameters["type_a_construction"] == "folding"
    ):
        return

    folding_plug = model.part("folding_plug")
    folding_plug.visual(
        mesh_from_geometry(_folding_blade_geometry(parameters), "folding_blade_assembly"),
        origin=Origin(),
        material=material,
        name="folding_blade_assembly",
    )
    model.articulation(
        "folding_plug_hinge",
        ArticulationType.REVOLUTE,
        parent=adapter,
        child=folding_plug,
        origin=Origin(
            xyz=(
                0.0,
                -0.5 * float(parameters["body_depth"]) - _FOLDING_ROTOR_RADIUS,
                0.0,
            )
        ),
        axis=(1.0, 0.0, 0.0),
        motion_limits=MotionLimits(
            effort=1.0,
            velocity=1.0,
            lower=0.0,
            upper=0.5 * math.pi,
        ),
    )


def _add_output_tongues(part, parameters: Mapping[str, Any], material) -> None:
    body_depth = float(parameters["body_depth"])

    for port in _port_specs(parameters):
        width, _height, _radius, cavity_depth = _port_dimensions(port.connector)
        rear_y = 0.5 * body_depth - cavity_depth
        if port.connector == "usb_a":
            tongue_width = 0.80 * width
            tongue_height = 0.0009
            tongue_depth = 0.78 * cavity_depth
            tongue_center_z = port.center_z - 0.00125
        else:
            tongue_width = 0.72 * width
            tongue_height = 0.0006
            tongue_depth = 0.72 * cavity_depth
            tongue_center_z = port.center_z
        visual_name = f"output_tongue_{port.name}"
        part.visual(
            Box((tongue_width, tongue_depth, tongue_height)),
            origin=Origin(
                xyz=(
                    0.0,
                    rear_y + 0.5 * tongue_depth,
                    tongue_center_z,
                )
            ),
            material=material,
            name=visual_name,
        )


def build_model(parameters: Mapping[str, Any]) -> ArticulatedObject:
    model = ArticulatedObject(name="phone_charger_wall_power_adapter")
    neutral = model.material("neutral", rgba=(0.58, 0.59, 0.60, 1.0))
    adapter = model.part("adapter")

    adapter.visual(
        mesh_from_geometry(_housing_geometry(parameters), "housing_shell"),
        origin=Origin(),
        material=neutral,
        name="housing_shell",
    )
    _add_ac_prongs(adapter, parameters, neutral)
    _add_folding_type_a_plug(model, adapter, parameters, neutral)
    _add_output_tongues(adapter, parameters, neutral)
    return model


def _output_layout_fits(parameters: Mapping[str, Any]) -> bool:
    ports = _port_specs(parameters)
    body_width = float(parameters["body_width"])
    body_height = float(parameters["body_height"])
    corner_radius = float(parameters["corner_radius"])
    maximum_port_half_width = max(0.5 * _port_dimensions(port.connector)[0] for port in ports)
    port_min_z = min(port.center_z - 0.5 * _port_dimensions(port.connector)[1] for port in ports)
    port_max_z = max(port.center_z + 0.5 * _port_dimensions(port.connector)[1] for port in ports)
    return (
        maximum_port_half_width + _PORT_SIDE_MARGIN <= 0.5 * body_width - corner_radius
        and max(abs(port_min_z), abs(port_max_z)) + _PORT_VERTICAL_MARGIN
        <= 0.5 * body_height - corner_radius
    )


def _type_g_footprint_fits(parameters: Mapping[str, Any]) -> bool:
    return parameters["plug_family"] != "type_g_rectangular_pin" or (
        0.0132 <= 0.5 * float(parameters["body_width"]) - float(parameters["corner_radius"])
        and 0.0152 <= 0.5 * float(parameters["body_height"]) - float(parameters["corner_radius"])
    )


def run_tests(model: ArticulatedObject, parameters: Mapping[str, Any]):
    ctx = TestContext(model)
    ports = _port_specs(parameters)
    body_depth = float(parameters["body_depth"])
    ctx.check(
        "housing-width-within-requested-x-envelope",
        0.032 <= float(parameters["body_width"]) <= 0.050,
    )
    ctx.check(
        "housing-height-within-requested-z-envelope",
        0.020 <= float(parameters["body_height"]) <= 0.070,
    )
    ctx.check(
        "output-openings-fit-housing",
        _output_layout_fits(parameters),
    )
    ctx.check(
        "usb-a-mating-depth-retains-housing-back",
        _USB_A_MATING_DEPTH + 0.006 < body_depth,
    )
    ctx.check(
        "usb-c-mating-depth-retains-housing-back",
        _USB_C_MATING_DEPTH + 0.006 < body_depth,
    )
    ctx.check(
        "output-topology-count",
        len(ports) == (2 if str(parameters["output_configuration"]).startswith("dual_") else 1),
    )

    if parameters["plug_family"] == "type_g_rectangular_pin":
        ctx.check(
            "type-g-pin-footprint-inside-housing",
            _type_g_footprint_fits(parameters),
        )
        ctx.check(
            "type-g-ground-pin-projects-farther",
            float(parameters["type_g_ground_extension"]) > 0.0,
        )
    else:
        pin_half_span = 0.0115 if parameters["plug_family"] == "type_c_round_pin" else 0.0072
        ctx.check(
            "two-pin-footprint-inside-housing",
            pin_half_span
            <= 0.5 * float(parameters["body_width"]) - float(parameters["corner_radius"]),
        )
    if (
        parameters["plug_family"] == "type_a_flat_blade"
        and parameters["type_a_construction"] == "folding"
    ):
        ctx.fail_if_articulation_overlaps(
            max_pose_samples=5,
            name="folding-blades-clear-through-full-motion",
        )
    return ctx.report()


def _covers_choices(samples: Sequence[Mapping[str, Any]], factor: str, expected: set[str]) -> bool:
    return {str(sample[factor]) for sample in samples} >= expected


def _covers_type_a_constructions(samples: Sequence[Mapping[str, Any]]) -> bool:
    return {
        str(sample["type_a_construction"])
        for sample in samples
        if sample["plug_family"] == "type_a_flat_blade"
    } >= {"fixed", "folding"}


def _covers_bounds(
    samples: Sequence[Mapping[str, Any]],
    factor: str,
    *,
    minimum_at_most: float,
    maximum_at_least: float,
) -> bool:
    values = [float(sample[factor]) for sample in samples]
    return min(values) <= minimum_at_most and max(values) >= maximum_at_least


GENERATOR = GeneratorSpec(
    name="phone_charger_wall_power_adapter",
    category="phone_charger_wall_power_adapter",
    description=(
        "Common phone charger and wall power adapters with a rounded solid housing, "
        "regional fixed or folding AC plug geometry, and one or two USB charging outputs."
    ),
    design=GeneratorDesign(
        coverage=(
            "Covers ordinary fixed Type A, Type C, and Type G wall adapters plus common folding "
            "Type A blade assemblies; single USB-A or USB-C and dual A+A, A+C, or C+C outputs; "
            "and compact through larger rounded housings with independent face dimensions. "
            "The housing face spans the requested 0.032-0.050 m global-X width and "
            "0.020-0.070 m global-Z height. This bounds-only revision preserves the accepted "
            "construction scope: dual outputs remain vertically stacked; the folding assembly's "
            "visible cylindrical rotor and declared revolute retention abstract hidden housing "
            "bearings; and depthwise face bevel or taper variants remain incidental. "
            "Excludes attached cables, wireless pads, desktop bricks with detachable mains "
            "cords, travel-adapter socket matrices, rare regional plug standards, more-than-two-"
            "port charging stations, and swappable plug heads."
        ),
        factors=(
            "Plug, Type A construction, and output selectors represent distinct standardized "
            "topology. Housing width, height, and depth retain independent ordinary targets; "
            "explicit port-layout and Type G footprint constraints remove only residual invalid "
            "corners. Corner radius scales with width while remaining bounded for the smallest "
            "height. Dual-port spacing is an independent casing-band dimension. Regional prong "
            "lengths vary only in their applicable families, and Type G ground extension is an "
            "independent positive addition to its line-pin length. USB mating depths are fixed "
            "connector-interface consequences, not stylistic factors."
        ),
        components=(
            "The housing varies continuously in width, height, depth, and corner roundness. The "
            "wall interface varies among fixed flat blades, a revolute fold-away two-blade rotor, "
            "two round pins, and three rectangular pins with a longer ground pin. Device-facing "
            "geometry has full-depth connector-specific USB-A and rounded USB-C openings and "
            "correctly placed tongues; dual layouts have two complete stacked receptacles. "
            "Connector face dimensions, mating depths, and pin spacing remain fixed because they "
            "are interface geometry rather than free styling."
        ),
        physics_and_task=(
            "Fixed AC prongs seat by full root faces on the wall-facing housing; folding Type A "
            "blades and their rotor form one retained child link on a bounded revolute joint with "
            "collision-free deployed-to-stowed motion. Every output tongue seats by its rear face "
            "on its connector channel back. Named RigidMount and JointMount declarations cover "
            "these interfaces. Port cutters pass beyond the output face but stop at standard "
            "mating depths within the housing, preserving insertion space and a structural back "
            "wall. No unspecified device, robot, or outlet clearance threshold is inferred."
        ),
    ),
    factors=(
        UniformChoice(
            name="plug_family",
            choices=(
                "type_a_flat_blade",
                "type_c_round_pin",
                "type_g_rectangular_pin",
            ),
            description="Standardized wall-facing AC pin topology.",
            unit="family",
        ),
        UniformChoice(
            name="type_a_construction",
            choices=("fixed", "folding"),
            description="Fixed-root or fold-away rotor construction for Type A flat blades.",
            unit="family",
            active_when=(ActiveWhen(factor="plug_family", values=("type_a_flat_blade",)),),
        ),
        UniformChoice(
            name="output_configuration",
            choices=(
                "single_usb_a",
                "single_usb_c",
                "dual_usb_a",
                "dual_usb_a_c",
                "dual_usb_c",
            ),
            description="Device-facing USB opening topology on the face opposite the AC pins.",
            unit="family",
        ),
        UniformFloat(
            name="body_width",
            low=0.032,
            high=0.050,
            description="Left-to-right housing span viewed from the USB face.",
            unit="m",
        ),
        UniformFloat(
            name="body_height",
            low=0.020,
            high=0.070,
            description="Independent vertical housing span viewed from the USB face.",
            unit="m",
        ),
        UniformFloat(
            name="body_depth",
            low=0.026,
            high=0.064,
            description="Housing span from the wall-facing surface to the USB output face.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="corner_radius",
            reference="body_width",
            ratio_low=0.055,
            ratio_high=0.14,
            hard_min=0.0018,
            hard_max=0.008,
            description="Radius of the four longitudinal housing edges.",
            unit="m",
        ),
        UniformFloat(
            name="dual_port_edge_spacing",
            low=0.003,
            high=0.007,
            description="Vertical clear casing band between two stacked USB openings.",
            unit="m",
            active_when=(
                ActiveWhen(
                    factor="output_configuration",
                    values=("dual_usb_a", "dual_usb_a_c", "dual_usb_c"),
                ),
            ),
        ),
        UniformFloat(
            name="type_a_blade_length",
            low=0.014,
            high=0.018,
            description="Exposed wallward length of each Type A flat blade.",
            unit="m",
            active_when=(ActiveWhen(factor="plug_family", values=("type_a_flat_blade",)),),
        ),
        UniformFloat(
            name="type_c_pin_length",
            low=0.016,
            high=0.019,
            description="Exposed wallward length of each Type C round pin.",
            unit="m",
            active_when=(ActiveWhen(factor="plug_family", values=("type_c_round_pin",)),),
        ),
        UniformFloat(
            name="type_g_line_pin_length",
            low=0.017,
            high=0.020,
            description="Exposed wallward length of each Type G line and neutral pin.",
            unit="m",
            active_when=(ActiveWhen(factor="plug_family", values=("type_g_rectangular_pin",)),),
        ),
        UniformFloat(
            name="type_g_ground_extension",
            low=0.003,
            high=0.005,
            description="Additional wallward projection of the Type G ground pin beyond line pins.",
            unit="m",
            active_when=(ActiveWhen(factor="plug_family", values=("type_g_rectangular_pin",)),),
        ),
    ),
    build=build_model,
    tests=run_tests,
    relationships=(
        RigidMount(
            name="left-ac-pin-mounted-to-housing",
            parent_part="adapter",
            parent_element="housing_shell",
            child_part="adapter",
            child_element="ac_pin_left",
            active_when=(
                ActiveWhen(
                    factor="plug_family",
                    values=("type_c_round_pin", "type_g_rectangular_pin"),
                ),
            ),
        ),
        RigidMount(
            name="right-ac-pin-mounted-to-housing",
            parent_part="adapter",
            parent_element="housing_shell",
            child_part="adapter",
            child_element="ac_pin_right",
            active_when=(
                ActiveWhen(
                    factor="plug_family",
                    values=("type_c_round_pin", "type_g_rectangular_pin"),
                ),
            ),
        ),
        RigidMount(
            name="fixed-type-a-left-blade-mounted-to-housing",
            parent_part="adapter",
            parent_element="housing_shell",
            child_part="adapter",
            child_element="ac_pin_left",
            active_when=(
                ActiveWhen(factor="plug_family", values=("type_a_flat_blade",)),
                ActiveWhen(factor="type_a_construction", values=("fixed",)),
            ),
        ),
        RigidMount(
            name="fixed-type-a-right-blade-mounted-to-housing",
            parent_part="adapter",
            parent_element="housing_shell",
            child_part="adapter",
            child_element="ac_pin_right",
            active_when=(
                ActiveWhen(factor="plug_family", values=("type_a_flat_blade",)),
                ActiveWhen(factor="type_a_construction", values=("fixed",)),
            ),
        ),
        JointMount(
            name="folding-type-a-blades-retained-by-housing",
            joint="folding_plug_hinge",
            parent_part="adapter",
            child_part="folding_plug",
            allowed_joint_types=("revolute",),
            active_when=(
                ActiveWhen(factor="plug_family", values=("type_a_flat_blade",)),
                ActiveWhen(factor="type_a_construction", values=("folding",)),
            ),
        ),
        RigidMount(
            name="ground-ac-pin-mounted-to-housing",
            parent_part="adapter",
            parent_element="housing_shell",
            child_part="adapter",
            child_element="ac_ground_pin",
            active_when=(ActiveWhen(factor="plug_family", values=("type_g_rectangular_pin",)),),
        ),
        RigidMount(
            name="primary-output-tongue-mounted-in-housing",
            parent_part="adapter",
            parent_element="housing_shell",
            child_part="adapter",
            child_element="output_tongue_primary",
        ),
        RigidMount(
            name="secondary-output-tongue-mounted-in-housing",
            parent_part="adapter",
            parent_element="housing_shell",
            child_part="adapter",
            child_element="output_tongue_secondary",
            active_when=(
                ActiveWhen(
                    factor="output_configuration",
                    values=("dual_usb_a", "dual_usb_a_c", "dual_usb_c"),
                ),
            ),
        ),
    ),
    constraints=(
        Constraint(
            name="type-g-housing-footprint",
            predicate=_type_g_footprint_fits,
            message="The complete Type G pin pattern must remain inside the rounded housing face.",
        ),
        Constraint(
            name="output-layout-fits-housing-face",
            predicate=_output_layout_fits,
            message="Every complete USB opening and required casing margin must fit the face.",
        ),
    ),
    population_checks=(
        PopulationCheck(
            name="plug-families-covered",
            predicate=lambda samples: _covers_choices(
                samples,
                "plug_family",
                {
                    "type_a_flat_blade",
                    "type_c_round_pin",
                    "type_g_rectangular_pin",
                },
            ),
            message="Samples must cover every authored AC pin topology.",
        ),
        PopulationCheck(
            name="type-a-constructions-covered",
            predicate=_covers_type_a_constructions,
            message="Type A samples must cover both fixed and fold-away blade constructions.",
        ),
        PopulationCheck(
            name="output-configurations-covered",
            predicate=lambda samples: _covers_choices(
                samples,
                "output_configuration",
                {
                    "single_usb_a",
                    "dual_usb_a",
                    "dual_usb_c",
                },
            ),
            message="Samples must exercise a single output and homogeneous legacy and modern dual branches.",
        ),
        PopulationCheck(
            name="housing-width-envelope-covered",
            predicate=lambda samples: _covers_bounds(
                samples,
                "body_width",
                minimum_at_most=0.033,
                maximum_at_least=0.049,
            ),
            message="Samples must exercise the requested 0.032-0.050 m housing-width envelope.",
        ),
        PopulationCheck(
            name="housing-height-envelope-covered",
            predicate=lambda samples: _covers_bounds(
                samples,
                "body_height",
                minimum_at_most=0.021,
                maximum_at_least=0.069,
            ),
            message="Samples must exercise the requested 0.020-0.070 m housing-height envelope.",
        ),
        PopulationCheck(
            name="housing-depth-envelope-covered",
            predicate=lambda samples: _covers_bounds(
                samples,
                "body_depth",
                minimum_at_most=0.027,
                maximum_at_least=0.063,
            ),
            message="Samples must exercise shallow and deep wall-adapter housings.",
        ),
    ),
    task_requirements=(
        "The housing spans 0.032-0.050 m in global X and 0.020-0.070 m in global Z.",
        "Every sample must have wall-facing AC plug geometry and at least one genuine full-depth device-facing USB charging output.",
        "Every fixed AC pin and USB tongue must remain mounted over a finite root face; folding blades must remain retained through their revolute rotor.",
    ),
    tags=(
        "phone charger",
        "wall power adapter",
        "usb-a",
        "usb-c",
        "type-a-plug",
        "type-c-plug",
        "type-g-plug",
    ),
)
