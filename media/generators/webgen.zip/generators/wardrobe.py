from __future__ import annotations

import math
from typing import Any, Mapping

from assetengine import (
    ActiveWhen,
    Derived,
    GeneratorDesign,
    GeneratorSpec,
    JointMount,
    PopulationCheck,
    RelativeUniformFloat,
    RigidMount,
    UniformChoice,
    UniformFloat,
    UniformInt,
)
from assetengine.articraft import (
    ArticulatedObject,
    ArticulationType,
    Box,
    BoxGeometry,
    Cylinder,
    ExtrudeGeometry,
    ExtrudeWithHolesGeometry,
    MotionLimits,
    Origin,
    Sphere,
    TestContext,
    mesh_from_geometry,
    rounded_rect_profile,
)


def _add_box(part, name: str, size, xyz, material) -> None:
    part.visual(Box(tuple(size)), origin=Origin(xyz=tuple(xyz)), material=material, name=name)


def _door_panel_geometry(parameters: Mapping[str, Any], x_direction: float):
    door_width = parameters["door_width"]
    door_height = parameters["door_height"]
    door_thickness = parameters["door_thickness"]
    if parameters["door_motion"] != "sliding":
        return BoxGeometry((door_width, door_thickness, door_height)).translate(
            x_direction * door_width / 2.0, -door_thickness / 2.0, 0.0
        )

    recess_width = parameters["recess_width"]
    recess_height = parameters["recess_height"]
    recess_depth = parameters["recess_depth"]
    recess_radius = 0.5 * min(recess_width, recess_height) * parameters["recess_roundness"]
    recess_x = x_direction * (door_width - parameters["recess_edge_offset"])
    recess_z = parameters["handle_center_height"] - parameters["case_height"] / 2.0
    x_min, x_max = (0.0, door_width) if x_direction > 0.0 else (-door_width, 0.0)
    outer_profile = (
        (x_min, -door_height / 2.0),
        (x_max, -door_height / 2.0),
        (x_max, door_height / 2.0),
        (x_min, door_height / 2.0),
    )
    recess_profile = tuple(
        (x + recess_x, z + recess_z)
        for x, z in rounded_rect_profile(recess_width, recess_height, recess_radius)
    )
    return (
        ExtrudeWithHolesGeometry(
            outer_profile,
            (recess_profile,),
            door_thickness,
        )
        .rotate_x(math.pi / 2.0)
        .translate(0.0, -door_thickness / 2.0, 0.0)
    )


def _add_door_geometry(part, side: str, parameters: Mapping[str, Any], panel_material, hardware):
    door_width = parameters["door_width"]
    door_height = parameters["door_height"]
    door_thickness = parameters["door_thickness"]
    door_motion = parameters["door_motion"]
    face_profile = parameters["door_face_profile"]
    x_direction = 1.0 if side == "left" else -1.0

    if door_motion == "sliding":
        part.visual(
            mesh_from_geometry(
                _door_panel_geometry(parameters, x_direction),
                f"{side}_recessed_door_panel",
            ),
            material=panel_material,
            name="door_panel",
        )
        recess_width = parameters["recess_width"]
        recess_height = parameters["recess_height"]
        recess_depth = parameters["recess_depth"]
        recess_x = x_direction * (door_width - parameters["recess_edge_offset"])
        recess_z = parameters["handle_center_height"] - parameters["case_height"] / 2.0
        free_edge_margin = parameters["recess_edge_offset"] - recess_width / 2.0
        vertical_margin = door_height / 2.0 - abs(recess_z) - recess_height / 2.0
        backing_lip = min(0.003, 0.45 * free_edge_margin, 0.45 * vertical_margin)
        backing_thickness = door_thickness - recess_depth
        _add_box(
            part,
            "recess_backing",
            (
                recess_width + 2.0 * backing_lip,
                backing_thickness,
                recess_height + 2.0 * backing_lip,
            ),
            (
                recess_x,
                -(door_thickness + recess_depth) / 2.0,
                recess_z,
            ),
            hardware,
        )
        part.meta["door_geometry_signature"] = (
            "sliding_recessed",
            door_width,
            door_height,
            door_thickness,
            parameters["recess_width"],
            parameters["recess_height"],
            parameters["recess_depth"],
            parameters["recess_edge_offset"],
            parameters["recess_roundness"],
        )
        return

    _add_box(
        part,
        "door_panel",
        (door_width, door_thickness, door_height),
        (x_direction * door_width / 2.0, -door_thickness / 2.0, 0.0),
        panel_material,
    )

    mount_y = 0.0
    if face_profile == "raised_frame":
        frame_width = parameters["door_frame_width"]
        frame_raise = parameters["door_frame_raise"]
        mount_y = frame_raise
        _add_box(
            part,
            "door_frame_hinge_stile",
            (frame_width, frame_raise, door_height),
            (x_direction * frame_width / 2.0, frame_raise / 2.0, 0.0),
            panel_material,
        )
        _add_box(
            part,
            "door_frame_free_stile",
            (frame_width, frame_raise, door_height),
            (
                x_direction * (door_width - frame_width / 2.0),
                frame_raise / 2.0,
                0.0,
            ),
            panel_material,
        )
        rail_width = door_width - 2.0 * frame_width
        for name, z_value in (
            ("door_frame_lower_rail", -door_height / 2.0 + frame_width / 2.0),
            ("door_frame_upper_rail", door_height / 2.0 - frame_width / 2.0),
        ):
            _add_box(
                part,
                name,
                (rail_width, frame_raise, frame_width),
                (x_direction * door_width / 2.0, frame_raise / 2.0, z_value),
                panel_material,
            )

    handle_x = x_direction * (
        door_width - parameters["door_frame_width"] / 2.0
        if face_profile == "raised_frame"
        else door_width - parameters["handle_edge_offset"]
    )
    handle_z = parameters["handle_center_height"] - parameters["case_height"] / 2.0
    handle_style = parameters["handle_style"]

    if handle_style == "bar_pull":
        handle_span = parameters["bar_handle_span"]
        member_width = parameters["bar_member_width"]
        member_depth = parameters["bar_member_depth"]
        projection = parameters["bar_projection"]
        root_depth = projection - member_depth / 2.0
        root_offset = handle_span / 2.0 - member_width / 2.0
        for name, z_value in (
            ("handle_lower_root", handle_z - root_offset),
            ("handle_upper_root", handle_z + root_offset),
        ):
            _add_box(
                part,
                name,
                (member_width, root_depth, member_width),
                (handle_x, mount_y + root_depth / 2.0, z_value),
                hardware,
            )

        section_radius = 0.5 * min(member_width, member_depth) * parameters["bar_section_roundness"]
        grip = ExtrudeGeometry.centered(
            rounded_rect_profile(member_width, member_depth, section_radius),
            handle_span,
        ).translate(
            handle_x,
            mount_y + projection - member_depth / 2.0,
            handle_z,
        )
        part.visual(
            mesh_from_geometry(grip, f"{side}_bar_handle_grip"),
            material=hardware,
            name="handle_grip",
        )
    else:
        knob_radius = parameters["knob_radius"]
        knob_projection = parameters["knob_projection"]
        stem_radius = 0.28 * knob_radius
        part.visual(
            Cylinder(radius=stem_radius, length=knob_projection),
            origin=Origin(
                xyz=(handle_x, mount_y + knob_projection / 2.0, handle_z),
                rpy=(-math.pi / 2.0, 0.0, 0.0),
            ),
            material=hardware,
            name="handle_knob_root",
        )
        part.visual(
            Sphere(radius=knob_radius),
            origin=Origin(xyz=(handle_x, mount_y + knob_projection, handle_z)),
            material=hardware,
            name="handle_knob",
        )

    part.meta["door_geometry_signature"] = (
        "hinged",
        door_width,
        door_height,
        door_thickness,
        face_profile,
        parameters["door_frame_width"],
        parameters["door_frame_raise"],
        handle_style,
        abs(handle_x),
        handle_z,
        parameters["bar_handle_span"],
        parameters["bar_member_width"],
        parameters["bar_member_depth"],
        parameters["bar_projection"],
        parameters["bar_section_roundness"],
        parameters["knob_radius"],
        parameters["knob_projection"],
    )


def build_model(parameters: Mapping[str, Any]):
    width = parameters["overall_width"]
    depth = parameters["overall_depth"]
    support_height = parameters["support_height"]
    case_height = parameters["case_height"]
    wall = parameters["wall_thickness"]
    back = parameters["back_thickness"]
    inner_width = parameters["inner_width"]
    inner_height = parameters["inner_height"]

    model = ArticulatedObject(name="two_door_wardrobe")
    carcass_material = model.material("neutral_carcass", rgba=(0.72, 0.70, 0.66, 1.0))
    panel_material = model.material("neutral_doors", rgba=(0.78, 0.76, 0.72, 1.0))
    hardware = model.material("neutral_hardware", rgba=(0.28, 0.29, 0.30, 1.0))

    carcass = model.part("wardrobe_carcass")
    case_center_z = support_height + case_height / 2.0
    _add_box(
        carcass,
        "carcass_left_side",
        (wall, depth, case_height),
        (-width / 2.0 + wall / 2.0, 0.0, case_center_z),
        carcass_material,
    )
    _add_box(
        carcass,
        "carcass_right_side",
        (wall, depth, case_height),
        (width / 2.0 - wall / 2.0, 0.0, case_center_z),
        carcass_material,
    )
    _add_box(
        carcass,
        "carcass_bottom",
        (inner_width, depth, wall),
        (0.0, 0.0, support_height + wall / 2.0),
        carcass_material,
    )
    _add_box(
        carcass,
        "carcass_top",
        (inner_width, depth, wall),
        (0.0, 0.0, support_height + case_height - wall / 2.0),
        carcass_material,
    )
    _add_box(
        carcass,
        "carcass_back",
        (inner_width, back, inner_height),
        (0.0, -depth / 2.0 + back / 2.0, case_center_z),
        carcass_material,
    )

    support_inset = parameters["support_inset"]
    if parameters["support_style"] == "plinth":
        _add_box(
            carcass,
            "support_plinth",
            (inner_width - 2.0 * support_inset, depth - 2.0 * support_inset, support_height),
            (0.0, 0.0, support_height / 2.0),
            carcass_material,
        )
    else:
        foot_width = parameters["foot_width"]
        foot_depth = parameters["foot_depth"]
        foot_x = inner_width / 2.0 - support_inset - foot_width / 2.0
        foot_y = depth / 2.0 - support_inset - foot_depth / 2.0
        for name, x_value, y_value in (
            ("support_front_left_foot", -foot_x, foot_y),
            ("support_front_right_foot", foot_x, foot_y),
            ("support_rear_left_foot", -foot_x, -foot_y),
            ("support_rear_right_foot", foot_x, -foot_y),
        ):
            _add_box(
                carcass,
                name,
                (foot_width, foot_depth, support_height),
                (x_value, y_value, support_height / 2.0),
                carcass_material,
            )

    shelf_depth = depth - back
    shelf_y = back / 2.0
    rail_y = -depth / 2.0 + back + parameters["rail_distance_from_back"]
    rail_radius = parameters["rail_radius"]
    interior_top = support_height + case_height - wall
    interior_bottom = support_height + wall
    rail_drop = parameters["rail_drop"]
    interior_layout = parameters["interior_layout"]

    if interior_layout == "top_shelf_and_hanging":
        shelf_z = interior_top - parameters["top_compartment_height"] - wall / 2.0
        _add_box(
            carcass,
            "interior_top_shelf",
            (inner_width, shelf_depth, wall),
            (0.0, shelf_y, shelf_z),
            carcass_material,
        )
        rail_z = shelf_z - wall / 2.0 - rail_drop
        rail_center_x = 0.0
        rail_length = inner_width
        rail_name = "full_hanging_rail"
    elif interior_layout == "split_shelves_and_hanging":
        divider_height = inner_height
        _add_box(
            carcass,
            "interior_divider",
            (wall, shelf_depth, divider_height),
            (0.0, shelf_y, case_center_z),
            carcass_material,
        )
        half_span = inner_width / 2.0 - wall / 2.0
        shelf_center_x = -width / 4.0 + wall / 4.0
        shelf_count = parameters["shelf_count"]
        for index in range(shelf_count):
            fraction = (index + 1.0) / (shelf_count + 1.0)
            shelf_z = interior_bottom + fraction * inner_height
            _add_box(
                carcass,
                f"split_shelf_{index + 1}",
                (half_span, shelf_depth, wall),
                (shelf_center_x, shelf_y, shelf_z),
                carcass_material,
            )
        rail_center_x = width / 4.0 - wall / 4.0
        rail_length = half_span
        rail_z = interior_top - rail_drop
        rail_name = "split_hanging_rail"
    else:
        rail_center_x = 0.0
        rail_length = inner_width
        rail_z = interior_top - rail_drop
        rail_name = "full_hanging_rail"

    carcass.visual(
        Cylinder(radius=rail_radius, length=rail_length),
        origin=Origin(
            xyz=(rail_center_x, rail_y, rail_z),
            rpy=(0.0, math.pi / 2.0, 0.0),
        ),
        material=hardware,
        name=rail_name,
    )

    left_door = model.part("left_door")
    right_door = model.part("right_door")
    _add_door_geometry(left_door, "left", parameters, panel_material, hardware)
    _add_door_geometry(right_door, "right", parameters, panel_material, hardware)

    perimeter_gap = parameters["door_perimeter_gap"]
    door_thickness = parameters["door_thickness"]
    hinge_or_track_y = depth / 2.0 + parameters["door_front_gap"] + door_thickness
    door_center_z = support_height + case_height / 2.0
    left_x = -width / 2.0 + perimeter_gap
    right_x = width / 2.0 - perimeter_gap

    if parameters["door_motion"] == "hinged":
        joint_type = ArticulationType.REVOLUTE
        motion_limits = MotionLimits(
            lower=0.0,
            upper=parameters["hinged_open_angle"],
            effort=12.0,
            velocity=1.2,
        )
        left_origin = Origin(xyz=(left_x, hinge_or_track_y, door_center_z))
        right_origin = Origin(xyz=(right_x, hinge_or_track_y, door_center_z))
    else:
        joint_type = ArticulationType.PRISMATIC
        motion_limits = MotionLimits(
            lower=0.0,
            upper=parameters["sliding_travel"],
            effort=20.0,
            velocity=0.5,
        )
        left_origin = Origin(xyz=(left_x, hinge_or_track_y, door_center_z))
        right_origin = Origin(
            xyz=(
                right_x,
                hinge_or_track_y + door_thickness + parameters["sliding_track_gap"],
                door_center_z,
            )
        )

    model.articulation(
        "carcass_to_left_door",
        joint_type,
        parent=carcass,
        child=left_door,
        origin=left_origin,
        axis=(0.0, 0.0, 1.0) if joint_type == ArticulationType.REVOLUTE else (1.0, 0.0, 0.0),
        motion_limits=motion_limits,
    )
    model.articulation(
        "carcass_to_right_door",
        joint_type,
        parent=carcass,
        child=right_door,
        origin=right_origin,
        axis=(0.0, 0.0, -1.0) if joint_type == ArticulationType.REVOLUTE else (-1.0, 0.0, 0.0),
        motion_limits=motion_limits,
    )

    return model


def run_tests(model, parameters):
    ctx = TestContext(model)
    ctx.check_model_valid()
    ctx.allow_isolated_part(
        "left_door",
        reason="The declared moving joint mechanically retains this non-contacting door link.",
    )
    ctx.allow_isolated_part(
        "right_door",
        reason="The declared moving joint mechanically retains this non-contacting door link.",
    )
    parts = {part.name: part for part in model.parts}
    ctx.check(
        "exactly-two-door-parts",
        {name for name in parts if name.endswith("_door")} == {"left_door", "right_door"},
    )
    ctx.check(
        "doors-are-congruent",
        parts["left_door"].meta.get("door_geometry_signature")
        == parts["right_door"].meta.get("door_geometry_signature"),
        "Both side-by-side doors must use the same dimensions, profile, and handle geometry.",
    )
    ctx.expect_gap(
        "right_door",
        "left_door",
        axis="x",
        min_gap=parameters["door_center_gap"] - 2e-5,
        positive_elem="door_panel",
        negative_elem="door_panel",
        name="closed-doors-have-horizontal-center-gap",
    )
    ctx.expect_gap(
        "left_door",
        "wardrobe_carcass",
        axis="y",
        min_gap=parameters["door_front_gap"] - 2e-5,
        name="doors-close-in-front-of-carcass",
    )
    left_panel_bounds = ctx.part_element_world_aabb("left_door", elem="door_panel")
    right_panel_bounds = ctx.part_element_world_aabb("right_door", elem="door_panel")
    ctx.check(
        "door-panels-share-global-vertical-span",
        left_panel_bounds is not None
        and right_panel_bounds is not None
        and abs(left_panel_bounds[0][2] - right_panel_bounds[0][2]) <= 1e-8
        and abs(left_panel_bounds[1][2] - right_panel_bounds[1][2]) <= 1e-8,
        "Corresponding door panels must remain horizontally mirrored, never vertically flipped.",
    )
    ctx.fail_if_parts_overlap_in_current_pose(name="closed-door-assembly-is-collision-free")
    ctx.fail_if_articulation_overlaps(
        max_pose_samples=9,
        name="door-motion-is-collision-free-at-decisive-poses",
    )

    if parameters["door_motion"] == "hinged":
        q1 = min(parameters["hinged_open_angle"], math.pi / 2.0)
        min_motion = parameters["door_width"] * 0.35
        ctx.expect_joint_motion_axis(
            "carcass_to_left_door",
            "left_door",
            world_axis="y",
            direction="positive",
            min_delta=min_motion,
            q0=0.0,
            q1=q1,
            name="left-door-swings-outward",
        )
        ctx.expect_joint_motion_axis(
            "carcass_to_right_door",
            "right_door",
            world_axis="y",
            direction="positive",
            min_delta=min_motion,
            q0=0.0,
            q1=q1,
            name="right-door-swings-outward",
        )
        with ctx.pose(
            {
                "carcass_to_left_door": parameters["hinged_open_angle"],
                "carcass_to_right_door": parameters["hinged_open_angle"],
            }
        ):
            ctx.fail_if_parts_overlap_in_current_pose(
                name="both-hinged-doors-clear-at-maximum-open-pose"
            )
    else:
        q1 = parameters["sliding_travel"]
        ctx.expect_joint_motion_axis(
            "carcass_to_left_door",
            "left_door",
            world_axis="x",
            direction="positive",
            min_delta=q1 * 0.9,
            q0=0.0,
            q1=q1,
            name="left-door-slides-right",
        )
        ctx.expect_joint_motion_axis(
            "carcass_to_right_door",
            "right_door",
            world_axis="x",
            direction="negative",
            min_delta=q1 * 0.9,
            q0=0.0,
            q1=q1,
            name="right-door-slides-left",
        )
        with ctx.pose(
            {
                "carcass_to_left_door": q1,
                "carcass_to_right_door": q1,
            }
        ):
            ctx.expect_within(
                "left_door",
                "wardrobe_carcass",
                axes="xz",
                name="left-sliding-door-remains-retained-at-maximum-travel",
            )
            ctx.expect_within(
                "right_door",
                "wardrobe_carcass",
                axes="xz",
                name="right-sliding-door-remains-retained-at-maximum-travel",
            )
            ctx.fail_if_parts_overlap_in_current_pose(
                name="both-sliding-doors-clear-at-maximum-open-pose"
            )
    return ctx.report()


def _mount(
    name: str,
    parent_element: str,
    child_element: str,
    *active_when: ActiveWhen,
) -> RigidMount:
    return RigidMount(
        name=name,
        parent_part="wardrobe_carcass",
        parent_element=parent_element,
        child_part="wardrobe_carcass",
        child_element=child_element,
        active_when=tuple(active_when),
    )


CARCASS_RELATIONSHIPS = (
    _mount("left-side-seated-on-bottom", "carcass_bottom", "carcass_left_side"),
    _mount("right-side-seated-on-bottom", "carcass_bottom", "carcass_right_side"),
    _mount("top-seated-on-left-side", "carcass_left_side", "carcass_top"),
    _mount("top-seated-on-right-side", "carcass_right_side", "carcass_top"),
    _mount("back-seated-on-left-side", "carcass_left_side", "carcass_back"),
    _mount("back-seated-on-right-side", "carcass_right_side", "carcass_back"),
    _mount("back-seated-on-bottom", "carcass_bottom", "carcass_back"),
    _mount("back-seated-on-top", "carcass_top", "carcass_back"),
    _mount(
        "plinth-mounted-to-bottom",
        "carcass_bottom",
        "support_plinth",
        ActiveWhen(factor="support_style", values=("plinth",)),
    ),
    *tuple(
        _mount(
            f"{position}-foot-mounted-to-bottom",
            "carcass_bottom",
            f"support_{position}_foot",
            ActiveWhen(factor="support_style", values=("four_legs",)),
        )
        for position in ("front_left", "front_right", "rear_left", "rear_right")
    ),
    _mount(
        "top-shelf-mounted-to-left-side",
        "carcass_left_side",
        "interior_top_shelf",
        ActiveWhen(factor="interior_layout", values=("top_shelf_and_hanging",)),
    ),
    _mount(
        "top-shelf-mounted-to-right-side",
        "carcass_right_side",
        "interior_top_shelf",
        ActiveWhen(factor="interior_layout", values=("top_shelf_and_hanging",)),
    ),
    _mount(
        "top-shelf-mounted-to-back",
        "carcass_back",
        "interior_top_shelf",
        ActiveWhen(factor="interior_layout", values=("top_shelf_and_hanging",)),
    ),
    _mount(
        "full-rail-mounted-to-left-side",
        "carcass_left_side",
        "full_hanging_rail",
        ActiveWhen(
            factor="interior_layout",
            values=("hanging_only", "top_shelf_and_hanging"),
        ),
    ),
    _mount(
        "full-rail-mounted-to-right-side",
        "carcass_right_side",
        "full_hanging_rail",
        ActiveWhen(
            factor="interior_layout",
            values=("hanging_only", "top_shelf_and_hanging"),
        ),
    ),
    _mount(
        "divider-mounted-to-bottom",
        "carcass_bottom",
        "interior_divider",
        ActiveWhen(factor="interior_layout", values=("split_shelves_and_hanging",)),
    ),
    _mount(
        "divider-mounted-to-top",
        "carcass_top",
        "interior_divider",
        ActiveWhen(factor="interior_layout", values=("split_shelves_and_hanging",)),
    ),
    _mount(
        "divider-mounted-to-back",
        "carcass_back",
        "interior_divider",
        ActiveWhen(factor="interior_layout", values=("split_shelves_and_hanging",)),
    ),
    _mount(
        "split-rail-mounted-to-divider",
        "interior_divider",
        "split_hanging_rail",
        ActiveWhen(factor="interior_layout", values=("split_shelves_and_hanging",)),
    ),
    _mount(
        "split-rail-mounted-to-right-side",
        "carcass_right_side",
        "split_hanging_rail",
        ActiveWhen(factor="interior_layout", values=("split_shelves_and_hanging",)),
    ),
    *tuple(
        relationship
        for shelf_index in range(1, 6)
        for relationship in (
            _mount(
                f"split-shelf-{shelf_index}-mounted-to-left-side",
                "carcass_left_side",
                f"split_shelf_{shelf_index}",
                ActiveWhen(factor="interior_layout", values=("split_shelves_and_hanging",)),
                ActiveWhen(factor="shelf_count", values=tuple(range(max(2, shelf_index), 6))),
            ),
            _mount(
                f"split-shelf-{shelf_index}-mounted-to-divider",
                "interior_divider",
                f"split_shelf_{shelf_index}",
                ActiveWhen(factor="interior_layout", values=("split_shelves_and_hanging",)),
                ActiveWhen(factor="shelf_count", values=tuple(range(max(2, shelf_index), 6))),
            ),
            _mount(
                f"split-shelf-{shelf_index}-mounted-to-back",
                "carcass_back",
                f"split_shelf_{shelf_index}",
                ActiveWhen(factor="interior_layout", values=("split_shelves_and_hanging",)),
                ActiveWhen(factor="shelf_count", values=tuple(range(max(2, shelf_index), 6))),
            ),
        )
    ),
)


def _door_relationships(side: str):
    part = f"{side}_door"
    relationships = []
    relationships.append(
        RigidMount(
            name=f"{side}-recess-backing-mounted-to-panel",
            parent_part=part,
            parent_element="door_panel",
            child_part=part,
            child_element="recess_backing",
            active_when=(ActiveWhen(factor="door_motion", values=("sliding",)),),
        )
    )
    for element in (
        "door_frame_hinge_stile",
        "door_frame_free_stile",
        "door_frame_lower_rail",
        "door_frame_upper_rail",
    ):
        relationships.append(
            RigidMount(
                name=f"{side}-{element.replace('_', '-')}-mounted-to-panel",
                parent_part=part,
                parent_element="door_panel",
                child_part=part,
                child_element=element,
                active_when=(
                    ActiveWhen(factor="door_motion", values=("hinged",)),
                    ActiveWhen(factor="door_face_profile", values=("raised_frame",)),
                ),
            )
        )
    for root in ("handle_lower_root", "handle_upper_root"):
        for profile, parent_element in (
            ("slab", "door_panel"),
            ("raised_frame", "door_frame_free_stile"),
        ):
            relationships.append(
                RigidMount(
                    name=f"{side}-{root.replace('_', '-')}-mounted-to-{profile}",
                    parent_part=part,
                    parent_element=parent_element,
                    child_part=part,
                    child_element=root,
                    active_when=(
                        ActiveWhen(factor="door_motion", values=("hinged",)),
                        ActiveWhen(factor="door_face_profile", values=(profile,)),
                        ActiveWhen(factor="handle_style", values=("bar_pull",)),
                    ),
                )
            )
    for profile, parent_element in (
        ("slab", "door_panel"),
        ("raised_frame", "door_frame_free_stile"),
    ):
        relationships.append(
            RigidMount(
                name=f"{side}-knob-root-mounted-to-{profile}",
                parent_part=part,
                parent_element=parent_element,
                child_part=part,
                child_element="handle_knob_root",
                active_when=(
                    ActiveWhen(factor="door_motion", values=("hinged",)),
                    ActiveWhen(factor="door_face_profile", values=(profile,)),
                    ActiveWhen(factor="handle_style", values=("knob",)),
                ),
            )
        )
    return tuple(relationships)


GENERATOR = GeneratorSpec(
    name="two_door_wardrobe",
    category="two_door_wardrobe",
    description=(
        "Ordinary freestanding household wardrobe with two congruent full-height doors arranged "
        "side-by-side across its width."
    ),
    design=GeneratorDesign(
        coverage=(
            "Freestanding household two-door wardrobes from compact to large ordinary sizes, "
            "including hinged and two-track bypass-sliding doors, slab and common raised-frame "
            "hinged faces, hanging-only, top-shelf-plus-hanging, and split shelf/hanging interiors, "
            "and recessed plinth or four-leg supports. The required horizontal stack means two "
            "equal full-height leaves side-by-side, not one above the other. Built-ins, walk-ins, "
            "corner units, fabric wardrobes, external drawers, ornate mouldings, and specialty "
            "multi-panel systems are excluded. The shared 0.75-1.60 m width envelope is "
            "intentional: compact two-track wardrobes and broad two-hinge-leaf wardrobes both "
            "occur in ordinary household ranges, while smaller cupboards and wider multi-panel "
            "systems remain outside scope."
        ),
        factors=(
            "Overall width, depth, and height vary independently across the ordinary envelope. "
            "Board, back, and door thicknesses remain independent; clearances and handle member "
            "dimensions are separately observable. Case/cavity and equal door dimensions are "
            "derived. Door-face and hinged-handle controls are conditional on hinged construction; "
            "recess controls and travel are conditional on sliding construction; shelf count is "
            "conditional on the split interior. Rail position and size, support geometry, frame "
            "width/raise, handle path, independent in-plane width/out-of-plane depth, projection, "
            "and continuous section roundness span their real geometric dependencies."
        ),
        components=(
            "Every model has a five-panel carcass with a real open storage cavity, a hanging rail, "
            "two congruent door assemblies, and floor supports. Interiors vary through shelves and "
            "a divider; door faces vary between planar and four-member raised frames; hinged doors "
            "use either a two-root rounded-rectangle bar pull or a rooted knob, while sliding doors "
            "use a genuine shallow recessed pull so bypass motion remains coherent. Incidental "
            "fasteners, textures, and hinge/track hardware are omitted."
        ),
        physics_and_task=(
            "The carcass panels form a zero-gap attachment graph through bottom, sides, top, and "
            "back. Plinths or all four finite-footprint legs seat on the bottom; shelves seat on "
            "side/divider and back surfaces; each rail seats at both ends. Raised-frame members and "
            "each handle root seat on their complete local door surface. The two doors are moving "
            "children of the carcass through matching revolute or prismatic joints, retain a real "
            "closed center gap, and move outward or along separate bypass tracks without an "
            "invented robot/tool clearance. Articulation-aware isolation allowances express the "
            "joint retention of non-contacting moving links; decisive closed, sampled, and "
            "maximum-open poses remain collision checked."
        ),
    ),
    factors=(
        UniformFloat(
            name="overall_width",
            low=0.75,
            high=1.60,
            description="Overall left-to-right wardrobe width.",
            unit="m",
        ),
        UniformFloat(
            name="overall_depth",
            low=0.45,
            high=0.70,
            description="Overall carcass depth from back to front.",
            unit="m",
        ),
        UniformFloat(
            name="overall_height",
            low=1.65,
            high=2.35,
            description="Overall floor-to-top height including the support.",
            unit="m",
        ),
        UniformFloat(
            name="wall_thickness",
            low=0.014,
            high=0.030,
            description="Thickness of the carcass boards and interior panels.",
            unit="m",
        ),
        UniformFloat(
            name="back_thickness",
            low=0.006,
            high=0.016,
            description="Thickness of the rear closure panel.",
            unit="m",
        ),
        UniformChoice(
            name="support_style",
            choices=("plinth", "four_legs"),
            description="Distinct floor-support construction.",
        ),
        UniformFloat(
            name="support_height",
            low=0.04,
            high=0.16,
            description="Height of the plinth or four legs below the carcass.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="support_inset",
            reference="overall_depth",
            ratio_low=0.035,
            ratio_high=0.11,
            hard_min=0.015,
            hard_max=0.070,
            description="Inset of the support footprint from the carcass edges.",
            unit="m",
        ),
        UniformFloat(
            name="foot_width",
            low=0.04,
            high=0.09,
            active_when=(ActiveWhen(factor="support_style", values=("four_legs",)),),
            description="Left-to-right width of each independent leg footprint.",
            unit="m",
        ),
        UniformFloat(
            name="foot_depth",
            low=0.04,
            high=0.10,
            active_when=(ActiveWhen(factor="support_style", values=("four_legs",)),),
            description="Front-to-back depth of each independent leg footprint.",
            unit="m",
        ),
        Derived(
            name="case_height",
            derive=lambda p: p["overall_height"] - p["support_height"],
            depends_on=("overall_height", "support_height"),
            description="Height of the enclosed wardrobe carcass above its support.",
            unit="m",
        ),
        Derived(
            name="inner_width",
            derive=lambda p: p["overall_width"] - 2.0 * p["wall_thickness"],
            depends_on=("overall_width", "wall_thickness"),
            description="Clear storage width between side panels.",
            unit="m",
        ),
        Derived(
            name="inner_height",
            derive=lambda p: p["case_height"] - 2.0 * p["wall_thickness"],
            depends_on=("case_height", "wall_thickness"),
            description="Clear storage height between bottom and top panels.",
            unit="m",
        ),
        UniformChoice(
            name="interior_layout",
            choices=("hanging_only", "top_shelf_and_hanging", "split_shelves_and_hanging"),
            description="Common wardrobe storage topology behind the doors.",
        ),
        UniformInt(
            name="shelf_count",
            low=2,
            high=5,
            active_when=(
                ActiveWhen(factor="interior_layout", values=("split_shelves_and_hanging",)),
            ),
            description="Number of shelves on the shelved side of a split interior.",
            unit="count",
        ),
        RelativeUniformFloat(
            name="top_compartment_height",
            reference="case_height",
            ratio_low=0.12,
            ratio_high=0.22,
            hard_min=0.20,
            hard_max=0.46,
            active_when=(ActiveWhen(factor="interior_layout", values=("top_shelf_and_hanging",)),),
            description="Clear height of the storage space above the full-width top shelf.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="rail_distance_from_back",
            reference="overall_depth",
            ratio_low=0.36,
            ratio_high=0.58,
            hard_min=0.17,
            hard_max=0.38,
            description="Hanging-rail center distance forward from the inner back surface.",
            unit="m",
        ),
        UniformFloat(
            name="rail_drop",
            low=0.08,
            high=0.20,
            description="Vertical drop from the panel above to the hanging-rail center.",
            unit="m",
        ),
        UniformFloat(
            name="rail_radius",
            low=0.009,
            high=0.018,
            description="Radius of the deliberately circular hanging rail.",
            unit="m",
        ),
        UniformChoice(
            name="door_motion",
            choices=("hinged", "sliding"),
            description="Distinct hinged-leaf or two-track bypass construction.",
        ),
        UniformFloat(
            name="door_thickness",
            low=0.016,
            high=0.032,
            description="Thickness shared exactly by both doors.",
            unit="m",
        ),
        UniformFloat(
            name="door_center_gap",
            low=0.004,
            high=0.016,
            description="Horizontal free gap between the two closed door leaves.",
            unit="m",
        ),
        UniformFloat(
            name="door_perimeter_gap",
            low=0.004,
            high=0.014,
            description="Equal clearance around the outer and top/bottom door edges.",
            unit="m",
        ),
        UniformFloat(
            name="door_front_gap",
            low=0.003,
            high=0.012,
            description="Free depth gap between the closed door backs and carcass front.",
            unit="m",
        ),
        Derived(
            name="door_width",
            derive=lambda p: (
                (p["overall_width"] - 2.0 * p["door_perimeter_gap"] - p["door_center_gap"]) / 2.0
            ),
            depends_on=("overall_width", "door_perimeter_gap", "door_center_gap"),
            description="Identical width of each side-by-side door leaf.",
            unit="m",
        ),
        Derived(
            name="door_height",
            derive=lambda p: p["case_height"] - 2.0 * p["door_perimeter_gap"],
            depends_on=("case_height", "door_perimeter_gap"),
            description="Identical full-height span of both door leaves.",
            unit="m",
        ),
        UniformChoice(
            name="door_face_profile",
            choices=("slab", "raised_frame"),
            active_when=(ActiveWhen(factor="door_motion", values=("hinged",)),),
            description="Planar or four-member raised face construction for hinged doors.",
        ),
        RelativeUniformFloat(
            name="door_frame_width",
            reference="door_width",
            ratio_low=0.07,
            ratio_high=0.15,
            hard_min=0.052,
            hard_max=0.095,
            active_when=(
                ActiveWhen(factor="door_motion", values=("hinged",)),
                ActiveWhen(factor="door_face_profile", values=("raised_frame",)),
            ),
            description="In-plane width shared by the raised door-frame rails and stiles.",
            unit="m",
        ),
        UniformFloat(
            name="door_frame_raise",
            low=0.004,
            high=0.016,
            active_when=(
                ActiveWhen(factor="door_motion", values=("hinged",)),
                ActiveWhen(factor="door_face_profile", values=("raised_frame",)),
            ),
            description="Out-of-plane projection of the raised door frame.",
            unit="m",
        ),
        UniformFloat(
            name="hinged_open_angle",
            low=math.radians(85.0),
            high=math.radians(120.0),
            active_when=(ActiveWhen(factor="door_motion", values=("hinged",)),),
            description="Maximum outward opening angle shared by both hinged doors.",
            unit="rad",
        ),
        UniformFloat(
            name="sliding_track_gap",
            low=0.004,
            high=0.014,
            active_when=(ActiveWhen(factor="door_motion", values=("sliding",)),),
            description="Free depth separation between the two bypass door tracks.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="sliding_travel",
            reference="door_width",
            ratio_low=0.65,
            ratio_high=0.95,
            active_when=(ActiveWhen(factor="door_motion", values=("sliding",)),),
            description="Horizontal opening travel of each bypass door.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="handle_center_height",
            reference="case_height",
            ratio_low=0.42,
            ratio_high=0.62,
            hard_min=0.70,
            hard_max=1.35,
            description="Handle center height above the bottom of the carcass.",
            unit="m",
        ),
        UniformChoice(
            name="handle_style",
            choices=("bar_pull", "knob"),
            active_when=(ActiveWhen(factor="door_motion", values=("hinged",)),),
            description="Distinct rooted handle topology for hinged doors.",
        ),
        RelativeUniformFloat(
            name="handle_edge_offset",
            reference="door_width",
            ratio_low=0.06,
            ratio_high=0.16,
            hard_min=0.035,
            hard_max=0.12,
            active_when=(
                ActiveWhen(factor="door_motion", values=("hinged",)),
                ActiveWhen(factor="door_face_profile", values=("slab",)),
            ),
            description="Horizontal distance from a slab door's free edge to its handle center.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="bar_handle_span",
            reference="door_height",
            ratio_low=0.05,
            ratio_high=0.18,
            hard_min=0.08,
            hard_max=0.38,
            active_when=(
                ActiveWhen(factor="door_motion", values=("hinged",)),
                ActiveWhen(factor="handle_style", values=("bar_pull",)),
            ),
            description="Overall vertical path length of each bar pull.",
            unit="m",
        ),
        UniformFloat(
            name="bar_member_width",
            low=0.010,
            high=0.032,
            active_when=(
                ActiveWhen(factor="door_motion", values=("hinged",)),
                ActiveWhen(factor="handle_style", values=("bar_pull",)),
            ),
            description="Independent in-plane width of the bar-pull stock and roots.",
            unit="m",
        ),
        UniformFloat(
            name="bar_member_depth",
            low=0.008,
            high=0.026,
            active_when=(
                ActiveWhen(factor="door_motion", values=("hinged",)),
                ActiveWhen(factor="handle_style", values=("bar_pull",)),
            ),
            description="Independent front-to-back thickness of the bar-pull grip.",
            unit="m",
        ),
        UniformFloat(
            name="bar_projection",
            low=0.030,
            high=0.070,
            active_when=(
                ActiveWhen(factor="door_motion", values=("hinged",)),
                ActiveWhen(factor="handle_style", values=("bar_pull",)),
            ),
            description="Projection from the door face to the front of the bar pull.",
            unit="m",
        ),
        UniformFloat(
            name="bar_section_roundness",
            low=0.0,
            high=1.0,
            active_when=(
                ActiveWhen(factor="door_motion", values=("hinged",)),
                ActiveWhen(factor="handle_style", values=("bar_pull",)),
            ),
            description="Continuous square-to-fully-rounded control for the bar cross-section.",
            unit="ratio",
        ),
        UniformFloat(
            name="knob_radius",
            low=0.012,
            high=0.024,
            active_when=(
                ActiveWhen(factor="door_motion", values=("hinged",)),
                ActiveWhen(factor="handle_style", values=("knob",)),
            ),
            description="Radius of each spherical hinged-door knob.",
            unit="m",
        ),
        UniformFloat(
            name="knob_projection",
            low=0.028,
            high=0.050,
            active_when=(
                ActiveWhen(factor="door_motion", values=("hinged",)),
                ActiveWhen(factor="handle_style", values=("knob",)),
            ),
            description="Distance from the door face to the center of each knob.",
            unit="m",
        ),
        UniformFloat(
            name="recess_width",
            low=0.028,
            high=0.060,
            active_when=(ActiveWhen(factor="door_motion", values=("sliding",)),),
            description="Horizontal width of each sliding-door recessed pull opening.",
            unit="m",
        ),
        UniformFloat(
            name="recess_height",
            low=0.070,
            high=0.180,
            active_when=(ActiveWhen(factor="door_motion", values=("sliding",)),),
            description="Vertical height of each sliding-door recessed pull opening.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="recess_depth",
            reference="door_thickness",
            ratio_low=0.25,
            ratio_high=0.58,
            hard_min=0.004,
            hard_max=0.014,
            active_when=(ActiveWhen(factor="door_motion", values=("sliding",)),),
            description="True inward depth of the shallow recessed pull cavity.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="recess_edge_offset",
            reference="recess_width",
            ratio_low=0.62,
            ratio_high=1.45,
            hard_min=0.025,
            hard_max=0.09,
            active_when=(ActiveWhen(factor="door_motion", values=("sliding",)),),
            description="Distance from the free door edge to the recessed pull center.",
            unit="m",
        ),
        UniformFloat(
            name="recess_roundness",
            low=0.08,
            high=1.0,
            active_when=(ActiveWhen(factor="door_motion", values=("sliding",)),),
            description="Continuous corner roundness of the recessed pull opening.",
            unit="ratio",
        ),
    ),
    relationships=(
        *CARCASS_RELATIONSHIPS,
        *_door_relationships("left"),
        *_door_relationships("right"),
        JointMount(
            name="left-door-guided-by-carcass",
            joint="carcass_to_left_door",
            parent_part="wardrobe_carcass",
            child_part="left_door",
            allowed_joint_types=("revolute", "prismatic"),
        ),
        JointMount(
            name="right-door-guided-by-carcass",
            joint="carcass_to_right_door",
            parent_part="wardrobe_carcass",
            child_part="right_door",
            allowed_joint_types=("revolute", "prismatic"),
        ),
    ),
    population_checks=(
        PopulationCheck(
            name="covers-ordinary-size-envelope",
            predicate=lambda samples: (
                min(p["overall_width"] for p in samples) <= 0.76
                and max(p["overall_width"] for p in samples) >= 1.59
                and min(p["overall_height"] for p in samples) <= 1.66
                and max(p["overall_height"] for p in samples) >= 2.34
                and min(p["overall_depth"] for p in samples) <= 0.46
                and max(p["overall_depth"] for p in samples) >= 0.69
            ),
            message="Population must exercise compact and large ordinary household wardrobes.",
        ),
        PopulationCheck(
            name="covers-common-construction-topologies",
            predicate=lambda samples: (
                {p["door_motion"] for p in samples} == {"hinged", "sliding"}
                and {p["support_style"] for p in samples} == {"plinth", "four_legs"}
                and {p["interior_layout"] for p in samples}
                == {"hanging_only", "top_shelf_and_hanging", "split_shelves_and_hanging"}
            ),
            message="Population must cover both door mechanisms, both supports, and all interiors.",
        ),
        PopulationCheck(
            name="preserves-identical-door-derivation",
            predicate=lambda samples: all(
                p["door_width"] > 0.34 and p["door_height"] > 1.45 for p in samples
            ),
            message="Both derived door leaves must remain full-size and physically meaningful.",
        ),
        PopulationCheck(
            name="covers-conditional-door-and-shelf-marginals",
            predicate=lambda samples: (
                {p["door_face_profile"] for p in samples if p["door_motion"] == "hinged"}
                == {"slab", "raised_frame"}
                and {p["handle_style"] for p in samples if p["door_motion"] == "hinged"}
                == {"bar_pull", "knob"}
                and min(p["shelf_count"] for p in samples) == 2
                and max(p["shelf_count"] for p in samples) == 5
            ),
            message=(
                "Population must cover both hinged faces, both hinged handles, and the marginal "
                "split-shelf count endpoints without a Cartesian sweep."
            ),
        ),
    ),
    build=build_model,
    tests=run_tests,
    task_requirements=(
        "Every sample must contain exactly two congruent full-height doors arranged side-by-side across the wardrobe width.",
        "Both doors must open through matching outward revolute motion or coherent separated-track bypass motion.",
        "The wardrobe must retain a real enclosed storage cavity with a mounted hanging rail behind the doors.",
    ),
    tags=("wardrobe", "household storage", "two identical doors", "side-by-side doors"),
)
