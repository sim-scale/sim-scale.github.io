from __future__ import annotations

import math
from typing import Any, Mapping, Sequence

import manifold3d
import numpy as np

from assetengine import (
    ActiveWhen,
    Constraint,
    Derived,
    GeneratorDesign,
    GeneratorSpec,
    JointMount,
    PopulationCheck,
    RelativeUniformFloat,
    RigidMount,
    UniformChoice,
    UniformFloat,
)
from assetengine.articraft import (
    ArticulatedObject,
    ArticulationType,
    Box,
    BoxGeometry,
    MeshGeometry,
    MotionLimits,
    Origin,
    TestContext,
    mesh_from_geometry,
    rounded_rect_profile,
    sweep_profile_along_spline,
)

_DRAWER_FACE_GAP = 0.003
_DRAWER_BOX_CLEARANCE = 0.004
_HANDLE_ROOT_STOCK = 0.010
_HANDLE_RADIAL_SEGMENTS = 20
_HANDLE_CURVE_SAMPLES = 10
_HANDLE_ROUND_FLAT_DEPTH_RATIO = 0.12


def _as_manifold(geometry: MeshGeometry, *, context: str) -> manifold3d.Manifold:
    mesh = manifold3d.Mesh(
        np.asarray(geometry.vertices, dtype=np.float32),
        np.asarray(geometry.faces, dtype=np.uint32),
    )
    solid = manifold3d.Manifold(mesh)
    if solid.status() != manifold3d.Error.NoError:
        raise ValueError(f"{context} is not a valid manifold solid")
    return solid


def _mesh_from_manifold(solid: manifold3d.Manifold) -> MeshGeometry:
    output = solid.to_mesh()
    return MeshGeometry(
        vertices=[tuple(float(value) for value in row[:3]) for row in output.vert_properties],
        faces=[tuple(int(value) for value in row) for row in output.tri_verts],
    )


def _outward_box_geometry(size: tuple[float, float, float]) -> MeshGeometry:
    geometry = BoxGeometry(size)
    return MeshGeometry(
        vertices=list(geometry.vertices),
        faces=[(a, c, b) for a, b, c in geometry.faces],
    )


def _flattened_round_profile(radius: float) -> list[tuple[float, float]]:
    """Return a round-dominant section with symmetric horizontal contact flats."""
    radius = float(radius)
    flat_half_height = radius * (1.0 - _HANDLE_ROUND_FLAT_DEPTH_RATIO)
    flat_angle = math.asin(flat_half_height / radius)
    side_segments = max(4, (_HANDLE_RADIAL_SEGMENTS - 2) // 2)

    profile = []
    for index in range(side_segments + 1):
        angle = -flat_angle + 2.0 * flat_angle * index / side_segments
        profile.append((radius * math.cos(angle), radius * math.sin(angle)))

    profile.append((-radius * math.cos(flat_angle), flat_half_height))
    for index in range(1, side_segments + 1):
        angle = math.pi - flat_angle + 2.0 * flat_angle * index / side_segments
        profile.append((radius * math.cos(angle), radius * math.sin(angle)))
    return profile


def _trim_handle_to_front(
    handle_geometry: MeshGeometry,
    front_geometry: MeshGeometry,
    *,
    handle_name: str,
    minimum_intersection_volume: float,
) -> MeshGeometry:
    handle_solid = _as_manifold(handle_geometry, context=f"extended {handle_name}")
    front_solid = _as_manifold(front_geometry, context=f"{handle_name} drawer front")
    intersection_volume = float((handle_solid ^ front_solid).volume())
    if intersection_volume < minimum_intersection_volume:
        raise ValueError(
            f"{handle_name} stock did not intersect both drawer-front roots: "
            f"intersection={intersection_volume:.9g}, required={minimum_intersection_volume:.9g}"
        )

    pieces = list((handle_solid - front_solid).decompose())
    if len(pieces) != 1:
        raise ValueError(f"trimmed {handle_name} must remain one connected pull")
    result = _mesh_from_manifold(pieces[0])
    if not result.faces:
        raise ValueError(f"drawer-front trimming removed {handle_name}")
    return result


def _drawer_dimensions(parameters: Mapping[str, Any]) -> dict[str, float]:
    width = float(parameters["overall_width"])
    body_height = float(parameters["body_height"])
    panel = float(parameters["panel_thickness"])
    rail = float(parameters["center_rail_thickness"])
    inner_width = width - 2.0 * panel
    opening_height = 0.5 * (body_height - 2.0 * panel - rail)
    if parameters["front_construction"] == "inset":
        front_width = inner_width - 2.0 * _DRAWER_FACE_GAP
        front_height = opening_height - 2.0 * _DRAWER_FACE_GAP
    else:
        front_width = width - 2.0 * _DRAWER_FACE_GAP
        front_height = opening_height - 2.0 * _DRAWER_FACE_GAP
    return {
        "inner_width": inner_width,
        "opening_height": opening_height,
        "front_width": front_width,
        "front_height": front_height,
        "box_width": inner_width - 2.0 * _DRAWER_BOX_CLEARANCE,
        "box_height": opening_height - 2.0 * _DRAWER_BOX_CLEARANCE,
    }


def _pull_handle_geometry(
    parameters: Mapping[str, Any],
    *,
    front_geometry: MeshGeometry,
    front_mount_y: float,
    front_back_y: float,
    front_height: float,
    handle_name: str,
) -> MeshGeometry:
    span = float(parameters["handle_span"])
    projection = float(parameters["handle_projection"])
    radius = float(parameters["handle_tube_radius"])
    center_z = -0.5 * front_height + float(parameters["handle_center_height_ratio"]) * front_height
    root_stock = min(_HANDLE_ROOT_STOCK, 0.5 * (front_back_y - front_mount_y))
    if root_stock <= 0.0:
        raise ValueError(f"{handle_name} has no drawer-front stock behind its mounting surface")
    inside_y = front_mount_y + root_stock
    outside_y = front_mount_y - projection

    if parameters["pull_path"] == "rectangular_pull":
        section_depth = 2.0 * radius
        section_height = 2.6 * radius
        return_length = inside_y - outside_y
        grip = _outward_box_geometry(
            (span + 2.0 * radius, section_depth, section_height)
        ).translate(0.0, outside_y, center_z)
        left_return = _outward_box_geometry(
            (2.0 * radius, return_length, section_height)
        ).translate(-0.5 * span, 0.5 * (inside_y + outside_y), center_z)
        right_return = _outward_box_geometry(
            (2.0 * radius, return_length, section_height)
        ).translate(0.5 * span, 0.5 * (inside_y + outside_y), center_z)
        united = (
            _as_manifold(grip, context=f"{handle_name} rectangular grip")
            + _as_manifold(left_return, context=f"{handle_name} left rectangular return")
            + _as_manifold(right_return, context=f"{handle_name} right rectangular return")
        )
        pieces = list(united.decompose())
        if len(pieces) != 1:
            raise ValueError(f"extended {handle_name} must remain one rectangular pull")
        extended = _mesh_from_manifold(pieces[0])
    elif parameters["pull_path"] == "bowed_arc":
        # Four chained cubic Bezier segments place the final surface-root centers exactly at the
        # exposed span while preserving tangent continuity from the sacrificial stock into the arc.
        path = [
            (-0.5 * span, inside_y, center_z),
            (-0.5 * span, front_mount_y + 2.0 * root_stock / 3.0, center_z),
            (-0.5 * span, front_mount_y + root_stock / 3.0, center_z),
            (-0.5 * span, front_mount_y, center_z),
            (-0.5 * span, front_mount_y - 0.50 * projection, center_z),
            (-0.34 * span, outside_y, center_z),
            (0.0, outside_y, center_z),
            (0.34 * span, outside_y, center_z),
            (0.5 * span, front_mount_y - 0.50 * projection, center_z),
            (0.5 * span, front_mount_y, center_z),
            (0.5 * span, front_mount_y + root_stock / 3.0, center_z),
            (0.5 * span, front_mount_y + 2.0 * root_stock / 3.0, center_z),
            (0.5 * span, inside_y, center_z),
        ]
    else:
        # Five Bezier segments make a common returned bar. Straight sacrificial root segments end
        # at the exact exposed root centers, then tangent-continuous returns meet the center grip.
        bend = min(0.22 * span, 1.25 * projection)
        straight_start = -0.5 * span + bend
        straight_end = 0.5 * span - bend
        straight_third = (straight_end - straight_start) / 3.0
        path = [
            (-0.5 * span, inside_y, center_z),
            (-0.5 * span, front_mount_y + 2.0 * root_stock / 3.0, center_z),
            (-0.5 * span, front_mount_y + root_stock / 3.0, center_z),
            (-0.5 * span, front_mount_y, center_z),
            (-0.5 * span, front_mount_y - 0.62 * projection, center_z),
            (-0.5 * span, outside_y, center_z),
            (straight_start, outside_y, center_z),
            (straight_start + straight_third, outside_y, center_z),
            (straight_start + 2.0 * straight_third, outside_y, center_z),
            (straight_end, outside_y, center_z),
            (0.5 * span, outside_y, center_z),
            (0.5 * span, front_mount_y - 0.62 * projection, center_z),
            (0.5 * span, front_mount_y, center_z),
            (0.5 * span, front_mount_y + root_stock / 3.0, center_z),
            (0.5 * span, front_mount_y + 2.0 * root_stock / 3.0, center_z),
            (0.5 * span, inside_y, center_z),
        ]
    if parameters["pull_path"] != "rectangular_pull":
        if (
            parameters["pull_path"] == "bowed_arc"
            or parameters["handle_section_profile"] == "round_tube"
        ):
            extended = sweep_profile_along_spline(
                path,
                profile=_flattened_round_profile(radius),
                samples_per_segment=_HANDLE_CURVE_SAMPLES,
                spline="bezier",
                cap_profile=True,
                up_hint=(0.0, 0.0, 1.0),
            )
        else:
            extended = sweep_profile_along_spline(
                path,
                profile=rounded_rect_profile(
                    3.2 * radius,
                    2.0 * radius,
                    radius=0.45 * radius,
                    corner_segments=5,
                ),
                samples_per_segment=_HANDLE_CURVE_SAMPLES,
                spline="bezier",
                cap_profile=True,
                up_hint=(0.0, 0.0, 1.0),
            )
    witness = max(1e-10, 0.15 * 2.0 * math.pi * radius * radius * root_stock)
    return _trim_handle_to_front(
        extended,
        front_geometry,
        handle_name=handle_name,
        minimum_intersection_volume=witness,
    )


def _drawer_front_geometry(
    parameters: Mapping[str, Any], dims: Mapping[str, float]
) -> tuple[MeshGeometry, float, float]:
    front_thickness = float(parameters["drawer_front_thickness"])
    if parameters["front_construction"] == "inset":
        exterior_y = 0.0
        box_start_y = front_thickness
    else:
        exterior_y = -front_thickness
        box_start_y = 0.0
    back_y = exterior_y + front_thickness

    if parameters["front_profile"] == "slab":
        front = _outward_box_geometry(
            (dims["front_width"], front_thickness, dims["front_height"])
        ).translate(0.0, exterior_y + 0.5 * front_thickness, 0.0)
        return front, exterior_y, box_start_y

    frame = float(parameters["front_frame_width"])
    recess = float(parameters["front_recess_depth"])
    front = _outward_box_geometry(
        (dims["front_width"], front_thickness, dims["front_height"])
    ).translate(0.0, exterior_y + 0.5 * front_thickness, 0.0)
    cutter_overrun = 0.002
    cutter = _outward_box_geometry(
        (
            dims["front_width"] - 2.0 * frame,
            recess + cutter_overrun,
            dims["front_height"] - 2.0 * frame,
        )
    ).translate(0.0, exterior_y + 0.5 * (recess - cutter_overrun), 0.0)
    recessed = _as_manifold(front, context="drawer-front slab") - _as_manifold(
        cutter, context="drawer-front recess cutter"
    )
    pieces = list(recessed.decompose())
    if len(pieces) != 1:
        raise ValueError("recessed drawer front must remain one connected solid")
    return _mesh_from_manifold(pieces[0]), exterior_y + recess, box_start_y


def _add_drawer_visuals(
    model: ArticulatedObject,
    parameters: Mapping[str, Any],
    *,
    drawer_name: str,
    neutral: object,
    accent: object,
) -> object:
    dims = _drawer_dimensions(parameters)
    wall = float(parameters["drawer_wall_thickness"])
    box_depth = float(parameters["drawer_box_depth"])

    drawer = model.part(drawer_name)
    front_geometry, front_mount_y, box_start_y = _drawer_front_geometry(parameters, dims)
    drawer.visual(
        mesh_from_geometry(front_geometry, f"{drawer_name}_front"),
        origin=Origin(),
        material=neutral,
        name=f"{drawer_name}_front",
    )

    side_depth = box_depth
    side_center_y = box_start_y + 0.5 * side_depth
    side_x = 0.5 * (dims["box_width"] - wall)
    for side, x in (("left", -side_x), ("right", side_x)):
        drawer.visual(
            Box((wall, side_depth, dims["box_height"])),
            origin=Origin(xyz=(x, side_center_y, 0.0)),
            material=neutral,
            name=f"{drawer_name}_{side}_wall",
        )

    drawer.visual(
        Box((dims["box_width"] - 2.0 * wall, box_depth, wall)),
        origin=Origin(
            xyz=(
                0.0,
                side_center_y,
                -0.5 * dims["box_height"] + 0.5 * wall,
            )
        ),
        material=neutral,
        name=f"{drawer_name}_bottom",
    )
    drawer.visual(
        Box((dims["box_width"], wall, dims["box_height"])),
        origin=Origin(
            xyz=(
                0.0,
                box_start_y + box_depth - 0.5 * wall,
                0.0,
            )
        ),
        material=neutral,
        name=f"{drawer_name}_back",
    )

    handle_geometry = _pull_handle_geometry(
        parameters,
        front_geometry=front_geometry,
        front_mount_y=front_mount_y,
        front_back_y=box_start_y,
        front_height=dims["front_height"],
        handle_name=f"{drawer_name} handle",
    )
    drawer.visual(
        mesh_from_geometry(handle_geometry, f"{drawer_name}_handle"),
        origin=Origin(),
        material=accent,
        name=f"{drawer_name}_handle",
    )
    return drawer


def build_model(parameters: Mapping[str, Any]) -> ArticulatedObject:
    width = float(parameters["overall_width"])
    depth = float(parameters["overall_depth"])
    total_height = float(parameters["overall_height"])
    support_height = float(parameters["support_height"])
    body_height = float(parameters["body_height"])
    panel = float(parameters["panel_thickness"])
    back = float(parameters["back_panel_thickness"])
    rail = float(parameters["center_rail_thickness"])
    overhang = float(parameters["top_overhang"])
    dims = _drawer_dimensions(parameters)

    model = ArticulatedObject(name="two_drawer_cabinet")
    neutral = model.material("neutral", rgba=(0.50, 0.52, 0.54, 1.0))
    accent = model.material("handle_accent", rgba=(0.28, 0.30, 0.32, 1.0))
    cabinet = model.part("cabinet")
    body_center_z = support_height + 0.5 * body_height

    cabinet.visual(
        Box((panel, depth, body_height)),
        origin=Origin(xyz=(-0.5 * width + 0.5 * panel, 0.0, body_center_z)),
        material=neutral,
        name="left_side",
    )
    cabinet.visual(
        Box((panel, depth, body_height)),
        origin=Origin(xyz=(0.5 * width - 0.5 * panel, 0.0, body_center_z)),
        material=neutral,
        name="right_side",
    )
    cabinet.visual(
        Box((width + 2.0 * overhang, depth + 2.0 * overhang, panel)),
        origin=Origin(xyz=(0.0, 0.0, total_height - 0.5 * panel)),
        material=neutral,
        name="top_panel",
    )
    cabinet.visual(
        Box((width, depth, panel)),
        origin=Origin(xyz=(0.0, 0.0, support_height + 0.5 * panel)),
        material=neutral,
        name="bottom_panel",
    )
    cabinet.visual(
        Box((width - 2.0 * panel, back, body_height - 2.0 * panel)),
        origin=Origin(xyz=(0.0, 0.5 * depth - 0.5 * back, body_center_z)),
        material=neutral,
        name="back_panel",
    )
    rail_depth = min(0.09, 0.24 * depth)
    cabinet.visual(
        Box((width - 2.0 * panel, rail_depth, rail)),
        origin=Origin(
            xyz=(0.0, -0.5 * depth + 0.5 * rail_depth, support_height + 0.5 * body_height)
        ),
        material=neutral,
        name="center_rail",
    )

    inset = float(parameters["support_inset"])
    if parameters["support_style"] == "floor_base":
        cabinet.visual(
            Box((width - 2.0 * inset, depth - 2.0 * inset, support_height)),
            origin=Origin(xyz=(0.0, 0.0, 0.5 * support_height)),
            material=neutral,
            name="floor_base",
        )
    else:
        leg_width = float(parameters["leg_width"])
        leg_x = 0.5 * width - inset - 0.5 * leg_width
        leg_y = 0.5 * depth - inset - 0.5 * leg_width
        for name, x, y in (
            ("front_left_leg", -leg_x, -leg_y),
            ("front_right_leg", leg_x, -leg_y),
            ("rear_left_leg", -leg_x, leg_y),
            ("rear_right_leg", leg_x, leg_y),
        ):
            cabinet.visual(
                Box((leg_width, leg_width, support_height)),
                origin=Origin(xyz=(x, y, 0.5 * support_height)),
                material=neutral,
                name=name,
            )

    lower_drawer = _add_drawer_visuals(
        model,
        parameters,
        drawer_name="lower_drawer",
        neutral=neutral,
        accent=accent,
    )
    upper_drawer = _add_drawer_visuals(
        model,
        parameters,
        drawer_name="upper_drawer",
        neutral=neutral,
        accent=accent,
    )

    lower_center_z = support_height + panel + 0.5 * dims["opening_height"]
    upper_center_z = support_height + body_height - panel - 0.5 * dims["opening_height"]
    travel = float(parameters["drawer_extension"])
    limits = MotionLimits(effort=80.0, velocity=0.5, lower=0.0, upper=travel)
    model.articulation(
        "cabinet_to_lower_drawer",
        ArticulationType.PRISMATIC,
        parent=cabinet,
        child=lower_drawer,
        origin=Origin(xyz=(0.0, -0.5 * depth, lower_center_z)),
        axis=(0.0, -1.0, 0.0),
        motion_limits=limits,
        meta={"qc_samples": [0.0, travel]},
    )
    model.articulation(
        "cabinet_to_upper_drawer",
        ArticulationType.PRISMATIC,
        parent=cabinet,
        child=upper_drawer,
        origin=Origin(xyz=(0.0, -0.5 * depth, upper_center_z)),
        axis=(0.0, -1.0, 0.0),
        motion_limits=limits,
        meta={"qc_samples": [0.0, travel]},
    )
    return model


def _aabb_extents(aabb: tuple[Sequence[float], Sequence[float]] | None) -> tuple[float, ...]:
    if aabb is None:
        return ()
    return tuple(float(aabb[1][axis]) - float(aabb[0][axis]) for axis in range(3))


def run_tests(model: ArticulatedObject, parameters: Mapping[str, Any]):
    ctx = TestContext(model)
    ctx.allow_isolated_part(
        "lower_drawer",
        reason=(
            "The omitted commercial runner hardware is represented by the declared prismatic "
            "JointMount; the drawer shell is intentionally clearanced from the carcass."
        ),
    )
    ctx.allow_isolated_part(
        "upper_drawer",
        reason=(
            "The omitted commercial runner hardware is represented by the declared prismatic "
            "JointMount; the drawer shell is intentionally clearanced from the carcass."
        ),
    )
    ctx.check(
        "exactly-two-drawer-links",
        {part.name for part in model.parts} == {"cabinet", "lower_drawer", "upper_drawer"},
        details="The category requires one cabinet and exactly two moving drawer links.",
    )
    ctx.check(
        "exactly-two-prismatic-drawer-joints",
        len(model.articulations) == 2
        and all(
            joint.articulation_type == ArticulationType.PRISMATIC for joint in model.articulations
        ),
        details="Both and only drawer links must slide outward on prismatic joints.",
    )

    lower_front = ctx.part_element_world_aabb("lower_drawer", elem="lower_drawer_front")
    upper_front = ctx.part_element_world_aabb("upper_drawer", elem="upper_drawer_front")
    lower_handle = ctx.part_element_world_aabb("lower_drawer", elem="lower_drawer_handle")
    upper_handle = ctx.part_element_world_aabb("upper_drawer", elem="upper_drawer_handle")
    ctx.check(
        "drawer-fronts-are-identical",
        all(
            abs(left - right) <= 1e-7
            for left, right in zip(_aabb_extents(lower_front), _aabb_extents(upper_front))
        )
        and len(_aabb_extents(lower_front)) == 3,
        details="Upper and lower drawer fronts must have identical compiled extents.",
    )
    ctx.check(
        "pulls-are-identical",
        all(
            abs(left - right) <= 1e-7
            for left, right in zip(_aabb_extents(lower_handle), _aabb_extents(upper_handle))
        )
        and len(_aabb_extents(lower_handle)) == 3,
        details="Both drawers must carry the same continuous pull geometry; knobs are excluded.",
    )

    travel = float(parameters["drawer_extension"])
    for drawer_name, joint_name in (
        ("lower_drawer", "cabinet_to_lower_drawer"),
        ("upper_drawer", "cabinet_to_upper_drawer"),
    ):
        rest = ctx.part_world_position(drawer_name)
        with ctx.pose({joint_name: travel}):
            opened = ctx.part_world_position(drawer_name)
            ctx.check(
                f"{drawer_name}-moves-outward",
                rest is not None and opened is not None and opened[1] <= rest[1] - travel + 1e-8,
                details=f"rest={rest}, opened={opened}, travel={travel}",
            )
            ctx.expect_within(
                drawer_name,
                "cabinet",
                axes="xz",
                margin=0.0,
                name=f"{drawer_name}-remains-guided-laterally-and-vertically",
            )
    return ctx.report()


def _covers_choices(samples: Sequence[Mapping[str, Any]], factor: str, expected: set[str]) -> bool:
    return {str(sample[factor]) for sample in samples} >= expected


def _covers_choices_when(
    samples: Sequence[Mapping[str, Any]],
    factor: str,
    expected: set[str],
    *,
    when_factor: str,
    when_value: str,
) -> bool:
    return {
        str(sample[factor]) for sample in samples if str(sample[when_factor]) == when_value
    } >= expected


def _covers_bounds(
    samples: Sequence[Mapping[str, Any]],
    factor: str,
    *,
    low: float,
    high: float,
) -> bool:
    values = [float(sample[factor]) for sample in samples]
    return min(values) <= low and max(values) >= high


def _covers_ratio(
    samples: Sequence[Mapping[str, Any]],
    numerator: str,
    denominator: str,
    *,
    low: float,
    high: float,
) -> bool:
    values = [float(sample[numerator]) / float(sample[denominator]) for sample in samples]
    return min(values) <= low and max(values) >= high


GENERATOR = GeneratorSpec(
    name="two_drawer_cabinet",
    category="two_drawer_cabinet",
    description=(
        "Common household two-drawer cabinets, file cabinets, and nightstands with two identical "
        "vertically stacked moving drawers and a continuous two-root pull on every drawer."
    ),
    design=GeneratorDesign(
        coverage=(
            "One connected ordinary size population spans 0.30-0.60 m in carcass width, 0.25-0.45 m "
            "in carcass depth, and 0.28-0.70 m in floor-to-top height. Transparent aspect constraints "
            "remove only unsupported broad-low, narrow-deep, and narrow-tall corners. Common inset and "
            "overlay placement, slab and recessed-panel faces, and floor-base or four-leg supports "
            "remain independently combinable. Every construction retains exactly two equal stacked "
            "drawers and two-root bowed-arc, returned-bar, or rectangular pulls. Excluded are knobs, "
            "door/open-shelf "
            "hybrids, unequal pencil/file drawer pairs, ornate fronts, and accessory locks or casters."
        ),
        factors=(
            "Carcass width, carcass depth, and floor-to-top height vary independently across their "
            "ordinary intervals; explicit depth/width and height/width constraints remove only residual "
            "unsupported aspect corners. Panel/front thickness, top overhang, pull root span, pull "
            "projection, section size, recess depth, and pull height vary independently. Drawer depth "
            "follows 70-92% of cabinet depth, and full-extension travel exactly equals box depth. Pull root span "
            "has a 70-150 mm physical envelope independent of carcass width. Four-leg supports have an "
            "independent 50-100 mm physical height envelope; floor-base and frame sizes scale with cabinet "
            "height. Back, rail, wall, active support, and body dimensions are exact derivations."
        ),
        components=(
            "The complete carcass has side, top, bottom, back, and center-rail solids. Drawer fronts "
            "vary independently between inset/overlay placement and slab/recessed framed profiles; "
            "both identical boxes include bottom, side walls, and back. Each pull is one coherent "
            "two-root member: a round-dominant bowed arc with small opposing flats, a smooth returned "
            "bar whose section may use the same flattened-round profile or a softly rounded rectangle, "
            "or a crisp rectangular U-pull with straight grip "
            "and returns. All share a 70-150 mm root span, 15-40 mm centerline projection, a 4-7 mm "
            "section scale, and relative vertical placement. "
            "Straight square legs are retained as the common non-decorative leg family; tapered or "
            "splayed legs remain an accepted advisory limitation."
        ),
        physics_and_task=(
            "The cabinet carcass is the root. Its floor base or each of four legs has genuine planar "
            "contact with the bottom panel. Two separate prismatic drawer links slide outward while "
            "remaining enclosed on the transverse axes. Each complete arc pull is cut back to the "
            "drawer-front surface from inward sacrificial stock, leaving both finite roots seated and "
            "a genuine unobstructed grasp opening; no connector pads or knobs are used."
        ),
    ),
    factors=(
        UniformFloat(
            name="overall_width",
            low=0.30,
            high=0.60,
            description="Outside left-to-right width of the cabinet carcass.",
            unit="m",
        ),
        UniformFloat(
            name="overall_depth",
            low=0.25,
            high=0.45,
            description="Outside front-to-back depth of the cabinet carcass.",
            unit="m",
        ),
        UniformFloat(
            name="overall_height",
            low=0.28,
            high=0.70,
            description="Total floor-to-top cabinet height, including the active support.",
            unit="m",
        ),
        UniformChoice(
            name="support_style",
            choices=("floor_base", "four_legs"),
            description="Common grounded plinth/base or elevated four-leg support construction.",
        ),
        RelativeUniformFloat(
            name="floor_base_height",
            reference="overall_height",
            ratio_low=0.04,
            ratio_high=0.09,
            hard_min=0.018,
            hard_max=0.060,
            active_when=(ActiveWhen(factor="support_style", values=("floor_base",)),),
            description="Recessed floor-base height relative to total cabinet height.",
            unit="m",
        ),
        UniformFloat(
            name="leg_height",
            low=0.050,
            high=0.100,
            active_when=(ActiveWhen(factor="support_style", values=("four_legs",)),),
            description="Visible height of the common four-leg support construction.",
            unit="m",
        ),
        Derived(
            name="support_height",
            derive=lambda p: (
                p["floor_base_height"] if p["support_style"] == "floor_base" else p["leg_height"]
            ),
            depends_on=("support_style", "floor_base_height", "leg_height"),
            description="Exact height of the active support construction.",
            unit="m",
        ),
        Derived(
            name="body_height",
            derive=lambda p: p["overall_height"] - p["support_height"],
            depends_on=("overall_height", "support_height"),
            description="Exact carcass height above the support construction.",
            unit="m",
        ),
        UniformFloat(
            name="panel_thickness",
            low=0.012,
            high=0.026,
            description="Carcass side, top, and bottom panel thickness.",
            unit="m",
        ),
        Derived(
            name="back_panel_thickness",
            derive=lambda p: 0.55 * p["panel_thickness"],
            depends_on=("panel_thickness",),
            description="Back-panel thickness derived from the carcass stock.",
            unit="m",
        ),
        Derived(
            name="center_rail_thickness",
            derive=lambda p: 0.80 * p["panel_thickness"],
            depends_on=("panel_thickness",),
            description="Front center-rail thickness derived from the carcass stock.",
            unit="m",
        ),
        UniformFloat(
            name="top_overhang",
            low=0.0,
            high=0.025,
            description="Horizontal top-panel extension beyond each carcass side and face.",
            unit="m",
        ),
        UniformChoice(
            name="front_construction",
            choices=("inset", "overlay"),
            description="Drawer fronts fitted inside the opening or laid over the face frame.",
        ),
        UniformChoice(
            name="front_profile",
            choices=("slab", "recessed_panel"),
            description="Plain slab face or a common non-decorative recessed framed face.",
        ),
        UniformFloat(
            name="drawer_front_thickness",
            low=0.012,
            high=0.024,
            description="Shared thickness of both identical drawer fronts.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="front_frame_width",
            reference="body_height",
            ratio_low=0.045,
            ratio_high=0.075,
            hard_min=0.015,
            hard_max=0.050,
            active_when=(ActiveWhen(factor="front_profile", values=("recessed_panel",)),),
            description="Visible border width of both identical recessed-panel fronts.",
            unit="m",
        ),
        UniformFloat(
            name="front_recess_depth",
            low=0.003,
            high=0.008,
            active_when=(ActiveWhen(factor="front_profile", values=("recessed_panel",)),),
            description="Setback of the center field behind the coherent raised front frame.",
            unit="m",
        ),
        Derived(
            name="drawer_wall_thickness",
            derive=lambda p: 0.58 * p["panel_thickness"],
            depends_on=("panel_thickness",),
            description="Shared side, back, and bottom thickness of both drawer boxes.",
            unit="m",
        ),
        RelativeUniformFloat(
            name="drawer_box_depth",
            reference="overall_depth",
            ratio_low=0.70,
            ratio_high=0.92,
            description="Front-to-back drawer-box depth relative to the enclosing cabinet depth.",
            unit="m",
        ),
        Derived(
            name="drawer_extension",
            derive=lambda p: p["drawer_box_depth"],
            depends_on=("drawer_box_depth",),
            description="Full-extension outward travel equal to the drawer-box depth.",
            unit="m",
        ),
        UniformChoice(
            name="pull_path",
            choices=("returned_bar", "rectangular_pull", "bowed_arc"),
            description=(
                "Smooth fully bowed arc, smooth returned bar, or crisp rectangular U-pull with a "
                "straight center grip."
            ),
        ),
        UniformChoice(
            name="handle_section_profile",
            choices=("round_tube", "soft_rectangular_bar"),
            active_when=(ActiveWhen(factor="pull_path", values=("returned_bar",)),),
            description=(
                "Round-dominant tube with small opposing top/bottom flats or a softly rounded "
                "rectangular returned-bar cross-section."
            ),
        ),
        UniformFloat(
            name="handle_span",
            low=0.070,
            high=0.150,
            description="Horizontal center-to-center span between the two pull roots.",
            unit="m",
        ),
        UniformFloat(
            name="handle_projection",
            low=0.015,
            high=0.040,
            description="Maximum outward distance from drawer-front surface to pull centerline.",
            unit="m",
        ),
        UniformFloat(
            name="handle_tube_radius",
            low=0.004,
            high=0.007,
            description=(
                "Parent-circle radius of a flattened-round section or half the smaller span of "
                "both identical pull sections."
            ),
            unit="m",
        ),
        UniformFloat(
            name="handle_center_height_ratio",
            low=0.46,
            high=0.70,
            description="Pull root height from the bottom of each identical drawer front.",
            unit="ratio",
        ),
        UniformFloat(
            name="support_inset",
            low=0.015,
            high=0.050,
            description="Horizontal setback of the active base or legs from the carcass edges.",
            unit="m",
        ),
        UniformFloat(
            name="leg_width",
            low=0.035,
            high=0.065,
            active_when=(ActiveWhen(factor="support_style", values=("four_legs",)),),
            description="Square cross-section width of all four identical legs.",
            unit="m",
        ),
    ),
    relationships=(
        JointMount(
            name="lower-drawer-guided-by-cabinet",
            joint="cabinet_to_lower_drawer",
            parent_part="cabinet",
            child_part="lower_drawer",
            allowed_joint_types=("prismatic",),
        ),
        JointMount(
            name="upper-drawer-guided-by-cabinet",
            joint="cabinet_to_upper_drawer",
            parent_part="cabinet",
            child_part="upper_drawer",
            allowed_joint_types=("prismatic",),
        ),
        RigidMount(
            name="lower-arc-pull-mounted-to-drawer-front",
            parent_part="lower_drawer",
            parent_element="lower_drawer_front",
            child_part="lower_drawer",
            child_element="lower_drawer_handle",
        ),
        RigidMount(
            name="upper-arc-pull-mounted-to-drawer-front",
            parent_part="upper_drawer",
            parent_element="upper_drawer_front",
            child_part="upper_drawer",
            child_element="upper_drawer_handle",
        ),
        RigidMount(
            name="floor-base-mounted-to-bottom-panel",
            parent_part="cabinet",
            parent_element="bottom_panel",
            child_part="cabinet",
            child_element="floor_base",
            active_when=(ActiveWhen(factor="support_style", values=("floor_base",)),),
        ),
        RigidMount(
            name="front-left-leg-mounted-to-bottom-panel",
            parent_part="cabinet",
            parent_element="bottom_panel",
            child_part="cabinet",
            child_element="front_left_leg",
            active_when=(ActiveWhen(factor="support_style", values=("four_legs",)),),
        ),
        RigidMount(
            name="front-right-leg-mounted-to-bottom-panel",
            parent_part="cabinet",
            parent_element="bottom_panel",
            child_part="cabinet",
            child_element="front_right_leg",
            active_when=(ActiveWhen(factor="support_style", values=("four_legs",)),),
        ),
        RigidMount(
            name="rear-left-leg-mounted-to-bottom-panel",
            parent_part="cabinet",
            parent_element="bottom_panel",
            child_part="cabinet",
            child_element="rear_left_leg",
            active_when=(ActiveWhen(factor="support_style", values=("four_legs",)),),
        ),
        RigidMount(
            name="rear-right-leg-mounted-to-bottom-panel",
            parent_part="cabinet",
            parent_element="bottom_panel",
            child_part="cabinet",
            child_element="rear_right_leg",
            active_when=(ActiveWhen(factor="support_style", values=("four_legs",)),),
        ),
    ),
    constraints=(
        Constraint(
            name="ordinary-cabinet-aspect-envelope",
            predicate=lambda p: (
                p["overall_depth"] <= 1.35 * p["overall_width"]
                and p["overall_height"] <= 1.85 * p["overall_width"]
                and p["overall_height"] >= 0.68 * p["overall_width"]
                and p["overall_width"] <= 2.40 * p["overall_depth"]
            ),
            message=(
                "Resolved dimensions must exclude narrow-deep/tall and broad-shallow/low residual "
                "corners while preserving the connected ordinary size population."
            ),
        ),
        Constraint(
            name="carcass-retains-two-usable-openings",
            predicate=lambda p: (
                p["body_height"] - 2.0 * p["panel_thickness"] - p["center_rail_thickness"] >= 0.17
            ),
            message="The body must retain two ordinary drawer openings after panels and rail.",
        ),
        Constraint(
            name="handle-section-fits-projection",
            predicate=lambda p: p["handle_projection"] >= 3.0 * p["handle_tube_radius"],
            message="The pull projection must leave a real open return behind its section.",
        ),
        Constraint(
            name="supports-fit-under-footprint",
            predicate=lambda p: (
                2.0 * p["support_inset"] + p["leg_width"] < p["overall_depth"]
                and 2.0 * p["support_inset"] + p["leg_width"] < p["overall_width"]
            ),
            message="The active base or all four legs must remain beneath the cabinet footprint.",
        ),
    ),
    population_checks=(
        PopulationCheck(
            name="covers-overall-size-envelope",
            predicate=lambda samples: (
                _covers_bounds(samples, "overall_width", low=0.305, high=0.595)
                and _covers_bounds(samples, "overall_depth", low=0.255, high=0.445)
                and _covers_bounds(samples, "overall_height", low=0.285, high=0.695)
            ),
            message="Validation must reach width, depth, and floor-to-top height margins.",
        ),
        PopulationCheck(
            name="covers-support-constructions",
            predicate=lambda samples: _covers_choices(
                samples, "support_style", {"floor_base", "four_legs"}
            ),
            message="Validation must exercise floor-base and four-leg support constructions.",
        ),
        PopulationCheck(
            name="covers-drawer-front-constructions",
            predicate=lambda samples: (
                _covers_choices(samples, "front_construction", {"inset", "overlay"})
                and _covers_choices(samples, "front_profile", {"slab", "recessed_panel"})
            ),
            message=(
                "Validation must exercise inset/overlay placement and slab/recessed front profiles."
            ),
        ),
        PopulationCheck(
            name="covers-drawer-depth-envelope",
            predicate=lambda samples: _covers_ratio(
                samples, "drawer_box_depth", "overall_depth", low=0.705, high=0.915
            ),
            message="Validation must reach both ends of the drawer-depth envelope.",
        ),
        PopulationCheck(
            name="covers-pull-envelope",
            predicate=lambda samples: (
                _covers_choices(
                    samples,
                    "pull_path",
                    {"bowed_arc", "returned_bar", "rectangular_pull"},
                )
                and _covers_choices_when(
                    samples,
                    "handle_section_profile",
                    {"round_tube", "soft_rectangular_bar"},
                    when_factor="pull_path",
                    when_value="returned_bar",
                )
                and _covers_bounds(samples, "handle_span", low=0.071, high=0.149)
                and _covers_bounds(samples, "handle_projection", low=0.016, high=0.039)
                and _covers_bounds(samples, "handle_tube_radius", low=0.0041, high=0.0069)
                and _covers_bounds(samples, "handle_center_height_ratio", low=0.47, high=0.69)
            ),
            message=(
                "Validation must exercise both pull paths and reach span, projection, section, and "
                "placement margins."
            ),
        ),
    ),
    build=build_model,
    tests=run_tests,
    task_requirements=(
        "Every instance has exactly two identical vertically stacked drawers.",
        "Every drawer has one genuine two-root continuous pull handle; knobs are forbidden.",
        "Both drawers move outward while remaining guided by the cabinet.",
    ),
    tags=("cabinet", "file cabinet", "nightstand", "two drawers", "pull handle"),
)
