"""Placeholder modules for CAD and solver libraries that the SDK imports but the demo generators never
call. Appended to the end of sys.meta_path, so real modules win when they exist."""
import importlib.abc
import importlib.machinery
import sys
import types

STUBBED = ("OCP", "ezdxf", "vtkmodules", "vtk", "casadi", "nlopt", "fcl", "rtree", "trimesh", "scipy")


class _Missing:
    def __init__(self, *a, **k):
        raise ImportError("not available in the browser demo")

    def __class_getitem__(cls, item):
        return cls


class _Module(types.ModuleType):
    __path__ = []

    def __getattr__(self, name):
        if name.startswith("__"):
            raise AttributeError(name)
        return type(name, (_Missing,), {})


class _Finder(importlib.abc.MetaPathFinder, importlib.abc.Loader):
    def find_spec(self, name, path=None, target=None):
        if name.split(".")[0] in STUBBED:
            return importlib.machinery.ModuleSpec(name, self, is_package=True)
        return None

    def create_module(self, spec):
        return _Module(spec.name)

    def exec_module(self, module):
        pass


sys.meta_path.append(_Finder())
